<?php

$p=0;
//Padi
while($rowtemp = mysqli_fetch_assoc($temppadi)){
  if($temperatur == $rowtemp['s1']){
    $c1p=1; 
  }elseif($temperatur == $rowtemp['s2']){
    $c1p=0.75; 
  }elseif($temperatur == $rowtemp['s3']){
    $c1p=0.5;
  }elseif($temperatur == $rowtemp['n']){
    $c1p=0.25;
  }elseif($temperatur == $rowtemp['kosong']){
    $c1p=0.25;
    $p=$p+1;
  }
}
while($rowka = mysqli_fetch_assoc($kapadi)){
  if($ketersediaanair == $rowka['s1']){
    $c2p=1;
  }elseif($ketersediaanair == $rowka['s2']){
    $c2p=0.75;
  }elseif($ketersediaanair == $rowka['s3']){
    $c2p=0.5;
  }elseif($ketersediaanair == $rowka['n']){
    $c2p=0.25;
  }elseif($ketersediaanair == $rowka['kosong']){
    $c2p=0.25;
    $p=$p+1;
  }
}
while($rowdrain = mysqli_fetch_assoc($drainpadi)){
  if($drainase == $rowdrain['s1']){
    $c3p=1;
  }elseif($drainase == $rowdrain['s2']){
    $c3p=0.75;
  }elseif($drainase == $rowdrain['s3']){
    $c3p=0.5;
  }elseif($drainase == $rowdrain['n']){
    $c3p=0.25;
  }elseif($drainase == $rowdrain['kosong']){
    $c3p=0.25;
    $p=$p+1;
  }
}
while($rowteks = mysqli_fetch_assoc($tekspadi)){
  if($tekstur == $rowteks['s1']){
    $c4p=1;
  }elseif($tekstur == $rowteks['s2']){
    $c4p=0.75;
  }elseif($tekstur == $rowteks['s3']){
    $c4p=0.5;
  }elseif($tekstur == $rowteks['n']){
    $c4p=0.25;
  }elseif($tekstur == $rowteks['kosong']){
    $c4p=0.25;
    $p=$p+1;
  }
}
while($rowbk = mysqli_fetch_assoc($bkpadi)){
  if($bahankasar == $rowbk['s1']){
    $c5p=1;
  }elseif($bahankasar == $rowbk['s2']){
    $c5p=0.75;
  }elseif($bahankasar == $rowbk['s3']){
    $c5p=0.5;
  }elseif($bahankasar == $rowbk['n']){
    $c5p=0.25;
  }elseif($bahankasar == $rowbk['kosong']){
    $c5p=0.25;
    $p=$p+1;
  }
}
while($rowkt = mysqli_fetch_assoc($ktpadi)){
  if($kedalamantanah == $rowkt['s1']){
    $c6p=1;
  }elseif($kedalamantanah == $rowkt['s2']){
    $c6p=0.75;
  }elseif($kedalamantanah == $rowkt['s3']){
    $c6p=0.5;
  }elseif($kedalamantanah == $rowkt['n']){
    $c6p=0.25;
  }elseif($kedalamantanah == $rowkt['kosong']){
    $c6p=0.25;
    $p=$p+1;
  }
}
while($rowkg = mysqli_fetch_assoc($kgpadi)){
  if($ketebalangambut == $rowkg['s1']){
    $c7p=1;
  }elseif($ketebalangambut == $rowkg['s2']){
    $c7p=0.75;
  }elseif($ketebalangambut == $rowkg['s3']){
    $c7p=0.5;
  }elseif($ketebalangambut == $rowkg['n']){
    $c7p=0.25;
  }elseif($ketebalangambut == $rowkg['kosong']){
    $c7p=0.25;
    $p=$p+1;
  }
}
while($rowktg = mysqli_fetch_assoc($ktgpadi)){
  if($kematangan == $rowktg['s1']){
    $c8p=1;
  }elseif($kematangan == $rowktg['s2']){
    $c8p=0.75;
  }elseif($kematangan == $rowktg['s3']){
    $c8p=0.5;
  }elseif($kematangan == $rowktg['n']){
    $c8p=0.25;
  }elseif($kematangan == $rowktg['kosong']){
    $c8p=0.25;
    $p=$p+1;
  }
}
while($rowktk = mysqli_fetch_assoc($ktkpadi)){
  if($ktktanah == $rowktk['s1']){
    $c9p=1;
  }elseif($ktktanah == $rowktk['s2']){
    $c9p=0.75;
  }elseif($ktktanah == $rowktk['s3']){
    $c9p=0.5;
  }elseif($ktktanah == $rowktk['n']){
    $c9p=0.25;
  }elseif($ktktanah == $rowktk['kosong']){
    $c9p=0.25;
    $p=$p+1;
  }
}
while($rowkb = mysqli_fetch_assoc($kbpadi)){
  if($kejenuhanbasa == $rowkb['s1']){
    $c10p=1;
  }elseif($kejenuhanbasa == $rowkb['s2']){
    $c10p=0.75;
  }elseif($kejenuhanbasa == $rowkb['s3']){
    $c10p=0.5;
  }elseif($kejenuhanbasa == $rowkb['n']){
    $c10p=0.25;
  }elseif($kejenuhanbasa == $rowkb['kosong']){
    $c10p=0.25;
    $p=$p+1;
  }
}
while($rowph = mysqli_fetch_assoc($phpadi)){
  if($phh2o == $rowph['s1']){
    $c11p=1;
  }elseif($phh2o == $rowph['s2']){
    $c11p=0.75;
  }elseif($phh2o == $rowph['s3']){
    $c11p=0.5;
  }elseif($phh2o == $rowph['n']){
    $c11p=0.25;
  }elseif($phh2o == $rowph['kosong']){
    $c11p=0.25;
    $p=$p+1;
  }
}
while($rowcorg = mysqli_fetch_assoc($corgpadi)){
  if($corganik == $rowcorg['s1']){
    $c12p=1;
  }elseif($corganik == $rowcorg['s2']){
    $c12p=0.75;
  }elseif($corganik == $rowcorg['s3']){
    $c12p=0.5;
  }elseif($corganik == $rowcorg['n']){
    $c12p=0.25;
  }elseif($corganik == $rowcorg['kosong']){
    $c12p=0.25;
    $p=$p+1;
  }
}
while($rowntotal = mysqli_fetch_assoc($ntotalpadi)){
  if($ntotal == $rowntotal['s1']){
    $c13p=1;
  }elseif($ntotal == $rowntotal['s2']){
    $c13p=0.75;
  }elseif($ntotal == $rowntotal['s3']){
    $c13p=0.5;
  }elseif($ntotal == $rowntotal['n']){
    $c13p=0.25;
  }elseif($ntotal == $rowntotal['kosong']){
    $c13p=0.25;
    $p=$p+1;
  }
}
while($rowp2 = mysqli_fetch_assoc($p2padi)){
  if($p2o5 == $rowp2['s1']){
    $c14p=1;
  }elseif($p2o5 == $rowp2['s2']){
    $c14p=0.75;
  }elseif($p2o5 == $rowp2['s3']){
    $c14p=0.5;
  }elseif($p2o5 == $rowp2['n']){
    $c14p=0.25;
  }elseif($p2o5 == $rowp2['kosong']){
    $c14p=0.25;
    $p=$p+1;
  }
}
while($rowk2 = mysqli_fetch_assoc($k2padi)){
  if($k2o == $rowk2['s1']){
    $c15p=1;
  }elseif($k2o == $rowk2['s2']){
    $c15p=0.75;
  }elseif($k2o == $rowk2['s3']){
    $c15p=0.5;
  }elseif($k2o == $rowk2['n']){
    $c15p=0.25;
  }elseif($k2o == $rowk2['kosong']){
    $c15p=0.25;
    $p=$p+1;
  }
}
while($rowsali = mysqli_fetch_assoc($salipadi)){
  if($salinitas == $rowsali['s1']){
    $c16p=1;
  }elseif($salinitas == $rowsali['s2']){
    $c16p=0.75;
  }elseif($salinitas == $rowsali['s3']){
    $c16p=0.5;
  }elseif($salinitas == $rowsali['n']){
    $c16p=0.25;
  }elseif($salinitas == $rowsali['kosong']){
    $c16p=0.25;
    $p=$p+1;
  }
}
while($rowalkali = mysqli_fetch_assoc($alkalipadi)){
  if($alkalinitas == $rowalkali['s1']){
    $c17p=1;
  }elseif($alkalinitas == $rowalkali['s2']){
    $c17p=0.75;
  }elseif($alkalinitas == $rowalkali['s3']){
    $c17p=0.5;
  }elseif($alkalinitas == $rowalkali['n']){
    $c17p=0.25;
  }elseif($alkalinitas == $rowalkali['kosong']){
    $c17p=0.25;
    $p=$p+1;
  }
}
while($rowks = mysqli_fetch_assoc($kspadi)){
  if($kedalamansulfidik == $rowks['s1']){
    $c18p=1;
  }elseif($kedalamansulfidik == $rowks['s2']){
    $c18p=0.75;
  }elseif($kedalamansulfidik == $rowks['s3']){
    $c18p=0.5;
  }elseif($kedalamansulfidik == $rowks['n']){
    $c18p=0.25;
  }elseif($kedalamansulfidik == $rowks['kosong']){
    $c18p=0.25;
    $p=$p+1;
  }
}
while($rowler = mysqli_fetch_assoc($lerpadi)){
  if($lereng == $rowler['s1']){
    $c19p=1;
  }elseif($lereng == $rowler['s2']){
    $c19p=0.75;
  }elseif($lereng == $rowler['s3']){
    $c19p=0.5;
  }elseif($lereng == $rowler['n']){
    $c19p=0.25;
  }elseif($lereng == $rowler['kosong']){
    $c19p=0.25;
    $p=$p+1;
  }
}
while($rowbe = mysqli_fetch_assoc($bepadi)){
  if($bahayaerosi == $rowbe['s1']){
    $c20p=1;
  }elseif($bahayaerosi == $rowbe['s2']){
    $c20p=0.75;
  }elseif($bahayaerosi == $rowbe['s3']){
    $c20p=0.5;
  }elseif($bahayaerosi == $rowbe['n']){
    $c20p=0.25;
  }elseif($bahayaerosi == $rowbe['kosong']){
    $c20p=0.25;
    $p=$p+1;
  }
}
while($rowtb = mysqli_fetch_assoc($tbpadi)){
  if($tinggigenangan == $rowtb['s1']){
    $c21p=1;
  }elseif($tinggigenangan == $rowtb['s2']){
    $c21p=0.75;
  }elseif($tinggigenangan == $rowtb['s3']){
    $c21p=0.5;
  }elseif($tinggigenangan == $rowtb['n']){
    $c21p=0.25;
  }elseif($tinggigenangan == $rowtb['kosong']){
    $c21p=0.25;
    $p=$p+1;
  }
}
while($rowlb = mysqli_fetch_assoc($lbpadi)){
  if($lamagenangan == $rowlb['s1']){
    $c22p=1;
  }elseif($lamagenangan == $rowlb['s2']){
    $c22p=0.75;
  }elseif($lamagenangan == $rowlb['s3']){
    $c22p=0.5;
  }elseif($lamagenangan == $rowlb['n']){
    $c22p=0.25;
  }elseif($lamagenangan == $rowlb['kosong']){
    $c22p=0.25;
    $p=$p+1;
  }
}
while($rowbatu = mysqli_fetch_assoc($batupadi)){
  if($batuan == $rowbatu['s1']){
    $c23p=1;
  }elseif($batuan == $rowbatu['s2']){
    $c23p=0.75;
  }elseif($batuan == $rowbatu['s3']){
    $c23p=0.5;
  }elseif($batuan == $rowbatu['n']){
    $c23p=0.25;
  }elseif($batuan == $rowbatu['kosong']){
    $c23p=0.25;
    $p=$p+1;
  }
}
while($rowsing = mysqli_fetch_assoc($singpadi)){
  if($singkapan == $rowsing['s1']){
    $c24p=1;
  }elseif($singkapan == $rowsing['s2']){
    $c24p=0.75;
  }elseif($singkapan == $rowsing['s3']){
    $c24p=0.5;
  }elseif($singkapan == $rowsing['n']){
    $c24p=0.25;
  }elseif($singkapan == $rowsing['kosong']){
    $c24p=0.25;
    $p=$p+1;
  }
}
while($rowcht = mysqli_fetch_assoc($chtpadi)){
  if($curahhujan == $rowcht['s1']){
    $c25p=1; 
  }elseif($curahhujan == $rowcht['s2']){
    $c25p=0.75; 
  }elseif($curahhujan == $rowcht['s3']){
    $c25p=0.5;
  }elseif($curahhujan == $rowcht['n']){
    $c25p=0.25;
  }elseif($curahhujan == $rowcht['kosong']){
    $c25p=0.25;
    $p=$p+1;
  }
}

$kl = 25-$p;
$kln = ($kl/25);
$kelengkapan = $kln * 100;

$x=0;
//Jagung
while($rowtemp2 = mysqli_fetch_assoc($tempjagung)){
  if($temperatur == $rowtemp2['s1']){
    $c1j=1;
  }elseif($temperatur == $rowtemp2['s2']){
    $c1j=0.75;
  }elseif($temperatur == $rowtemp2['s3']){
    $c1j=0.5;
  }elseif($temperatur == $rowtemp2['n']){
    $c1j=0.25;
  }elseif($temperatur == $rowtemp2['kosong']){
    $c1j=0.25;
  }
}
while($rowka2 = mysqli_fetch_assoc($kajagung)){
  if($ketersediaanair == $rowka2['s1']){
    $c2j=1;
  }elseif($ketersediaanair == $rowka2['s2']){
    $c2j=0.75;
  }elseif($ketersediaanair == $rowka2['s3']){
    $c2j=0.5;
  }elseif($ketersediaanair == $rowka2['n']){
    $c2j=0.25;
  }elseif($ketersediaanair == $rowka2['kosong']){
    $c2j=0.25;
  }
}
while($rowdrain2 = mysqli_fetch_assoc($drainjagung)){
  if($drainase == $rowdrain2['s1']){
    $c3j=1;
  }elseif($drainase == $rowdrain2['s2']){
    $c3j=0.75;
  }elseif($drainase == $rowdrain2['s3']){
    $c3j=0.5;
  }elseif($drainase == $rowdrain2['n']){
    $c3j=0.25;
  }elseif($drainase == $rowdrain2['kosong']){
    $c3j=0.25;
  }
}
while($rowteks2 = mysqli_fetch_assoc($teksjagung)){
  if($tekstur == $rowteks2['s1']){
    $c4j=1;
  }elseif($tekstur == $rowteks2['s2']){
    $c4j=0.75;
  }elseif($tekstur == $rowteks2['s3']){
    $c4j=0.5;
  }elseif($tekstur == $rowteks2['n']){
    $c4j=0.25;
  }elseif($tekstur == $rowteks2['kosong']){
    $c4j=0.25;
  }
}
while($rowbk2 = mysqli_fetch_assoc($bkjagung)){
  if($bahankasar == $rowbk2['s1']){
    $c5j=1;
  }elseif($bahankasar == $rowbk2['s2']){
    $c5j=0.75;
  }elseif($bahankasar == $rowbk2['s3']){
    $c5j=0.5;
  }elseif($bahankasar == $rowbk2['n']){
    $c5j=0.25;
  }elseif($bahankasar == $rowbk2['kosong']){
    $c5j=0.25;
  }
}
while($rowkt2 = mysqli_fetch_assoc($ktjagung)){
  if($kedalamantanah == $rowkt2['s1']){
    $c6j=1;
  }elseif($kedalamantanah == $rowkt2['s2']){
    $c6j=0.75;
  }elseif($kedalamantanah == $rowkt2['s3']){
    $c6j=0.5;
  }elseif($kedalamantanah == $rowkt2['n']){
    $c6j=0.25;
  }elseif($kedalamantanah == $rowkt2['kosong']){
    $c6j=0.25;
  }
}
while($rowkg2 = mysqli_fetch_assoc($kgjagung)){
  if($ketebalangambut == $rowkg2['s1']){
    $c7j=1;
  }elseif($ketebalangambut == $rowkg2['s2']){
    $c7j=0.75;
  }elseif($ketebalangambut == $rowkg2['s3']){
    $c7j=0.5;
  }elseif($ketebalangambut == $rowkg2['n']){
    $c7j=0.25;
  }elseif($ketebalangambut == $rowkg2['kosong']){
    $c7j=0.25;
  }
}
while($rowktg2 = mysqli_fetch_assoc($ktgjagung)){
  if($kematangan == $rowktg2['s1']){
    $c8j=1;
  }elseif($kematangan == $rowktg2['s2']){
    $c8j=0.75;
  }elseif($kematangan == $rowktg2['s3']){
    $c8j=0.5;
  }elseif($kematangan == $rowktg2['n']){
    $c8j=0.25;
  }elseif($kematangan == $rowktg2['kosong']){
    $c8j=0.25;
  }
}
while($rowktk2 = mysqli_fetch_assoc($ktkjagung)){
  if($ktktanah == $rowktk2['s1']){
    $c9j=1;
  }elseif($ktktanah == $rowktk2['s2']){
    $c9j=0.75;
  }elseif($ktktanah == $rowktk2['s3']){
    $c9j=0.5;
  }elseif($ktktanah == $rowktk2['n']){
    $c9j=0.25;
  }elseif($ktktanah == $rowktk2['kosong']){
    $c9j=0.25;
  }
}
while($rowkb2 = mysqli_fetch_assoc($kbjagung)){
  if($kejenuhanbasa == $rowkb2['s1']){
    $c10j=1;
  }elseif($kejenuhanbasa == $rowkb2['s2']){
    $c10j=0.75;
  }elseif($kejenuhanbasa == $rowkb2['s3']){
    $c10j=0.5;
  }elseif($kejenuhanbasa == $rowkb2['n']){
    $c10j=0.25;
  }elseif($kejenuhanbasa == $rowkb2['kosong']){
    $c10j=0.25;
  }
}
while($rowph2 = mysqli_fetch_assoc($phjagung)){
  if($phh2o == $rowph2['s1']){
    $c11j=1;
  }elseif($phh2o == $rowph2['s2']){
    $c11j=0.75;
  }elseif($phh2o == $rowph2['s3']){
    $c11j=0.5;
  }elseif($phh2o == $rowph2['n']){
    $c11j=0.25;
  }elseif($phh2o == $rowph2['kosong']){
    $c11j=0.25;
  }
}
while($rowcorg2 = mysqli_fetch_assoc($corgjagung)){
  if($corganik == $rowcorg2['s1']){
    $c12j=1;
  }elseif($corganik == $rowcorg2['s2']){
    $c12j=0.75;
  }elseif($corganik == $rowcorg2['s3']){
    $c12j=0.5;
  }elseif($corganik == $rowcorg2['n']){
    $c12j=0.25;
  }elseif($corganik == $rowcorg2['kosong']){
    $c12j=0.25;
  }
}
while($rowntotal2 = mysqli_fetch_assoc($ntotaljagung)){
  if($ntotal == $rowntotal2['s1']){
    $c13j=1;
  }elseif($ntotal == $rowntotal2['s2']){
    $c13j=0.75;
  }elseif($ntotal == $rowntotal2['s3']){
    $c13j=0.5;
  }elseif($ntotal == $rowntotal2['n']){
    $c13j=0.25;
  }elseif($ntotal == $rowntotal2['kosong']){
    $c13j=0.25;
  }
}
while($rowp22 = mysqli_fetch_assoc($p2jagung)){
  if($p2o5 == $rowp22['s1']){
    $c14j=1;
  }elseif($p2o5 == $rowp22['s2']){
    $c14j=0.75;
  }elseif($p2o5 == $rowp22['s3']){
    $c14j=0.5;
  }elseif($p2o5 == $rowp22['n']){
    $c14j=0.25;
  }elseif($p2o5 == $rowp22['kosong']){
    $c14j=0.25;
  }
}
while($rowk22 = mysqli_fetch_assoc($k2jagung)){
  if($k2o == $rowk22['s1']){
    $c15j=1;
  }elseif($k2o == $rowk22['s2']){
    $c15j=0.75;
  }elseif($k2o == $rowk22['s3']){
    $c15j=0.5;
  }elseif($k2o == $rowk22['n']){
    $c15j=0.25;
  }elseif($k2o == $rowk22['kosong']){
    $c15j=0.25;
  }
}
while($rowsali2 = mysqli_fetch_assoc($salijagung)){
  if($salinitas == $rowsali2['s1']){
    $c16j=1;
  }elseif($salinitas == $rowsali2['s2']){
    $c16j=0.75;
  }elseif($salinitas == $rowsali2['s3']){
    $c16j=0.5;
  }elseif($salinitas == $rowsali2['n']){
    $c16j=0.25;
  }elseif($salinitas == $rowsali2['kosong']){
    $c16j=0.25;
  }
}
while($rowalkali2 = mysqli_fetch_assoc($alkalijagung)){
  if($alkalinitas == $rowalkali2['s1']){
    $c17j=1;
  }elseif($alkalinitas == $rowalkali2['s2']){
    $c17j=0.75;
  }elseif($alkalinitas == $rowalkali2['s3']){
    $c17j=0.5;
  }elseif($alkalinitas == $rowalkali2['n']){
    $c17j=0.25;
  }elseif($alkalinitas == $rowalkali2['kosong']){
    $c17j=0.25;
  }
}
while($rowks2 = mysqli_fetch_assoc($ksjagung)){
  if($kedalamansulfidik == $rowks2['s1']){
    $c18j=1;
  }elseif($kedalamansulfidik == $rowks2['s2']){
    $c18j=0.75;
  }elseif($kedalamansulfidik == $rowks2['s3']){
    $c18j=0.5;
  }elseif($kedalamansulfidik == $rowks2['n']){
    $c18j=0.25;
  }elseif($kedalamansulfidik == $rowks2['kosong']){
    $c18j=0.25;
  }
}
while($rowler2 = mysqli_fetch_assoc($lerjagung)){
  if($lereng == $rowler2['s1']){
    $c19j=1;
  }elseif($lereng == $rowler2['s2']){
    $c19j=0.75;
  }elseif($lereng == $rowler2['s3']){
    $c19j=0.5;
  }elseif($lereng == $rowler2['n']){
    $c19j=0.25;
  }elseif($lereng == $rowler2['kosong']){
    $c19j=0.25;
  }
}
while($rowbe2 = mysqli_fetch_assoc($bejagung)){
  if($bahayaerosi == $rowbe2['s1']){
    $c20j=1;
  }elseif($bahayaerosi == $rowbe2['s2']){
    $c20j=0.75;
  }elseif($bahayaerosi == $rowbe2['s3']){
    $c20j=0.5;
  }elseif($bahayaerosi == $rowbe2['n']){
    $c20j=0.25;
  }elseif($bahayaerosi == $rowbe2['kosong']){
    $c20j=0.25;
  }
}
while($rowtb2 = mysqli_fetch_assoc($tbjagung)){
  if($tinggigenangan == $rowtb2['s1']){
    $c21j=1;
  }elseif($tinggigenangan == $rowtb2['s2']){
    $c21j=0.75;
  }elseif($tinggigenangan == $rowtb2['s3']){
    $c21j=0.5;
  }elseif($tinggigenangan == $rowtb2['n']){
    $c21j=0.25;
  }elseif($tinggigenangan == $rowtb2['kosong']){
    $c21j=0.25;
  }
}
while($rowlb2 = mysqli_fetch_assoc($lbjagung)){
  if($lamagenangan == $rowlb2['s1']){
    $c22j=1;
  }elseif($lamagenangan == $rowlb2['s2']){
    $c22j=0.75;
  }elseif($lamagenangan == $rowlb2['s3']){
    $c22j=0.5;
  }elseif($lamagenangan == $rowlb2['n']){
    $c22j=0.25;
  }elseif($lamagenangan == $rowlb2['kosong']){
    $c22j=0.25;
  }
}
while($rowbatu2 = mysqli_fetch_assoc($batujagung)){
  if($batuan == $rowbatu2['s1']){
    $c23j=1;
  }elseif($batuan == $rowbatu2['s2']){
    $c23j=0.75;
  }elseif($batuan == $rowbatu2['s3']){
    $c23j=0.5;
  }elseif($batuan == $rowbatu2['n']){
    $c23j=0.25;
  }elseif($batuan == $rowbatu2['kosong']){
    $c23j=0.25;
  }
}
while($rowsing2 = mysqli_fetch_assoc($singjagung)){
  if($singkapan == $rowsing2['s1']){
    $c24j=1;
  }elseif($singkapan == $rowsing2['s2']){
    $c24j=0.75;
  }elseif($singkapan == $rowsing2['s3']){
    $c24j=0.5;
  }elseif($singkapan == $rowsing2['n']){
    $c24j=0.25;
  }elseif($singkapan == $rowsing2['kosong']){
    $c24j=0.25;
  }
}
while($rowcht2 = mysqli_fetch_assoc($chtjagung)){
  if($curahhujan == $rowcht2['s1']){
    $c25j=1; 
  }elseif($curahhujan == $rowcht2['s2']){
    $c25j=0.75; 
  }elseif($curahhujan == $rowcht2['s3']){
    $c25j=0.5;
  }elseif($curahhujan == $rowcht2['n']){
    $c25j=0.25;
  }elseif($curahhujan == $rowcht2['kosong']){
    $c25j=0.25;
  }
}




//Kedelai
while($rowtemp3 = mysqli_fetch_assoc($tempkedelai)){
  if($temperatur == $rowtemp3['s1']){
    $c1k=1;
  }elseif($temperatur == $rowtemp3['s2']){
    $c1k=0.75;
  }elseif($temperatur == $rowtemp3['s3']){
    $c1k=0.5;
  }elseif($temperatur == $rowtemp3['n']){
    $c1k=0.25;
  }elseif($temperatur == $rowtemp3['kosong']){
    $c1k=0.25;
  }
}
while($rowka3 = mysqli_fetch_assoc($kakedelai)){
  if($ketersediaanair == $rowka3['s1']){
    $c2k=1;
  }elseif($ketersediaanair == $rowka3['s2']){
    $c2k=0.75;
  }elseif($ketersediaanair == $rowka3['s3']){
    $c2k=0.5;
  }elseif($ketersediaanair == $rowka3['n']){
    $c2k=0.25;
  }elseif($ketersediaanair == $rowka3['kosong']){
    $c2k=0.25;
  }
}
while($rowdrain3 = mysqli_fetch_assoc($drainkedelai)){
  if($drainase == $rowdrain3['s1']){
    $c3k=1;
  }elseif($drainase == $rowdrain3['s2']){
    $c3k=0.75;
  }elseif($drainase == $rowdrain3['s3']){
    $c3k=0.5;
  }elseif($drainase == $rowdrain3['n']){
    $c3k=0.25;
  }elseif($drainase == $rowdrain3['kosong']){
    $c3k=0.25;
  }
}
while($rowteks3 = mysqli_fetch_assoc($tekskedelai)){
  if($tekstur == $rowteks3['s1']){
    $c4k=1;
  }elseif($tekstur == $rowteks3['s2']){
    $c4k=0.75;
  }elseif($tekstur == $rowteks3['s3']){
    $c4k=0.5;
  }elseif($tekstur == $rowteks3['n']){
    $c4k=0.25;
  }elseif($tekstur == $rowteks3['kosong']){
    $c4k=0.25;
  }
}
while($rowbk3 = mysqli_fetch_assoc($bkkedelai)){
  if($bahankasar == $rowbk3['s1']){
    $c5k=1;
  }elseif($bahankasar == $rowbk3['s2']){
    $c5k=0.75;
  }elseif($bahankasar == $rowbk3['s3']){
    $c5k=0.5;
  }elseif($bahankasar == $rowbk3['n']){
    $c5k=0.25;
  }elseif($bahankasar == $rowbk3['kosong']){
    $c5k=0.25;
  }
}
while($rowkt3 = mysqli_fetch_assoc($ktkedelai)){
  if($kedalamantanah == $rowkt3['s1']){
    $c6k=1;
  }elseif($kedalamantanah == $rowkt3['s2']){
    $c6k=0.75;
  }elseif($kedalamantanah == $rowkt3['s3']){
    $c6k=0.5;
  }elseif($kedalamantanah == $rowkt3['n']){
    $c6k=0.25;
  }elseif($kedalamantanah == $rowkt3['kosong']){
    $c6k=0.25;
  }
}
while($rowkg3 = mysqli_fetch_assoc($kgkedelai)){
  if($ketebalangambut == $rowkg3['s1']){
    $c7k=1;
  }elseif($ketebalangambut == $rowkg3['s2']){
    $c7k=0.75;
  }elseif($ketebalangambut == $rowkg3['s3']){
    $c7k=0.5;
  }elseif($ketebalangambut == $rowkg3['n']){
    $c7k=0.25;
  }elseif($ketebalangambut == $rowkg3['kosong']){
    $c7k=0.25;
  }
}
while($rowktg3 = mysqli_fetch_assoc($ktgkedelai)){
  if($kematangan == $rowktg3['s1']){
    $c8k=1;
  }elseif($kematangan == $rowktg3['s2']){
    $c8k=0.75;
  }elseif($kematangan == $rowktg3['s3']){
    $c8k=0.5;
  }elseif($kematangan == $rowktg3['n']){
    $c8k=0.25;
  }elseif($kematangan == $rowktg3['kosong']){
    $c8k=0.25;
  }
}
while($rowktk3 = mysqli_fetch_assoc($ktkkedelai)){
  if($ktktanah == $rowktk3['s1']){
    $c9k=1;
  }elseif($ktktanah == $rowktk3['s2']){
    $c9k=0.75;
  }elseif($ktktanah == $rowktk3['s3']){
    $c9k=0.5;
  }elseif($ktktanah == $rowktk3['n']){
    $c9k=0.25;
  }elseif($ktktanah == $rowktk3['kosong']){
    $c9k=0.25;
  }
}
while($rowkb3 = mysqli_fetch_assoc($kbkedelai)){
  if($kejenuhanbasa == $rowkb3['s1']){
    $c10k=1;
  }elseif($kejenuhanbasa == $rowkb3['s2']){
    $c10k=0.75;
  }elseif($kejenuhanbasa == $rowkb3['s3']){
    $c10k=0.5;
  }elseif($kejenuhanbasa == $rowkb3['n']){
    $c10k=0.25;
  }elseif($kejenuhanbasa == $rowkb3['kosong']){
    $c10k=0.25;
  }
}
while($rowph3 = mysqli_fetch_assoc($phkedelai)){
  if($phh2o == $rowph3['s1']){
    $c11k=1;
  }elseif($phh2o == $rowph3['s2']){
    $c11k=0.75;
  }elseif($phh2o == $rowph3['s3']){
    $c11k=0.5;
  }elseif($phh2o == $rowph3['n']){
    $c11k=0.25;
  }elseif($phh2o == $rowph3['kosong']){
    $c11k=0.25;
  }
}
while($rowcorg3 = mysqli_fetch_assoc($corgkedelai)){
  if($corganik == $rowcorg3['s1']){
    $c12k=1;
  }elseif($corganik == $rowcorg3['s2']){
    $c12k=0.75;
  }elseif($corganik == $rowcorg3['s3']){
    $c12k=0.5;
  }elseif($corganik == $rowcorg3['n']){
    $c12k=0.25;
  }elseif($corganik == $rowcorg3['kosong']){
    $c12k=0.25;
  }
}
while($rowntotal3 = mysqli_fetch_assoc($ntotalkedelai)){
  if($ntotal == $rowntotal3['s1']){
    $c13k=1;
  }elseif($ntotal == $rowntotal3['s2']){
    $c13k=0.75;
  }elseif($ntotal == $rowntotal3['s3']){
    $c13k=0.5;
  }elseif($ntotal == $rowntotal3['n']){
    $c13k=0.25;
  }elseif($ntotal == $rowntotal3['kosong']){
    $c13k=0.25;
  }
}
while($rowp23 = mysqli_fetch_assoc($p2kedelai)){
  if($p2o5 == $rowp23['s1']){
    $c14k=1;
  }elseif($p2o5 == $rowp23['s2']){
    $c14k=0.75;
  }elseif($p2o5 == $rowp23['s3']){
    $c14k=0.5;
  }elseif($p2o5 == $rowp23['n']){
    $c14k=0.25;
  }elseif($p2o5 == $rowp23['kosong']){
    $c14k=0.25;
  }
}
while($rowk23 = mysqli_fetch_assoc($k2kedelai)){
  if($k2o == $rowk23['s1']){
    $c15k=1;
  }elseif($k2o == $rowk23['s2']){
    $c15k=0.75;
  }elseif($k2o == $rowk23['s3']){
    $c15k=0.5;
  }elseif($k2o == $rowk23['n']){
    $c15k=0.25;
  }elseif($k2o == $rowk23['kosong']){
    $c15k=0.25;
  }
}
while($rowsali3 = mysqli_fetch_assoc($salikedelai)){
  if($salinitas == $rowsali3['s1']){
    $c16k=1;
  }elseif($salinitas == $rowsali3['s2']){
    $c16k=0.75;
  }elseif($salinitas == $rowsali3['s3']){
    $c16k=0.5;
  }elseif($salinitas == $rowsali3['n']){
    $c16k=0.25;
  }elseif($salinitas == $rowsali3['kosong']){
    $c16k=0.25;
  }
}
while($rowalkali3 = mysqli_fetch_assoc($alkalikedelai)){
  if($alkalinitas == $rowalkali3['s1']){
    $c17k=1;
  }elseif($alkalinitas == $rowalkali3['s2']){
    $c17k=0.75;
  }elseif($alkalinitas == $rowalkali3['s3']){
    $c17k=0.5;
  }elseif($alkalinitas == $rowalkali3['n']){
    $c17k=0.25;
  }elseif($alkalinitas == $rowalkali3['kosong']){
    $c17k=0.25;
  }
}
while($rowks3 = mysqli_fetch_assoc($kskedelai)){
  if($kedalamansulfidik == $rowks3['s1']){
    $c18k=1;
  }elseif($kedalamansulfidik == $rowks3['s2']){
    $c18k=0.75;
  }elseif($kedalamansulfidik == $rowks3['s3']){
    $c18k=0.5;
  }elseif($kedalamansulfidik == $rowks3['n']){
    $c18k=0.25;
  }elseif($kedalamansulfidik == $rowks3['kosong']){
    $c18k=0.25;
  }
}
while($rowler3 = mysqli_fetch_assoc($lerkedelai)){
  if($lereng == $rowler3['s1']){
    $c19k=1;
  }elseif($lereng == $rowler3['s2']){
    $c19k=0.75;
  }elseif($lereng == $rowler3['s3']){
    $c19k=0.5;
  }elseif($lereng == $rowler3['n']){
    $c19k=0.25;
  }elseif($lereng == $rowler3['kosong']){
    $c19k=0.25;
  }
}
while($rowbe3 = mysqli_fetch_assoc($bekedelai)){
  if($bahayaerosi == $rowbe3['s1']){
    $c20k=1;
  }elseif($bahayaerosi == $rowbe3['s2']){
    $c20k=0.75;
  }elseif($bahayaerosi == $rowbe3['s3']){
    $c20k=0.5;
  }elseif($bahayaerosi == $rowbe3['n']){
    $c20k=0.25;
  }elseif($bahayaerosi == $rowbe3['kosong']){
    $c20k=0.25;
  }
}
while($rowtb3 = mysqli_fetch_assoc($tbkedelai)){
  if($tinggigenangan == $rowtb3['s1']){
    $c21k=1;
  }elseif($tinggigenangan == $rowtb3['s2']){
    $c21k=0.75;
  }elseif($tinggigenangan == $rowtb3['s3']){
    $c21k=0.5;
  }elseif($tinggigenangan == $rowtb3['n']){
    $c21k=0.25;
  }elseif($tinggigenangan == $rowtb3['kosong']){
    $c21k=0.25;
  }
}
while($rowlb3 = mysqli_fetch_assoc($lbkedelai)){
  if($lamagenangan == $rowlb3['s1']){
    $c22k=1;
  }elseif($lamagenangan == $rowlb3['s2']){
    $c22k=0.75;
  }elseif($lamagenangan == $rowlb3['s3']){
    $c22k=0.5;
  }elseif($lamagenangan == $rowlb3['n']){
    $c22k=0.25;
  }elseif($lamagenangan == $rowlb3['kosong']){
    $c22k=0.25;
  }
}
while($rowbatu3 = mysqli_fetch_assoc($batukedelai)){
  if($batuan == $rowbatu3['s1']){
    $c23k=1;
  }elseif($batuan == $rowbatu3['s2']){
    $c23k=0.75;
  }elseif($batuan == $rowbatu3['s3']){
    $c23k=0.5;
  }elseif($batuan == $rowbatu3['n']){
    $c23k=0.25;
  }elseif($batuan == $rowbatu3['kosong']){
    $c23k=0.25;
  }
}
while($rowsing3 = mysqli_fetch_assoc($singkedelai)){
  if($singkapan == $rowsing3['s1']){
    $c24k=1;
  }elseif($singkapan == $rowsing3['s2']){
    $c24k=0.75;
  }elseif($singkapan == $rowsing3['s3']){
    $c24k=0.5;
  }elseif($singkapan == $rowsing3['n']){
    $c24k=0.25;
  }elseif($singkapan == $rowsing3['kosong']){
    $c24k=0.25;
  }
}
while($rowcht3 = mysqli_fetch_assoc($chtkedelai)){
  if($curahhujan == $rowcht3['s1']){
    $c25k=1; 
  }elseif($curahhujan == $rowcht3['s2']){
    $c25k=0.75; 
  }elseif($curahhujan == $rowcht3['s3']){
    $c25k=0.5;
  }elseif($curahhujan == $rowcht3['n']){
    $c25k=0.25;
  }elseif($curahhujan == $rowcht3['kosong']){
    $c25k=0.25;
  }
}


//PADISTH
while($rowtemp4 = mysqli_fetch_assoc($temppadisth)){
  if($temperatur == $rowtemp4['s1']){
    $c1psth=1;
  }elseif($temperatur == $rowtemp4['s2']){
    $c1psth=0.75;
  }elseif($temperatur == $rowtemp4['s3']){
    $c1psth=0.5;
  }elseif($temperatur == $rowtemp4['n']){
    $c1psth=0.25;
  }elseif($temperatur == $rowtemp4['kosong']){
    $c1psth=0.25;
  }
}
while($rowka4 = mysqli_fetch_assoc($kapadisth)){
  if($ketersediaanair == $rowka4['s1']){
    $c2psth=1;
  }elseif($ketersediaanair == $rowka4['s2']){
    $c2psth=0.75;
  }elseif($ketersediaanair == $rowka4['s3']){
    $c2psth=0.5;
  }elseif($ketersediaanair == $rowka4['n']){
    $c2psth=0.25;
  }elseif($ketersediaanair == $rowka4['kosong']){
    $c2psth=0.25;
  }
}
while($rowdrain4 = mysqli_fetch_assoc($drainpadisth)){
  if($drainase == $rowdrain4['s1']){
    $c3psth=1;
  }elseif($drainase == $rowdrain4['s2']){
    $c3psth=0.75;
  }elseif($drainase == $rowdrain4['s3']){
    $c3psth=0.5;
  }elseif($drainase == $rowdrain4['n']){
    $c3psth=0.25;
  }elseif($drainase == $rowdrain4['kosong']){
    $c3psth=0.25;
  }
}
while($rowteks4 = mysqli_fetch_assoc($tekspadisth)){
  if($tekstur == $rowteks4['s1']){
    $c4psth=1;
  }elseif($tekstur == $rowteks4['s2']){
    $c4psth=0.75;
  }elseif($tekstur == $rowteks4['s3']){
    $c4psth=0.5;
  }elseif($tekstur == $rowteks4['n']){
    $c4psth=0.25;
  }elseif($tekstur == $rowteks4['kosong']){
    $c4psth=0.25;
  }
}
while($rowbk4 = mysqli_fetch_assoc($bkpadisth)){
  if($bahankasar == $rowbk4['s1']){
    $c5psth=1;
  }elseif($bahankasar == $rowbk4['s2']){
    $c5psth=0.75;
  }elseif($bahankasar == $rowbk4['s3']){
    $c5psth=0.5;
  }elseif($bahankasar == $rowbk4['n']){
    $c5psth=0.25;
  }elseif($bahankasar == $rowbk4['kosong']){
    $c5psth=0.25;
  }
}
while($rowkt4 = mysqli_fetch_assoc($ktpadisth)){
  if($kedalamantanah == $rowkt4['s1']){
    $c6psth=1;
  }elseif($kedalamantanah == $rowkt4['s2']){
    $c6psth=0.75;
  }elseif($kedalamantanah == $rowkt4['s3']){
    $c6psth=0.5;
  }elseif($kedalamantanah == $rowkt4['n']){
    $c6psth=0.25;
  }elseif($kedalamantanah == $rowkt4['kosong']){
    $c6psth=0.25;
  }
}
while($rowkg4 = mysqli_fetch_assoc($kgpadisth)){
  if($ketebalangambut == $rowkg4['s1']){
    $c7psth=1;
  }elseif($ketebalangambut == $rowkg4['s2']){
    $c7psth=0.75;
  }elseif($ketebalangambut == $rowkg4['s3']){
    $c7psth=0.5;
  }elseif($ketebalangambut == $rowkg4['n']){
    $c7psth=0.25;
  }elseif($ketebalangambut == $rowkg4['kosong']){
    $c7psth=0.25;
  }
}
while($rowktg4 = mysqli_fetch_assoc($ktgpadisth)){
  if($kematangan == $rowktg4['s1']){
    $c8psth=1;
  }elseif($kematangan == $rowktg4['s2']){
    $c8psth=0.75;
  }elseif($kematangan == $rowktg4['s3']){
    $c8psth=0.5;
  }elseif($kematangan == $rowktg4['n']){
    $c8psth=0.25;
  }elseif($kematangan == $rowktg4['kosong']){
    $c8psth=0.25;
  }
}
while($rowktk4 = mysqli_fetch_assoc($ktkpadisth)){
  if($ktktanah == $rowktk4['s1']){
    $c9psth=1;
  }elseif($ktktanah == $rowktk4['s2']){
    $c9psth=0.75;
  }elseif($ktktanah == $rowktk4['s3']){
    $c9psth=0.5;
  }elseif($ktktanah == $rowktk4['n']){
    $c9psth=0.25;
  }elseif($ktktanah == $rowktk4['kosong']){
    $c9psth=0.25;
  }
}
while($rowkb4 = mysqli_fetch_assoc($kbpadisth)){
  if($kejenuhanbasa == $rowkb4['s1']){
    $c10psth=1;
  }elseif($kejenuhanbasa == $rowkb4['s2']){
    $c10psth=0.75;
  }elseif($kejenuhanbasa == $rowkb4['s3']){
    $c10psth=0.5;
  }elseif($kejenuhanbasa == $rowkb4['n']){
    $c10psth=0.25;
  }elseif($kejenuhanbasa == $rowkb4['kosong']){
    $c10psth=0.25;
  }
}
while($rowph4 = mysqli_fetch_assoc($phpadisth)){
  if($phh2o == $rowph4['s1']){
    $c11psth=1;
  }elseif($phh2o == $rowph4['s2']){
    $c11psth=0.75;
  }elseif($phh2o == $rowph4['s3']){
    $c11psth=0.5;
  }elseif($phh2o == $rowph4['n']){
    $c11psth=0.25;
  }elseif($phh2o == $rowph4['kosong']){
    $c11psth=0.25;
  }
}
while($rowcorg4 = mysqli_fetch_assoc($corgpadisth)){
  if($corganik == $rowcorg4['s1']){
    $c12psth=1;
  }elseif($corganik == $rowcorg4['s2']){
    $c12psth=0.75;
  }elseif($corganik == $rowcorg4['s3']){
    $c12psth=0.5;
  }elseif($corganik == $rowcorg4['n']){
    $c12psth=0.25;
  }elseif($corganik == $rowcorg4['kosong']){
    $c12psth=0.25;
  }
}
while($rowntotal4 = mysqli_fetch_assoc($ntotalpadisth)){
  if($ntotal == $rowntotal4['s1']){
    $c13psth=1;
  }elseif($ntotal == $rowntotal4['s2']){
    $c13psth=0.75;
  }elseif($ntotal == $rowntotal4['s3']){
    $c13psth=0.5;
  }elseif($ntotal == $rowntotal4['n']){
    $c13psth=0.25;
  }elseif($ntotal == $rowntotal4['kosong']){
    $c13psth=0.25;
  }
}
while($rowp24 = mysqli_fetch_assoc($p2padisth)){
  if($p2o5 == $rowp24['s1']){
    $c14psth=1;
  }elseif($p2o5 == $rowp24['s2']){
    $c14psth=0.75;
  }elseif($p2o5 == $rowp24['s3']){
    $c14psth=0.5;
  }elseif($p2o5 == $rowp24['n']){
    $c14psth=0.25;
  }elseif($p2o5 == $rowp24['kosong']){
    $c14psth=0.25;
  }
}
while($rowk24 = mysqli_fetch_assoc($k2padisth)){
  if($k2o == $rowk24['s1']){
    $c15psth=1;
  }elseif($k2o == $rowk24['s2']){
    $c15psth=0.75;
  }elseif($k2o == $rowk24['s3']){
    $c15psth=0.5;
  }elseif($k2o == $rowk24['n']){
    $c15psth=0.25;
  }elseif($k2o == $rowk24['kosong']){
    $c15psth=0.25;
  }
}
while($rowsali4 = mysqli_fetch_assoc($salipadisth)){
  if($salinitas == $rowsali4['s1']){
    $c16psth=1;
  }elseif($salinitas == $rowsali4['s2']){
    $c16psth=0.75;
  }elseif($salinitas == $rowsali4['s3']){
    $c16psth=0.5;
  }elseif($salinitas == $rowsali4['n']){
    $c16psth=0.25;
  }elseif($salinitas == $rowsali4['kosong']){
    $c16psth=0.25;
  }
}
while($rowalkali4 = mysqli_fetch_assoc($alkalipadisth)){
  if($alkalinitas == $rowalkali4['s1']){
    $c17psth=1;
  }elseif($alkalinitas == $rowalkali4['s2']){
    $c17psth=0.75;
  }elseif($alkalinitas == $rowalkali4['s3']){
    $c17psth=0.5;
  }elseif($alkalinitas == $rowalkali4['n']){
    $c17psth=0.25;
  }elseif($alkalinitas == $rowalkali4['kosong']){
    $c17psth=0.25;
  }
}
while($rowks4 = mysqli_fetch_assoc($kspadisth)){
  if($kedalamansulfidik == $rowks4['s1']){
    $c18psth=1;
  }elseif($kedalamansulfidik == $rowks4['s2']){
    $c18psth=0.75;
  }elseif($kedalamansulfidik == $rowks4['s3']){
    $c18psth=0.5;
  }elseif($kedalamansulfidik == $rowks4['n']){
    $c18psth=0.25;
  }elseif($kedalamansulfidik == $rowks4['kosong']){
    $c18psth=0.25;
  }
}
while($rowler4 = mysqli_fetch_assoc($lerpadisth)){
  if($lereng == $rowler4['s1']){
    $c19psth=1;
  }elseif($lereng == $rowler4['s2']){
    $c19psth=0.75;
  }elseif($lereng == $rowler4['s3']){
    $c19psth=0.5;
  }elseif($lereng == $rowler4['n']){
    $c19psth=0.25;
  }elseif($lereng == $rowler4['kosong']){
    $c19psth=0.25;
  }
}
while($rowbe4 = mysqli_fetch_assoc($bepadisth)){
  if($bahayaerosi == $rowbe4['s1']){
    $c20psth=1;
  }elseif($bahayaerosi == $rowbe4['s2']){
    $c20psth=0.75;
  }elseif($bahayaerosi == $rowbe4['s3']){
    $c20psth=0.5;
  }elseif($bahayaerosi == $rowbe4['n']){
    $c20psth=0.25;
  }elseif($bahayaerosi == $rowbe4['kosong']){
    $c20psth=0.25;
  }
}
while($rowtb = mysqli_fetch_assoc($tbpadisth)){
  if($tinggigenangan == $rowtb['s1']){
    $c21psth=1;
  }elseif($tinggigenangan == $rowtb['s2']){
    $c21psth=0.75;
  }elseif($tinggigenangan == $rowtb['s3']){
    $c21psth=0.5;
  }elseif($tinggigenangan == $rowtb['n']){
    $c21psth=0.25;
  }elseif($tinggigenangan == $rowtb['kosong']){
    $c21psth=0.25;
  }
}
while($rowlb4 = mysqli_fetch_assoc($lbpadisth)){
  if($lamagenangan == $rowlb4['s1']){
    $c22psth=1;
  }elseif($lamagenangan == $rowlb4['s2']){
    $c22psth=0.75;
  }elseif($lamagenangan == $rowlb4['s3']){
    $c22psth=0.5;
  }elseif($lamagenangan == $rowlb4['n']){
    $c22psth=0.25;
  }elseif($lamagenangan == $rowlb4['kosong']){
    $c22psth=0.25;
  }
}
while($rowbatu4 = mysqli_fetch_assoc($batupadisth)){
  if($batuan == $rowbatu4['s1']){
    $c23psth=1;
  }elseif($batuan == $rowbatu4['s2']){
    $c23psth=0.75;
  }elseif($batuan == $rowbatu4['s3']){
    $c23psth=0.5;
  }elseif($batuan == $rowbatu4['n']){
    $c23psth=0.25;
  }elseif($batuan == $rowbatu4['kosong']){
    $c23psth=0.25;
  }
}
while($rowsing4 = mysqli_fetch_assoc($singpadisth)){
  if($singkapan == $rowsing4['s1']){
    $c24psth=1;
  }elseif($singkapan == $rowsing4['s2']){
    $c24psth=0.75;
  }elseif($singkapan == $rowsing4['s3']){
    $c24psth=0.5;
  }elseif($singkapan == $rowsing4['n']){
    $c24psth=0.25;
  }elseif($singkapan == $rowsing4['kosong']){
    $c24psth=0.25;
  }
}
while($rowcht4 = mysqli_fetch_assoc($chtpadisth)){
  if($curahhujan == $rowcht4['s1']){
    $c25psth=1; 
  }elseif($curahhujan == $rowcht4['s2']){
    $c25psth=0.75; 
  }elseif($curahhujan == $rowcht4['s3']){
    $c25psth=0.5;
  }elseif($curahhujan == $rowcht4['n']){
    $c25psth=0.25;
  }elseif($curahhujan == $rowcht4['kosong']){
    $c25psth=0.25;
  }
}


//PADI GOGO
while($rowtemp5 = mysqli_fetch_assoc($temppadigogo)){
  if($temperatur == $rowtemp5['s1']){
    $c1pgogo=1;
  }elseif($temperatur == $rowtemp5['s2']){
    $c1pgogo=0.75;
  }elseif($temperatur == $rowtemp5['s3']){
    $c1pgogo=0.5;
  }elseif($temperatur == $rowtemp5['n']){
    $c1pgogo=0.25;
  }elseif($temperatur == $rowtemp5['kosong']){
    $c1pgogo=0.25;
  }
}
while($rowka5 = mysqli_fetch_assoc($kapadigogo)){
  if($ketersediaanair == $rowka5['s1']){
    $c2pgogo=1;
  }elseif($ketersediaanair == $rowka5['s2']){
    $c2pgogo=0.75;
  }elseif($ketersediaanair == $rowka5['s3']){
    $c2pgogo=0.5;
  }elseif($ketersediaanair == $rowka5['n']){
    $c2pgogo=0.25;
  }elseif($ketersediaanair == $rowka5['kosong']){
    $c2pgogo=0.25;
  }
}
while($rowdrain5 = mysqli_fetch_assoc($drainpadigogo)){
  if($drainase == $rowdrain5['s1']){
    $c3pgogo=1;
  }elseif($drainase == $rowdrain5['s2']){
    $c3pgogo=0.75;
  }elseif($drainase == $rowdrain5['s3']){
    $c3pgogo=0.5;
  }elseif($drainase == $rowdrain5['n']){
    $c3pgogo=0.25;
  }elseif($drainase == $rowdrain5['kosong']){
    $c3pgogo=0.25;
  }
}
while($rowteks5 = mysqli_fetch_assoc($tekspadigogo)){
  if($tekstur == $rowteks5['s1']){
    $c4pgogo=1;
  }elseif($tekstur == $rowteks5['s2']){
    $c4pgogo=0.75;
  }elseif($tekstur == $rowteks5['s3']){
    $c4pgogo=0.5;
  }elseif($tekstur == $rowteks5['n']){
    $c4pgogo=0.25;
  }elseif($tekstur == $rowteks5['kosong']){
    $c4pgogo=0.25;
  }
}
while($rowbk5 = mysqli_fetch_assoc($bkpadigogo)){
  if($bahankasar == $rowbk5['s1']){
    $c5pgogo=1;
  }elseif($bahankasar == $rowbk5['s2']){
    $c5pgogo=0.75;
  }elseif($bahankasar == $rowbk5['s3']){
    $c5pgogo=0.5;
  }elseif($bahankasar == $rowbk5['n']){
    $c5pgogo=0.25;
  }elseif($bahankasar == $rowbk5['kosong']){
    $c5pgogo=0.25;
  }
}
while($rowkt5 = mysqli_fetch_assoc($ktpadigogo)){
  if($kedalamantanah == $rowkt5['s1']){
    $c6pgogo=1;
  }elseif($kedalamantanah == $rowkt5['s2']){
    $c6pgogo=0.75;
  }elseif($kedalamantanah == $rowkt5['s3']){
    $c6pgogo=0.5;
  }elseif($kedalamantanah == $rowkt5['n']){
    $c6pgogo=0.25;
  }elseif($kedalamantanah == $rowkt5['kosong']){
    $c6pgogo=0.25;
  }
}
while($rowkg5 = mysqli_fetch_assoc($kgpadigogo)){
  if($ketebalangambut == $rowkg5['s1']){
    $c7pgogo=1;
  }elseif($ketebalangambut == $rowkg5['s2']){
    $c7pgogo=0.75;
  }elseif($ketebalangambut == $rowkg5['s3']){
    $c7pgogo=0.5;
  }elseif($ketebalangambut == $rowkg5['n']){
    $c7pgogo=0.25;
  }elseif($ketebalangambut == $rowkg5['kosong']){
    $c7pgogo=0.25;
  }
}
while($rowktg5 = mysqli_fetch_assoc($ktgpadigogo)){
  if($kematangan == $rowktg5['s1']){
    $c8pgogo=1;
  }elseif($kematangan == $rowktg5['s2']){
    $c8pgogo=0.75;
  }elseif($kematangan == $rowktg5['s3']){
    $c8pgogo=0.5;
  }elseif($kematangan == $rowktg5['n']){
    $c8pgogo=0.25;
  }elseif($kematangan == $rowktg5['kosong']){
    $c8pgogo=0.25;
  }
}
while($rowktk5 = mysqli_fetch_assoc($ktkpadigogo)){
  if($ktktanah == $rowktk5['s1']){
    $c9pgogo=1;
  }elseif($ktktanah == $rowktk5['s2']){
    $c9pgogo=0.75;
  }elseif($ktktanah == $rowktk5['s3']){
    $c9pgogo=0.5;
  }elseif($ktktanah == $rowktk5['n']){
    $c9pgogo=0.25;
  }elseif($ktktanah == $rowktk5['kosong']){
    $c9pgogo=0.25;
  }
}
while($rowkb5 = mysqli_fetch_assoc($kbpadigogo)){
  if($kejenuhanbasa == $rowkb5['s1']){
    $c10pgogo=1;
  }elseif($kejenuhanbasa == $rowkb5['s2']){
    $c10pgogo=0.75;
  }elseif($kejenuhanbasa == $rowkb5['s3']){
    $c10pgogo=0.5;
  }elseif($kejenuhanbasa == $rowkb5['n']){
    $c10pgogo=0.25;
  }elseif($kejenuhanbasa == $rowkb5['kosong']){
    $c10pgogo=0.25;
  }
}
while($rowph5 = mysqli_fetch_assoc($phpadigogo)){
  if($phh2o == $rowph5['s1']){
    $c11pgogo=1;
  }elseif($phh2o == $rowph5['s2']){
    $c11pgogo=0.75;
  }elseif($phh2o == $rowph5['s3']){
    $c11pgogo=0.5;
  }elseif($phh2o == $rowph5['n']){
    $c11pgogo=0.25;
  }elseif($phh2o == $rowph5['kosong']){
    $c11pgogo=0.25;
  }
}
while($rowcorg5 = mysqli_fetch_assoc($corgpadigogo)){
  if($corganik == $rowcorg5['s1']){
    $c12pgogo=1;
  }elseif($corganik == $rowcorg5['s2']){
    $c12pgogo=0.75;
  }elseif($corganik == $rowcorg5['s3']){
    $c12pgogo=0.5;
  }elseif($corganik == $rowcorg5['n']){
    $c12pgogo=0.25;
  }elseif($corganik == $rowcorg5['kosong']){
    $c12pgogo=0.25;
  }
}
while($rowntotal5 = mysqli_fetch_assoc($ntotalpadigogo)){
  if($ntotal == $rowntotal5['s1']){
    $c13pgogo=1;
  }elseif($ntotal == $rowntotal5['s2']){
    $c13pgogo=0.75;
  }elseif($ntotal == $rowntotal5['s3']){
    $c13pgogo=0.5;
  }elseif($ntotal == $rowntotal5['n']){
    $c13pgogo=0.25;
  }elseif($ntotal == $rowntotal5['kosong']){
    $c13pgogo=0.25;
  }
}
while($rowp25 = mysqli_fetch_assoc($p2padigogo)){
  if($p2o5 == $rowp25['s1']){
    $c14pgogo=1;
  }elseif($p2o5 == $rowp25['s2']){
    $c14pgogo=0.75;
  }elseif($p2o5 == $rowp25['s3']){
    $c14pgogo=0.5;
  }elseif($p2o5 == $rowp25['n']){
    $c14pgogo=0.25;
  }elseif($p2o5 == $rowp25['kosong']){
    $c14pgogo=0.25;
  }
}
while($rowk25 = mysqli_fetch_assoc($k2padigogo)){
  if($k2o == $rowk25['s1']){
    $c15pgogo=1;
  }elseif($k2o == $rowk25['s2']){
    $c15pgogo=0.75;
  }elseif($k2o == $rowk25['s3']){
    $c15pgogo=0.5;
  }elseif($k2o == $rowk25['n']){
    $c15pgogo=0.25;
  }elseif($k2o == $rowk25['kosong']){
    $c15pgogo=0.25;
  }
}
while($rowsali5 = mysqli_fetch_assoc($salipadigogo)){
  if($salinitas == $rowsali5['s1']){
    $c16pgogo=1;
  }elseif($salinitas == $rowsali5['s2']){
    $c16pgogo=0.75;
  }elseif($salinitas == $rowsali5['s3']){
    $c16pgogo=0.5;
  }elseif($salinitas == $rowsali5['n']){
    $c16pgogo=0.25;
  }elseif($salinitas == $rowsali5['kosong']){
    $c16pgogo=0.25;
  }
}
while($rowalkali5 = mysqli_fetch_assoc($alkalipadigogo)){
  if($alkalinitas == $rowalkali5['s1']){
    $c17pgogo=1;
  }elseif($alkalinitas == $rowalkali5['s2']){
    $c17pgogo=0.75;
  }elseif($alkalinitas == $rowalkali5['s3']){
    $c17pgogo=0.5;
  }elseif($alkalinitas == $rowalkali5['n']){
    $c17pgogo=0.25;
  }elseif($alkalinitas == $rowalkali5['kosong']){
    $c17pgogo=0.25;
  }
}
while($rowks5 = mysqli_fetch_assoc($kspadigogo)){
  if($kedalamansulfidik == $rowks5['s1']){
    $c18pgogo=1;
  }elseif($kedalamansulfidik == $rowks5['s2']){
    $c18pgogo=0.75;
  }elseif($kedalamansulfidik == $rowks5['s3']){
    $c18pgogo=0.5;
  }elseif($kedalamansulfidik == $rowks5['n']){
    $c18pgogo=0.25;
  }elseif($kedalamansulfidik == $rowks5['kosong']){
    $c18pgogo=0.25;
  }
}
while($rowler5 = mysqli_fetch_assoc($lerpadigogo)){
  if($lereng == $rowler5['s1']){
    $c19pgogo=1;
  }elseif($lereng == $rowler5['s2']){
    $c19pgogo=0.75;
  }elseif($lereng == $rowler5['s3']){
    $c19pgogo=0.5;
  }elseif($lereng == $rowler5['n']){
    $c19pgogo=0.25;
  }elseif($lereng == $rowler5['kosong']){
    $c19pgogo=0.25;
  }
}
while($rowbe5 = mysqli_fetch_assoc($bepadigogo)){
  if($bahayaerosi == $rowbe5['s1']){
    $c20pgogo=1;
  }elseif($bahayaerosi == $rowbe5['s2']){
    $c20pgogo=0.75;
  }elseif($bahayaerosi == $rowbe5['s3']){
    $c20pgogo=0.5;
  }elseif($bahayaerosi == $rowbe5['n']){
    $c20pgogo=0.25;
  }elseif($bahayaerosi == $rowbe5['kosong']){
    $c20pgogo=0.25;
  }
}
while($rowtb5 = mysqli_fetch_assoc($tbpadigogo)){
  if($tinggigenangan == $rowtb5['s1']){
    $c21pgogo=1;
  }elseif($tinggigenangan == $rowtb5['s2']){
    $c21pgogo=0.75;
  }elseif($tinggigenangan == $rowtb5['s3']){
    $c21pgogo=0.5;
  }elseif($tinggigenangan == $rowtb5['n']){
    $c21pgogo=0.25;
  }elseif($tinggigenangan == $rowtb5['kosong']){
    $c21pgogo=0.25;
  }
}
while($rowlb5 = mysqli_fetch_assoc($lbpadigogo)){
  if($lamagenangan == $rowlb5['s1']){
    $c22pgogo=1;
  }elseif($lamagenangan == $rowlb5['s2']){
    $c22pgogo=0.75;
  }elseif($lamagenangan == $rowlb5['s3']){
    $c22pgogo=0.5;
  }elseif($lamagenangan == $rowlb5['n']){
    $c22pgogo=0.25;
  }elseif($lamagenangan == $rowlb5['kosong']){
    $c22pgogo=0.25;
  }
}
while($rowbatu5 = mysqli_fetch_assoc($batupadigogo)){
  if($batuan == $rowbatu5['s1']){
    $c23pgogo=1;
  }elseif($batuan == $rowbatu5['s2']){
    $c23pgogo=0.75;
  }elseif($batuan == $rowbatu5['s3']){
    $c23pgogo=0.5;
  }elseif($batuan == $rowbatu5['n']){
    $c23pgogo=0.25;
  }elseif($batuan == $rowbatu5['kosong']){
    $c23pgogo=0.25;
  }
}
while($rowsing5 = mysqli_fetch_assoc($singpadigogo)){
  if($singkapan == $rowsing5['s1']){
    $c24pgogo=1;
  }elseif($singkapan == $rowsing5['s2']){
    $c24pgogo=0.75;
  }elseif($singkapan == $rowsing5['s3']){
    $c24pgogo=0.5;
  }elseif($singkapan == $rowsing5['n']){
    $c24pgogo=0.25;
  }elseif($singkapan == $rowsing5['kosong']){
    $c24pgogo=0.25;
  }
}
while($rowcht5 = mysqli_fetch_assoc($chtpadigogo)){
  if($curahhujan == $rowcht5['s1']){
    $c25pgogo=1; 
  }elseif($curahhujan == $rowcht5['s2']){
    $c25pgogo=0.75; 
  }elseif($curahhujan == $rowcht5['s3']){
    $c25pgogo=0.5;
  }elseif($curahhujan == $rowcht5['n']){
    $c25pgogo=0.25;
  }elseif($curahhujan == $rowcht5['kosong']){
    $c25pgogo=0.25;
  }
}


//PADI SRPS
while($rowtemp6 = mysqli_fetch_assoc($temppadisrps)){
  if($temperatur == $rowtemp6['s1']){
    $c1psrps=1;
  }elseif($temperatur == $rowtemp6['s2']){
    $c1psrps=0.75;
  }elseif($temperatur == $rowtemp6['s3']){
    $c1psrps=0.5;
  }elseif($temperatur == $rowtemp6['n']){
    $c1psrps=0.25;
  }elseif($temperatur == $rowtemp6['kosong']){
    $c1psrps=0.25;
  }
}
while($rowka6 = mysqli_fetch_assoc($kapadisrps)){
  if($ketersediaanair == $rowka6['s1']){
    $c2psrps=1;
  }elseif($ketersediaanair == $rowka6['s2']){
    $c2psrps=0.75;
  }elseif($ketersediaanair == $rowka6['s3']){
    $c2psrps=0.5;
  }elseif($ketersediaanair == $rowka6['n']){
    $c2psrps=0.25;
  }elseif($ketersediaanair == $rowka6['kosong']){
    $c2psrps=0.25;
  }
}
while($rowdrain6 = mysqli_fetch_assoc($drainpadisrps)){
  if($drainase == $rowdrain6['s1']){
    $c3psrps=1;
  }elseif($drainase == $rowdrain6['s2']){
    $c3psrps=0.75;
  }elseif($drainase == $rowdrain6['s3']){
    $c3psrps=0.5;
  }elseif($drainase == $rowdrain6['n']){
    $c3psrps=0.25;
  }elseif($drainase == $rowdrain6['kosong']){
    $c3psrps=0.25;
  }
}
while($rowteks6 = mysqli_fetch_assoc($tekspadisrps)){
  if($tekstur == $rowteks6['s1']){
    $c4psrps=1;
  }elseif($tekstur == $rowteks6['s2']){
    $c4psrps=0.75;
  }elseif($tekstur == $rowteks6['s3']){
    $c4psrps=0.5;
  }elseif($tekstur == $rowteks6['n']){
    $c4psrps=0.25;
  }elseif($tekstur == $rowteks6['kosong']){
    $c4psrps=0.25;
  }
}
while($rowbk6 = mysqli_fetch_assoc($bkpadisrps)){
  if($bahankasar == $rowbk6['s1']){
    $c5psrps=1;
  }elseif($bahankasar == $rowbk6['s2']){
    $c5psrps=0.75;
  }elseif($bahankasar == $rowbk6['s3']){
    $c5psrps=0.5;
  }elseif($bahankasar == $rowbk6['n']){
    $c5psrps=0.25;
  }elseif($bahankasar == $rowbk6['kosong']){
    $c5psrps=0.25;
  }
}
while($rowkt6 = mysqli_fetch_assoc($ktpadisrps)){
  if($kedalamantanah == $rowkt6['s1']){
    $c6psrps=1;
  }elseif($kedalamantanah == $rowkt6['s2']){
    $c6psrps=0.75;
  }elseif($kedalamantanah == $rowkt6['s3']){
    $c6psrps=0.5;
  }elseif($kedalamantanah == $rowkt6['n']){
    $c6psrps=0.25;
  }elseif($kedalamantanah == $rowkt6['kosong']){
    $c6psrps=0.25;
  }
}
while($rowkg6 = mysqli_fetch_assoc($kgpadisrps)){
  if($ketebalangambut == $rowkg6['s1']){
    $c7psrps=1;
  }elseif($ketebalangambut == $rowkg6['s2']){
    $c7psrps=0.75;
  }elseif($ketebalangambut == $rowkg6['s3']){
    $c7psrps=0.5;
  }elseif($ketebalangambut == $rowkg6['n']){
    $c7psrps=0.25;
  }elseif($ketebalangambut == $rowkg6['kosong']){
    $c7psrps=0.25;
  }
}
while($rowktg6 = mysqli_fetch_assoc($ktgpadisrps)){
  if($kematangan == $rowktg6['s1']){
    $c8psrps=1;
  }elseif($kematangan == $rowktg6['s2']){
    $c8psrps=0.75;
  }elseif($kematangan == $rowktg6['s3']){
    $c8psrps=0.5;
  }elseif($kematangan == $rowktg6['n']){
    $c8psrps=0.25;
  }elseif($kematangan == $rowktg6['kosong']){
    $c8psrps=0.25;
  }
}
while($rowktk6 = mysqli_fetch_assoc($ktkpadisrps)){
  if($ktktanah == $rowktk6['s1']){
    $c9psrps=1;
  }elseif($ktktanah == $rowktk6['s2']){
    $c9psrps=0.75;
  }elseif($ktktanah == $rowktk6['s3']){
    $c9psrps=0.5;
  }elseif($ktktanah == $rowktk6['n']){
    $c9psrps=0.25;
  }elseif($ktktanah == $rowktk6['kosong']){
    $c9psrps=0.25;
  }
}
while($rowkb6 = mysqli_fetch_assoc($kbpadisrps)){
  if($kejenuhanbasa == $rowkb6['s1']){
    $c10psrps=1;
  }elseif($kejenuhanbasa == $rowkb6['s2']){
    $c10psrps=0.75;
  }elseif($kejenuhanbasa == $rowkb6['s3']){
    $c10psrps=0.5;
  }elseif($kejenuhanbasa == $rowkb6['n']){
    $c10psrps=0.25;
  }elseif($kejenuhanbasa == $rowkb6['kosong']){
    $c10psrps=0.25;
  }
}
while($rowph6 = mysqli_fetch_assoc($phpadisrps)){
  if($phh2o == $rowph6['s1']){
    $c11psrps=1;
  }elseif($phh2o == $rowph6['s2']){
    $c11psrps=0.75;
  }elseif($phh2o == $rowph6['s3']){
    $c11psrps=0.5;
  }elseif($phh2o == $rowph6['n']){
    $c11psrps=0.25;
  }elseif($phh2o == $rowph6['kosong']){
    $c11psrps=0.25;
  }
}
while($rowcorg6 = mysqli_fetch_assoc($corgpadisrps)){
  if($corganik == $rowcorg6['s1']){
    $c12psrps=1;
  }elseif($corganik == $rowcorg6['s2']){
    $c12psrps=0.75;
  }elseif($corganik == $rowcorg6['s3']){
    $c12psrps=0.5;
  }elseif($corganik == $rowcorg6['n']){
    $c12psrps=0.25;
  }elseif($corganik == $rowcorg6['kosong']){
    $c12psrps=0.25;
  }
}
while($rowntotal6 = mysqli_fetch_assoc($ntotalpadisrps)){
  if($ntotal == $rowntotal6['s1']){
    $c13psrps=1;
  }elseif($ntotal == $rowntotal6['s2']){
    $c13psrps=0.75;
  }elseif($ntotal == $rowntotal6['s3']){
    $c13psrps=0.5;
  }elseif($ntotal == $rowntotal6['n']){
    $c13psrps=0.25;
  }elseif($ntotal == $rowntotal6['kosong']){
    $c13psrps=0.25;
  }
}
while($rowp26 = mysqli_fetch_assoc($p2padisrps)){
  if($p2o5 == $rowp26['s1']){
    $c14psrps=1;
  }elseif($p2o5 == $rowp26['s2']){
    $c14psrps=0.75;
  }elseif($p2o5 == $rowp26['s3']){
    $c14psrps=0.5;
  }elseif($p2o5 == $rowp26['n']){
    $c14psrps=0.25;
  }elseif($p2o5 == $rowp26['kosong']){
    $c14psrps=0.25;
  }
}
while($rowk26 = mysqli_fetch_assoc($k2padisrps)){
  if($k2o == $rowk26['s1']){
    $c15psrps=1;
  }elseif($k2o == $rowk26['s2']){
    $c15psrps=0.75;
  }elseif($k2o == $rowk26['s3']){
    $c15psrps=0.5;
  }elseif($k2o == $rowk26['n']){
    $c15psrps=0.25;
  }elseif($k2o == $rowk26['kosong']){
    $c15psrps=0.25;
  }
}
while($rowsali6 = mysqli_fetch_assoc($salipadisrps)){
  if($salinitas == $rowsali6['s1']){
    $c16psrps=1;
  }elseif($salinitas == $rowsali6['s2']){
    $c16psrps=0.75;
  }elseif($salinitas == $rowsali6['s3']){
    $c16psrps=0.5;
  }elseif($salinitas == $rowsali6['n']){
    $c16psrps=0.25;
  }elseif($salinitas == $rowsali6['kosong']){
    $c16psrps=0.25;
  }
}
while($rowalkali6 = mysqli_fetch_assoc($alkalipadisrps)){
  if($alkalinitas == $rowalkali6['s1']){
    $c17psrps=1;
  }elseif($alkalinitas == $rowalkali6['s2']){
    $c17psrps=0.75;
  }elseif($alkalinitas == $rowalkali6['s3']){
    $c17psrps=0.5;
  }elseif($alkalinitas == $rowalkali6['n']){
    $c17psrps=0.25;
  }elseif($alkalinitas == $rowalkali6['kosong']){
    $c17psrps=0.25;
  }
}
while($rowks6 = mysqli_fetch_assoc($kspadisrps)){
  if($kedalamansulfidik == $rowks6['s1']){
    $c18psrps=1;
  }elseif($kedalamansulfidik == $rowks6['s2']){
    $c18psrps=0.75;
  }elseif($kedalamansulfidik == $rowks6['s3']){
    $c18psrps=0.5;
  }elseif($kedalamansulfidik == $rowks6['n']){
    $c18psrps=0.25;
  }elseif($kedalamansulfidik == $rowks6['kosong']){
    $c18psrps=0.25;
  }
}
while($rowler6 = mysqli_fetch_assoc($lerpadisrps)){
  if($lereng == $rowler6['s1']){
    $c19psrps=1;
  }elseif($lereng == $rowler6['s2']){
    $c19psrps=0.75;
  }elseif($lereng == $rowler6['s3']){
    $c19psrps=0.5;
  }elseif($lereng == $rowler6['n']){
    $c19psrps=0.25;
  }elseif($lereng == $rowler6['kosong']){
    $c19psrps=0.25;
  }
}
while($rowbe6 = mysqli_fetch_assoc($bepadisrps)){
  if($bahayaerosi == $rowbe6['s1']){
    $c20psrps=1;
  }elseif($bahayaerosi == $rowbe6['s2']){
    $c20psrps=0.75;
  }elseif($bahayaerosi == $rowbe6['s3']){
    $c20psrps=0.5;
  }elseif($bahayaerosi == $rowbe6['n']){
    $c20psrps=0.25;
  }elseif($bahayaerosi == $rowbe6['kosong']){
    $c20psrps=0.25;
  }
}
while($rowtb6 = mysqli_fetch_assoc($tbpadisrps)){
  if($tinggigenangan == $rowtb6['s1']){
    $c21psrps=1;
  }elseif($tinggigenangan == $rowtb6['s2']){
    $c21psrps=0.75;
  }elseif($tinggigenangan == $rowtb6['s3']){
    $c21psrps=0.5;
  }elseif($tinggigenangan == $rowtb6['n']){
    $c21psrps=0.25;
  }elseif($tinggigenangan == $rowtb6['kosong']){
    $c21psrps=0.25;
  }
}
while($rowlb6 = mysqli_fetch_assoc($lbpadisrps)){
  if($lamagenangan == $rowlb6['s1']){
    $c22psrps=1;
  }elseif($lamagenangan == $rowlb6['s2']){
    $c22psrps=0.75;
  }elseif($lamagenangan == $rowlb6['s3']){
    $c22psrps=0.5;
  }elseif($lamagenangan == $rowlb6['n']){
    $c22psrps=0.25;
  }elseif($lamagenangan == $rowlb6['kosong']){
    $c22psrps=0.25;
  }
}
while($rowbatu6 = mysqli_fetch_assoc($batupadisrps)){
  if($batuan == $rowbatu6['s1']){
    $c23psrps=1;
  }elseif($batuan == $rowbatu6['s2']){
    $c23psrps=0.75;
  }elseif($batuan == $rowbatu6['s3']){
    $c23psrps=0.5;
  }elseif($batuan == $rowbatu6['n']){
    $c23psrps=0.25;
  }elseif($batuan == $rowbatu6['kosong']){
    $c23psrps=0.25;
  }
}
while($rowsing6 = mysqli_fetch_assoc($singpadisrps)){
  if($singkapan == $rowsing6['s1']){
    $c24psrps=1;
  }elseif($singkapan == $rowsing6['s2']){
    $c24psrps=0.75;
  }elseif($singkapan == $rowsing6['s3']){
    $c24psrps=0.5;
  }elseif($singkapan == $rowsing6['n']){
    $c24psrps=0.25;
  }elseif($singkapan == $rowsing6['kosong']){
    $c24psrps=0.25;
  }
}
while($rowcht6 = mysqli_fetch_assoc($chtpadisrps)){
  if($curahhujan == $rowcht6['s1']){
    $c25psrps=1; 
  }elseif($curahhujan == $rowcht6['s2']){
    $c25psrps=0.75; 
  }elseif($curahhujan == $rowcht6['s3']){
    $c25psrps=0.5;
  }elseif($curahhujan == $rowcht6['n']){
    $c25psrps=0.25;
  }elseif($curahhujan == $rowcht6['kosong']){
    $c25psrps=0.25;
  }
}


//PADI SRL
while($rowtemp7 = mysqli_fetch_assoc($temppadisrl)){
  if($temperatur == $rowtemp7['s1']){
    $c1psrl=1;
  }elseif($temperatur == $rowtemp7['s2']){
    $c1psrl=0.75;
  }elseif($temperatur == $rowtemp7['s3']){
    $c1psrl=0.5;
  }elseif($temperatur == $rowtemp7['n']){
    $c1psrl=0.25;
  }elseif($temperatur == $rowtemp7['kosong']){
    $c1psrl=0.25;
  }
}
while($rowka7 = mysqli_fetch_assoc($kapadisrl)){
  if($ketersediaanair == $rowka7['s1']){
    $c2psrl=1;
  }elseif($ketersediaanair == $rowka7['s2']){
    $c2psrl=0.75;
  }elseif($ketersediaanair == $rowka7['s3']){
    $c2psrl=0.5;
  }elseif($ketersediaanair == $rowka7['n']){
    $c2psrl=0.25;
  }elseif($ketersediaanair == $rowka7['kosong']){
    $c2psrl=0.25;
  }
}
while($rowdrain7 = mysqli_fetch_assoc($drainpadisrl)){
  if($drainase == $rowdrain7['s1']){
    $c3psrl=1;
  }elseif($drainase == $rowdrain7['s2']){
    $c3psrl=0.75;
  }elseif($drainase == $rowdrain7['s3']){
    $c3psrl=0.5;
  }elseif($drainase == $rowdrain7['n']){
    $c3psrl=0.25;
  }elseif($drainase == $rowdrain7['kosong']){
    $c3psrl=0.25;
  }
}
while($rowteks7 = mysqli_fetch_assoc($tekspadisrl)){
  if($tekstur == $rowteks7['s1']){
    $c4psrl=1;
  }elseif($tekstur == $rowteks7['s2']){
    $c4psrl=0.75;
  }elseif($tekstur == $rowteks7['s3']){
    $c4psrl=0.5;
  }elseif($tekstur == $rowteks7['n']){
    $c4psrl=0.25;
  }elseif($tekstur == $rowteks7['kosong']){
    $c4psrl=0.25;
  }
}
while($rowbk7 = mysqli_fetch_assoc($bkpadisrl)){
  if($bahankasar == $rowbk7['s1']){
    $c5psrl=1;
  }elseif($bahankasar == $rowbk7['s2']){
    $c5psrl=0.75;
  }elseif($bahankasar == $rowbk7['s3']){
    $c5psrl=0.5;
  }elseif($bahankasar == $rowbk7['n']){
    $c5psrl=0.25;
  }elseif($bahankasar == $rowbk7['kosong']){
    $c5psrl=0.25;
  }
}
while($rowkt7 = mysqli_fetch_assoc($ktpadisrl)){
  if($kedalamantanah == $rowkt7['s1']){
    $c6psrl=1;
  }elseif($kedalamantanah == $rowkt7['s2']){
    $c6psrl=0.75;
  }elseif($kedalamantanah == $rowkt7['s3']){
    $c6psrl=0.5;
  }elseif($kedalamantanah == $rowkt7['n']){
    $c6psrl=0.25;
  }elseif($kedalamantanah == $rowkt7['kosong']){
    $c6psrl=0.25;
  }
}
while($rowkg7 = mysqli_fetch_assoc($kgpadisrl)){
  if($ketebalangambut == $rowkg7['s1']){
    $c7psrl=1;
  }elseif($ketebalangambut == $rowkg7['s2']){
    $c7psrl=0.75;
  }elseif($ketebalangambut == $rowkg7['s3']){
    $c7psrl=0.5;
  }elseif($ketebalangambut == $rowkg7['n']){
    $c7psrl=0.25;
  }elseif($ketebalangambut == $rowkg7['kosong']){
    $c7psrl=0.25;
  }
}
while($rowktg7 = mysqli_fetch_assoc($ktgpadisrl)){
  if($kematangan == $rowktg7['s1']){
    $c8psrl=1;
  }elseif($kematangan == $rowktg7['s2']){
    $c8psrl=0.75;
  }elseif($kematangan == $rowktg7['s3']){
    $c8psrl=0.5;
  }elseif($kematangan == $rowktg7['n']){
    $c8psrl=0.25;
  }elseif($kematangan == $rowktg7['kosong']){
    $c8psrl=0.25;
  }
}
while($rowktk7 = mysqli_fetch_assoc($ktkpadisrl)){
  if($ktktanah == $rowktk7['s1']){
    $c9psrl=1;
  }elseif($ktktanah == $rowktk7['s2']){
    $c9psrl=0.75;
  }elseif($ktktanah == $rowktk7['s3']){
    $c9psrl=0.5;
  }elseif($ktktanah == $rowktk7['n']){
    $c9psrl=0.25;
  }elseif($ktktanah == $rowktk7['kosong']){
    $c9psrl=0.25;
  }
}
while($rowkb7 = mysqli_fetch_assoc($kbpadisrl)){
  if($kejenuhanbasa == $rowkb7['s1']){
    $c10psrl=1;
  }elseif($kejenuhanbasa == $rowkb7['s2']){
    $c10psrl=0.75;
  }elseif($kejenuhanbasa == $rowkb7['s3']){
    $c10psrl=0.5;
  }elseif($kejenuhanbasa == $rowkb7['n']){
    $c10psrl=0.25;
  }elseif($kejenuhanbasa == $rowkb7['kosong']){
    $c10psrl=0.25;
  }
}
while($rowph7 = mysqli_fetch_assoc($phpadisrl)){
  if($phh2o == $rowph7['s1']){
    $c11psrl=1;
  }elseif($phh2o == $rowph7['s2']){
    $c11psrl=0.75;
  }elseif($phh2o == $rowph7['s3']){
    $c11psrl=0.5;
  }elseif($phh2o == $rowph7['n']){
    $c11psrl=0.25;
  }elseif($phh2o == $rowph7['kosong']){
    $c11psrl=0.25;
  }
}
while($rowcorg7 = mysqli_fetch_assoc($corgpadisrl)){
  if($corganik == $rowcorg7['s1']){
    $c12psrl=1;
  }elseif($corganik == $rowcorg7['s2']){
    $c12psrl=0.75;
  }elseif($corganik == $rowcorg7['s3']){
    $c12psrl=0.5;
  }elseif($corganik == $rowcorg7['n']){
    $c12psrl=0.25;
  }elseif($corganik == $rowcorg7['kosong']){
    $c12psrl=0.25;
  }
}
while($rowntotal7 = mysqli_fetch_assoc($ntotalpadisrl)){
  if($ntotal == $rowntotal7['s1']){
    $c13psrl=1;
  }elseif($ntotal == $rowntotal7['s2']){
    $c13psrl=0.75;
  }elseif($ntotal == $rowntotal7['s3']){
    $c13psrl=0.5;
  }elseif($ntotal == $rowntotal7['n']){
    $c13psrl=0.25;
  }elseif($ntotal == $rowntotal7['kosong']){
    $c13psrl=0.25;
  }
}
while($rowp27 = mysqli_fetch_assoc($p2padisrl)){
  if($p2o5 == $rowp27['s1']){
    $c14psrl=1;
  }elseif($p2o5 == $rowp27['s2']){
    $c14psrl=0.75;
  }elseif($p2o5 == $rowp27['s3']){
    $c14psrl=0.5;
  }elseif($p2o5 == $rowp27['n']){
    $c14psrl=0.25;
  }elseif($p2o5 == $rowp27['kosong']){
    $c14psrl=0.25;
  }
}
while($rowk27 = mysqli_fetch_assoc($k2padisrl)){
  if($k2o == $rowk27['s1']){
    $c15psrl=1;
  }elseif($k2o == $rowk27['s2']){
    $c15psrl=0.75;
  }elseif($k2o == $rowk27['s3']){
    $c15psrl=0.5;
  }elseif($k2o == $rowk27['n']){
    $c15psrl=0.25;
  }elseif($k2o == $rowk27['kosong']){
    $c15psrl=0.25;
  }
}
while($rowsali7 = mysqli_fetch_assoc($salipadisrl)){
  if($salinitas == $rowsali7['s1']){
    $c16psrl=1;
  }elseif($salinitas == $rowsali7['s2']){
    $c16psrl=0.75;
  }elseif($salinitas == $rowsali7['s3']){
    $c16psrl=0.5;
  }elseif($salinitas == $rowsali7['n']){
    $c16psrl=0.25;
  }elseif($salinitas == $rowsali7['kosong']){
    $c16psrl=0.25;
  }
}
while($rowalkali7 = mysqli_fetch_assoc($alkalipadisrl)){
  if($alkalinitas == $rowalkali7['s1']){
    $c17psrl=1;
  }elseif($alkalinitas == $rowalkali7['s2']){
    $c17psrl=0.75;
  }elseif($alkalinitas == $rowalkali7['s3']){
    $c17psrl=0.5;
  }elseif($alkalinitas == $rowalkali7['n']){
    $c17psrl=0.25;
  }elseif($alkalinitas == $rowalkali7['kosong']){
    $c17psrl=0.25;
  }
}
while($rowks7 = mysqli_fetch_assoc($kspadisrl)){
  if($kedalamansulfidik == $rowks7['s1']){
    $c18psrl=1;
  }elseif($kedalamansulfidik == $rowks7['s2']){
    $c18psrl=0.75;
  }elseif($kedalamansulfidik == $rowks7['s3']){
    $c18psrl=0.5;
  }elseif($kedalamansulfidik == $rowks7['n']){
    $c18psrl=0.25;
  }elseif($kedalamansulfidik == $rowks7['kosong']){
    $c18psrl=0.25;
  }
}
while($rowler7 = mysqli_fetch_assoc($lerpadisrl)){
  if($lereng == $rowler7['s1']){
    $c19psrl=1;
  }elseif($lereng == $rowler7['s2']){
    $c19psrl=0.75;
  }elseif($lereng == $rowler7['s3']){
    $c19psrl=0.5;
  }elseif($lereng == $rowler7['n']){
    $c19psrl=0.25;
  }elseif($lereng == $rowler7['kosong']){
    $c19psrl=0.25;
  }
}
while($rowbe7 = mysqli_fetch_assoc($bepadisrl)){
  if($bahayaerosi == $rowbe7['s1']){
    $c20psrl=1;
  }elseif($bahayaerosi == $rowbe7['s2']){
    $c20psrl=0.75;
  }elseif($bahayaerosi == $rowbe7['s3']){
    $c20psrl=0.5;
  }elseif($bahayaerosi == $rowbe7['n']){
    $c20psrl=0.25;
  }elseif($bahayaerosi == $rowbe7['kosong']){
    $c20psrl=0.25;
  }
}
while($rowtb7 = mysqli_fetch_assoc($tbpadisrl)){
  if($tinggigenangan == $rowtb7['s1']){
    $c21psrl=1;
  }elseif($tinggigenangan == $rowtb7['s2']){
    $c21psrl=0.75;
  }elseif($tinggigenangan == $rowtb7['s3']){
    $c21psrl=0.5;
  }elseif($tinggigenangan == $rowtb7['n']){
    $c21psrl=0.25;
  }elseif($tinggigenangan == $rowtb7['kosong']){
    $c21psrl=0.25;
  }
}
while($rowlb7 = mysqli_fetch_assoc($lbpadisrl)){
  if($lamagenangan == $rowlb7['s1']){
    $c22psrl=1;
  }elseif($lamagenangan == $rowlb7['s2']){
    $c22psrl=0.75;
  }elseif($lamagenangan == $rowlb7['s3']){
    $c22psrl=0.5;
  }elseif($lamagenangan == $rowlb7['n']){
    $c22psrl=0.25;
  }elseif($lamagenangan == $rowlb7['kosong']){
    $c22psrl=0.25;
  }
}
while($rowbatu7 = mysqli_fetch_assoc($batupadisrl)){
  if($batuan == $rowbatu7['s1']){
    $c23psrl=1;
  }elseif($batuan == $rowbatu7['s2']){
    $c23psrl=0.75;
  }elseif($batuan == $rowbatu7['s3']){
    $c23psrl=0.5;
  }elseif($batuan == $rowbatu7['n']){
    $c23psrl=0.25;
  }elseif($batuan == $rowbatu7['kosong']){
    $c23psrl=0.25;
  }
}
while($rowsing7 = mysqli_fetch_assoc($singpadisrl)){
  if($singkapan == $rowsing7['s1']){
    $c24psrl=1;
  }elseif($singkapan == $rowsing7['s2']){
    $c24psrl=0.75;
  }elseif($singkapan == $rowsing7['s3']){
    $c24psrl=0.5;
  }elseif($singkapan == $rowsing7['n']){
    $c24psrl=0.25;
  }elseif($singkapan == $rowsing7['kosong']){
    $c24psrl=0.25;
  }
}
while($rowcht7 = mysqli_fetch_assoc($chtpadisrl)){
  if($curahhujan == $rowcht7['s1']){
    $c25psrl=1; 
  }elseif($curahhujan == $rowcht7['s2']){
    $c25psrl=0.75; 
  }elseif($curahhujan == $rowcht7['s3']){
    $c25psrl=0.5;
  }elseif($curahhujan == $rowcht7['n']){
    $c25psrl=0.25;
  }elseif($curahhujan == $rowcht7['kosong']){
    $c25psrl=0.25;
  }
}


//BAWANG MERAH
while($rowtemp8 = mysqli_fetch_assoc($tempbawang)){
  if($temperatur == $rowtemp8['s1']){
    $c1b=1;
  }elseif($temperatur == $rowtemp8['s2']){
    $c1b=0.75;
  }elseif($temperatur == $rowtemp8['s3']){
    $c1b=0.5;
  }elseif($temperatur == $rowtemp8['n']){
    $c1b=0.25;
  }elseif($temperatur == $rowtemp8['kosong']){
    $c1b=0.25;
  }
}
while($rowka8 = mysqli_fetch_assoc($kabawang)){
  if($ketersediaanair == $rowka8['s1']){
    $c2b=1;
  }elseif($ketersediaanair == $rowka8['s2']){
    $c2b=0.75;
  }elseif($ketersediaanair == $rowka8['s3']){
    $c2b=0.5;
  }elseif($ketersediaanair == $rowka8['n']){
    $c2b=0.25;
  }elseif($ketersediaanair == $rowka8['kosong']){
    $c2b=0.25;
  }
}
while($rowdrain8 = mysqli_fetch_assoc($drainbawang)){
  if($drainase == $rowdrain8['s1']){
    $c3b=1;
  }elseif($drainase == $rowdrain8['s2']){
    $c3b=0.75;
  }elseif($drainase == $rowdrain8['s3']){
    $c3b=0.5;
  }elseif($drainase == $rowdrain8['n']){
    $c3b=0.25;
  }elseif($drainase == $rowdrain8['kosong']){
    $c3b=0.25;
  }
}
while($rowteks8 = mysqli_fetch_assoc($teksbawang)){
  if($tekstur == $rowteks8['s1']){
    $c4b=1;
  }elseif($tekstur == $rowteks8['s2']){
    $c4b=0.75;
  }elseif($tekstur == $rowteks8['s3']){
    $c4b=0.5;
  }elseif($tekstur == $rowteks8['n']){
    $c4b=0.25;
  }elseif($tekstur == $rowteks8['kosong']){
    $c4b=0.25;
  }
}
while($rowbk8 = mysqli_fetch_assoc($bkbawang)){
  if($bahankasar == $rowbk8['s1']){
    $c5b=1;
  }elseif($bahankasar == $rowbk8['s2']){
    $c5b=0.75;
  }elseif($bahankasar == $rowbk8['s3']){
    $c5b=0.5;
  }elseif($bahankasar == $rowbk8['n']){
    $c5b=0.25;
  }elseif($bahankasar == $rowbk8['kosong']){
    $c5b=0.25;
  }
}
while($rowkt8 = mysqli_fetch_assoc($ktbawang)){
  if($kedalamantanah == $rowkt8['s1']){
    $c6b=1;
  }elseif($kedalamantanah == $rowkt8['s2']){
    $c6b=0.75;
  }elseif($kedalamantanah == $rowkt8['s3']){
    $c6b=0.5;
  }elseif($kedalamantanah == $rowkt8['n']){
    $c6b=0.25;
  }elseif($kedalamantanah == $rowkt8['kosong']){
    $c6b=0.25;
  }
}
while($rowkg8 = mysqli_fetch_assoc($kgbawang)){
  if($ketebalangambut == $rowkg8['s1']){
    $c7b=1;
  }elseif($ketebalangambut == $rowkg8['s2']){
    $c7b=0.75;
  }elseif($ketebalangambut == $rowkg8['s3']){
    $c7b=0.5;
  }elseif($ketebalangambut == $rowkg8['n']){
    $c7b=0.25;
  }elseif($ketebalangambut == $rowkg8['kosong']){
    $c7b=0.25;
  }
}
while($rowktg8 = mysqli_fetch_assoc($ktgbawang)){
  if($kematangan == $rowktg8['s1']){
    $c8b=1;
  }elseif($kematangan == $rowktg8['s2']){
    $c8b=0.75;
  }elseif($kematangan == $rowktg8['s3']){
    $c8b=0.5;
  }elseif($kematangan == $rowktg8['n']){
    $c8b=0.25;
  }elseif($kematangan == $rowktg8['kosong']){
    $c8b=0.25;
  }
}
while($rowktk8 = mysqli_fetch_assoc($ktkbawang)){
  if($ktktanah == $rowktk8['s1']){
    $c9b=1;
  }elseif($ktktanah == $rowktk8['s2']){
    $c9b=0.75;
  }elseif($ktktanah == $rowktk8['s3']){
    $c9b=0.5;
  }elseif($ktktanah == $rowktk8['n']){
    $c9b=0.25;
  }elseif($ktktanah == $rowktk8['kosong']){
    $c9b=0.25;
  }
}
while($rowkb8 = mysqli_fetch_assoc($kbbawang)){
  if($kejenuhanbasa == $rowkb8['s1']){
    $c10b=1;
  }elseif($kejenuhanbasa == $rowkb8['s2']){
    $c10b=0.75;
  }elseif($kejenuhanbasa == $rowkb8['s3']){
    $c10b=0.5;
  }elseif($kejenuhanbasa == $rowkb8['n']){
    $c10b=0.25;
  }elseif($kejenuhanbasa == $rowkb8['kosong']){
    $c10b=0.25;
  }
}
while($rowph8 = mysqli_fetch_assoc($phbawang)){
  if($phh2o == $rowph8['s1']){
    $c11b=1;
  }elseif($phh2o == $rowph8['s2']){
    $c11b=0.75;
  }elseif($phh2o == $rowph8['s3']){
    $c11b=0.5;
  }elseif($phh2o == $rowph8['n']){
    $c11b=0.25;
  }elseif($phh2o == $rowph8['kosong']){
    $c11b=0.25;
  }
}
while($rowcorg8 = mysqli_fetch_assoc($corgbawang)){
  if($corganik == $rowcorg8['s1']){
    $c12b=1;
  }elseif($corganik == $rowcorg8['s2']){
    $c12b=0.75;
  }elseif($corganik == $rowcorg8['s3']){
    $c12b=0.5;
  }elseif($corganik == $rowcorg8['n']){
    $c12b=0.25;
  }elseif($corganik == $rowcorg8['kosong']){
    $c12b=0.25;
  }
}
while($rowntotal8 = mysqli_fetch_assoc($ntotalbawang)){
  if($ntotal == $rowntotal8['s1']){
    $c13b=1;
  }elseif($ntotal == $rowntotal8['s2']){
    $c13b=0.75;
  }elseif($ntotal == $rowntotal8['s3']){
    $c13b=0.5;
  }elseif($ntotal == $rowntotal8['n']){
    $c13b=0.25;
  }elseif($ntotal == $rowntotal8['kosong']){
    $c13b=0.25;
  }
}
while($rowp28 = mysqli_fetch_assoc($p2bawang)){
  if($p2o5 == $rowp28['s1']){
    $c14b=1;
  }elseif($p2o5 == $rowp28['s2']){
    $c14b=0.75;
  }elseif($p2o5 == $rowp28['s3']){
    $c14b=0.5;
  }elseif($p2o5 == $rowp28['n']){
    $c14b=0.25;
  }elseif($p2o5 == $rowp28['kosong']){
    $c14b=0.25;
  }
}
while($rowk28 = mysqli_fetch_assoc($k2bawang)){
  if($k2o == $rowk28['s1']){
    $c15b=1;
  }elseif($k2o == $rowk28['s2']){
    $c15b=0.75;
  }elseif($k2o == $rowk28['s3']){
    $c15b=0.5;
  }elseif($k2o == $rowk28['n']){
    $c15b=0.25;
  }elseif($k2o == $rowk28['kosong']){
    $c15b=0.25;
  }
}
while($rowsali8 = mysqli_fetch_assoc($salibawang)){
  if($salinitas == $rowsali8['s1']){
    $c16b=1;
  }elseif($salinitas == $rowsali8['s2']){
    $c16b=0.75;
  }elseif($salinitas == $rowsali8['s3']){
    $c16b=0.5;
  }elseif($salinitas == $rowsali8['n']){
    $c16b=0.25;
  }elseif($salinitas == $rowsali8['kosong']){
    $c16b=0.25;
  }
}
while($rowalkali8 = mysqli_fetch_assoc($alkalibawang)){
  if($alkalinitas == $rowalkali8['s1']){
    $c17b=1;
  }elseif($alkalinitas == $rowalkali8['s2']){
    $c17b=0.75;
  }elseif($alkalinitas == $rowalkali8['s3']){
    $c17b=0.5;
  }elseif($alkalinitas == $rowalkali8['n']){
    $c17b=0.25;
  }elseif($alkalinitas == $rowalkali8['kosong']){
    $c17b=0.25;
  }
}
while($rowks8 = mysqli_fetch_assoc($ksbawang)){
  if($kedalamansulfidik == $rowks8['s1']){
    $c18b=1;
  }elseif($kedalamansulfidik == $rowks8['s2']){
    $c18b=0.75;
  }elseif($kedalamansulfidik == $rowks8['s3']){
    $c18b=0.5;
  }elseif($kedalamansulfidik == $rowks8['n']){
    $c18b=0.25;
  }elseif($kedalamansulfidik == $rowks8['kosong']){
    $c18b=0.25;
  }
}
while($rowler8 = mysqli_fetch_assoc($lerbawang)){
  if($lereng == $rowler8['s1']){
    $c19b=1;
  }elseif($lereng == $rowler8['s2']){
    $c19b=0.75;
  }elseif($lereng == $rowler8['s3']){
    $c19b=0.5;
  }elseif($lereng == $rowler8['n']){
    $c19b=0.25;
  }elseif($lereng == $rowler8['kosong']){
    $c19b=0.25;
  }
}
while($rowbe8 = mysqli_fetch_assoc($bebawang)){
  if($bahayaerosi == $rowbe8['s1']){
    $c20b=1;
  }elseif($bahayaerosi == $rowbe8['s2']){
    $c20b=0.75;
  }elseif($bahayaerosi == $rowbe8['s3']){
    $c20b=0.5;
  }elseif($bahayaerosi == $rowbe8['n']){
    $c20b=0.25;
  }elseif($bahayaerosi == $rowbe8['kosong']){
    $c20b=0.25;
  }
}
while($rowtb8 = mysqli_fetch_assoc($tbbawang)){
  if($tinggigenangan == $rowtb8['s1']){
    $c21b=1;
  }elseif($tinggigenangan == $rowtb8['s2']){
    $c21b=0.75;
  }elseif($tinggigenangan == $rowtb8['s3']){
    $c21b=0.5;
  }elseif($tinggigenangan == $rowtb8['n']){
    $c21b=0.25;
  }elseif($tinggigenangan == $rowtb8['kosong']){
    $c21b=0.25;
  }
}
while($rowlb8 = mysqli_fetch_assoc($lbbawang)){
  if($lamagenangan == $rowlb8['s1']){
    $c22b=1;
  }elseif($lamagenangan == $rowlb8['s2']){
    $c22b=0.75;
  }elseif($lamagenangan == $rowlb8['s3']){
    $c22b=0.5;
  }elseif($lamagenangan == $rowlb8['n']){
    $c22b=0.25;
  }elseif($lamagenangan == $rowlb8['kosong']){
    $c22b=0.25;
  }
}
while($rowbatu8 = mysqli_fetch_assoc($batubawang)){
  if($batuan == $rowbatu8['s1']){
    $c23b=1;
  }elseif($batuan == $rowbatu8['s2']){
    $c23b=0.75;
  }elseif($batuan == $rowbatu8['s3']){
    $c23b=0.5;
  }elseif($batuan == $rowbatu8['n']){
    $c23b=0.25;
  }elseif($batuan == $rowbatu8['kosong']){
    $c23b=0.25;
  }
}
while($rowsing8 = mysqli_fetch_assoc($singbawang)){
  if($singkapan == $rowsing8['s1']){
    $c24b=1;
  }elseif($singkapan == $rowsing8['s2']){
    $c24b=0.75;
  }elseif($singkapan == $rowsing8['s3']){
    $c24b=0.5;
  }elseif($singkapan == $rowsing8['n']){
    $c24b=0.25;
  }elseif($singkapan == $rowsing8['kosong']){
    $c24b=0.25;
  }
}
while($rowcht8 = mysqli_fetch_assoc($chtbawang)){
  if($curahhujan == $rowcht8['s1']){
    $c25b=1; 
  }elseif($curahhujan == $rowcht8['s2']){
    $c25b=0.75; 
  }elseif($curahhujan == $rowcht8['s3']){
    $c25b=0.5;
  }elseif($curahhujan == $rowcht8['n']){
    $c25b=0.25;
  }elseif($curahhujan == $rowcht8['kosong']){
    $c25b=0.25;
  }
}


//CABAI
while($rowtemp9 = mysqli_fetch_assoc($tempcabai)){
  if($temperatur == $rowtemp9['s1']){
    $c1c=1;
  }elseif($temperatur == $rowtemp9['s2']){
    $c1c=0.75;
  }elseif($temperatur == $rowtemp9['s3']){
    $c1c=0.5;
  }elseif($temperatur == $rowtemp9['n']){
    $c1c=0.25;
  }elseif($temperatur == $rowtemp9['kosong']){
    $c1c=0.25;
  }
}
while($rowka9 = mysqli_fetch_assoc($kacabai)){
  if($ketersediaanair == $rowka9['s1']){
    $c2c=1;
  }elseif($ketersediaanair == $rowka9['s2']){
    $c2c=0.75;
  }elseif($ketersediaanair == $rowka9['s3']){
    $c2c=0.5;
  }elseif($ketersediaanair == $rowka9['n']){
    $c2c=0.25;
  }elseif($ketersediaanair == $rowka9['kosong']){
    $c2c=0.25;
  }
}
while($rowdrain9 = mysqli_fetch_assoc($draincabai)){
  if($drainase == $rowdrain9['s1']){
    $c3c=1;
  }elseif($drainase == $rowdrain9['s2']){
    $c3c=0.75;
  }elseif($drainase == $rowdrain9['s3']){
    $c3c=0.5;
  }elseif($drainase == $rowdrain9['n']){
    $c3c=0.25;
  }elseif($drainase == $rowdrain9['kosong']){
    $c3c=0.25;
  }
}
while($rowteks9 = mysqli_fetch_assoc($tekscabai)){
  if($tekstur == $rowteks9['s1']){
    $c4c=1;
  }elseif($tekstur == $rowteks9['s2']){
    $c4c=0.75;
  }elseif($tekstur == $rowteks9['s3']){
    $c4c=0.5;
  }elseif($tekstur == $rowteks9['n']){
    $c4c=0.25;
  }elseif($tekstur == $rowteks9['kosong']){
    $c4c=0.25;
  }
}
while($rowbk9 = mysqli_fetch_assoc($bkcabai)){
  if($bahankasar == $rowbk9['s1']){
    $c5c=1;
  }elseif($bahankasar == $rowbk9['s2']){
    $c5c=0.75;
  }elseif($bahankasar == $rowbk9['s3']){
    $c5c=0.5;
  }elseif($bahankasar == $rowbk9['n']){
    $c5c=0.25;
  }elseif($bahankasar == $rowbk9['kosong']){
    $c5c=0.25;
  }
}
while($rowkt9 = mysqli_fetch_assoc($ktcabai)){
  if($kedalamantanah == $rowkt9['s1']){
    $c6c=1;
  }elseif($kedalamantanah == $rowkt9['s2']){
    $c6c=0.75;
  }elseif($kedalamantanah == $rowkt9['s3']){
    $c6c=0.5;
  }elseif($kedalamantanah == $rowkt9['n']){
    $c6c=0.25;
  }elseif($kedalamantanah == $rowkt9['kosong']){
    $c6c=0.25;
  }
}
while($rowkg9 = mysqli_fetch_assoc($kgcabai)){
  if($ketebalangambut == $rowkg9['s1']){
    $c7c=1;
  }elseif($ketebalangambut == $rowkg9['s2']){
    $c7c=0.75;
  }elseif($ketebalangambut == $rowkg9['s3']){
    $c7c=0.5;
  }elseif($ketebalangambut == $rowkg9['n']){
    $c7c=0.25;
  }elseif($ketebalangambut == $rowkg9['kosong']){
    $c7c=0.25;
  }
}
while($rowktg9 = mysqli_fetch_assoc($ktgcabai)){
  if($kematangan == $rowktg9['s1']){
    $c8c=1;
  }elseif($kematangan == $rowktg9['s2']){
    $c8c=0.75;
  }elseif($kematangan == $rowktg9['s3']){
    $c8c=0.5;
  }elseif($kematangan == $rowktg9['n']){
    $c8c=0.25;
  }elseif($kematangan == $rowktg9['kosong']){
    $c8c=0.25;
  }
}
while($rowktk9 = mysqli_fetch_assoc($ktkcabai)){
  if($ktktanah == $rowktk9['s1']){
    $c9c=1;
  }elseif($ktktanah == $rowktk9['s2']){
    $c9c=0.75;
  }elseif($ktktanah == $rowktk9['s3']){
    $c9c=0.5;
  }elseif($ktktanah == $rowktk9['n']){
    $c9c=0.25;
  }elseif($ktktanah == $rowktk9['kosong']){
    $c9c=0.25;
  }
}
while($rowkb9 = mysqli_fetch_assoc($kbcabai)){
  if($kejenuhanbasa == $rowkb9['s1']){
    $c10c=1;
  }elseif($kejenuhanbasa == $rowkb9['s2']){
    $c10c=0.75;
  }elseif($kejenuhanbasa == $rowkb9['s3']){
    $c10c=0.5;
  }elseif($kejenuhanbasa == $rowkb9['n']){
    $c10c=0.25;
  }elseif($kejenuhanbasa == $rowkb9['kosong']){
    $c10c=0.25;
  }
}
while($rowph9 = mysqli_fetch_assoc($phcabai)){
  if($phh2o == $rowph9['s1']){
    $c11c=1;
  }elseif($phh2o == $rowph9['s2']){
    $c11c=0.75;
  }elseif($phh2o == $rowph9['s3']){
    $c11c=0.5;
  }elseif($phh2o == $rowph9['n']){
    $c11c=0.25;
  }elseif($phh2o == $rowph9['kosong']){
    $c11c=0.25;
  }
}
while($rowcorg9 = mysqli_fetch_assoc($corgcabai)){
  if($corganik == $rowcorg9['s1']){
    $c12c=1;
  }elseif($corganik == $rowcorg9['s2']){
    $c12c=0.75;
  }elseif($corganik == $rowcorg9['s3']){
    $c12c=0.5;
  }elseif($corganik == $rowcorg9['n']){
    $c12c=0.25;
  }elseif($corganik == $rowcorg9['kosong']){
    $c12c=0.25;
  }
}
while($rowntotal9 = mysqli_fetch_assoc($ntotalcabai)){
  if($ntotal == $rowntotal9['s1']){
    $c13c=1;
  }elseif($ntotal == $rowntotal9['s2']){
    $c13c=0.75;
  }elseif($ntotal == $rowntotal9['s3']){
    $c13c=0.5;
  }elseif($ntotal == $rowntotal9['n']){
    $c13c=0.25;
  }elseif($ntotal == $rowntotal9['kosong']){
    $c13c=0.25;
  }
}
while($rowp29 = mysqli_fetch_assoc($p2cabai)){
  if($p2o5 == $rowp29['s1']){
    $c14c=1;
  }elseif($p2o5 == $rowp29['s2']){
    $c14c=0.75;
  }elseif($p2o5 == $rowp29['s3']){
    $c14c=0.5;
  }elseif($p2o5 == $rowp29['n']){
    $c14c=0.25;
  }elseif($p2o5 == $rowp29['kosong']){
    $c14c=0.25;
  }
}
while($rowk29 = mysqli_fetch_assoc($k2cabai)){
  if($k2o == $rowk29['s1']){
    $c15c=1;
  }elseif($k2o == $rowk29['s2']){
    $c15c=0.75;
  }elseif($k2o == $rowk29['s3']){
    $c15c=0.5;
  }elseif($k2o == $rowk29['n']){
    $c15c=0.25;
  }elseif($k2o == $rowk29['kosong']){
    $c15c=0.25;
  }
}
while($rowsali9 = mysqli_fetch_assoc($salicabai)){
  if($salinitas == $rowsali9['s1']){
    $c16c=1;
  }elseif($salinitas == $rowsali9['s2']){
    $c16c=0.75;
  }elseif($salinitas == $rowsali9['s3']){
    $c16c=0.5;
  }elseif($salinitas == $rowsali9['n']){
    $c16c=0.25;
  }elseif($salinitas == $rowsali9['kosong']){
    $c16c=0.25;
  }
}
while($rowalkali9 = mysqli_fetch_assoc($alkalicabai)){
  if($alkalinitas == $rowalkali9['s1']){
    $c17c=1;
  }elseif($alkalinitas == $rowalkali9['s2']){
    $c17c=0.75;
  }elseif($alkalinitas == $rowalkali9['s3']){
    $c17c=0.5;
  }elseif($alkalinitas == $rowalkali9['n']){
    $c17c=0.25;
  }elseif($alkalinitas == $rowalkali9['kosong']){
    $c17c=0.25;
  }
}
while($rowks9 = mysqli_fetch_assoc($kscabai)){
  if($kedalamansulfidik == $rowks9['s1']){
    $c18c=1;
  }elseif($kedalamansulfidik == $rowks9['s2']){
    $c18c=0.75;
  }elseif($kedalamansulfidik == $rowks9['s3']){
    $c18c=0.5;
  }elseif($kedalamansulfidik == $rowks9['n']){
    $c18c=0.25;
  }elseif($kedalamansulfidik == $rowks9['kosong']){
    $c18c=0.25;
  }
}
while($rowler9 = mysqli_fetch_assoc($lercabai)){
  if($lereng == $rowler9['s1']){
    $c19c=1;
  }elseif($lereng == $rowler9['s2']){
    $c19c=0.75;
  }elseif($lereng == $rowler9['s3']){
    $c19c=0.5;
  }elseif($lereng == $rowler9['n']){
    $c19c=0.25;
  }elseif($lereng == $rowler9['kosong']){
    $c19c=0.25;
  }
}
while($rowbe9 = mysqli_fetch_assoc($becabai)){
  if($bahayaerosi == $rowbe9['s1']){
    $c20c=1;
  }elseif($bahayaerosi == $rowbe9['s2']){
    $c20c=0.75;
  }elseif($bahayaerosi == $rowbe9['s3']){
    $c20c=0.5;
  }elseif($bahayaerosi == $rowbe9['n']){
    $c20c=0.25;
  }elseif($bahayaerosi == $rowbe9['kosong']){
    $c20c=0.25;
  }
}
while($rowtb9 = mysqli_fetch_assoc($tbcabai)){
  if($tinggigenangan == $rowtb9['s1']){
    $c21c=1;
  }elseif($tinggigenangan == $rowtb9['s2']){
    $c21c=0.75;
  }elseif($tinggigenangan == $rowtb9['s3']){
    $c21c=0.5;
  }elseif($tinggigenangan == $rowtb9['n']){
    $c21c=0.25;
  }elseif($tinggigenangan == $rowtb9['kosong']){
    $c21c=0.25;
  }
}
while($rowlb9 = mysqli_fetch_assoc($lbcabai)){
  if($lamagenangan == $rowlb9['s1']){
    $c22c=1;
  }elseif($lamagenangan == $rowlb9['s2']){
    $c22c=0.75;
  }elseif($lamagenangan == $rowlb9['s3']){
    $c22c=0.5;
  }elseif($lamagenangan == $rowlb9['n']){
    $c22c=0.25;
  }elseif($lamagenangan == $rowlb9['kosong']){
    $c22c=0.25;
  }
}
while($rowbatu9 = mysqli_fetch_assoc($batucabai)){
  if($batuan == $rowbatu9['s1']){
    $c23c=1;
  }elseif($batuan == $rowbatu9['s2']){
    $c23c=0.75;
  }elseif($batuan == $rowbatu9['s3']){
    $c23c=0.5;
  }elseif($batuan == $rowbatu9['n']){
    $c23c=0.25;
  }elseif($batuan == $rowbatu9['kosong']){
    $c23c=0.25;
  }
}
while($rowsing9 = mysqli_fetch_assoc($singcabai)){
  if($singkapan == $rowsing9['s1']){
    $c24c=1;
  }elseif($singkapan == $rowsing9['s2']){
    $c24c=0.75;
  }elseif($singkapan == $rowsing9['s3']){
    $c24c=0.5;
  }elseif($singkapan == $rowsing9['n']){
    $c24c=0.25;
  }elseif($singkapan == $rowsing9['kosong']){
    $c24c=0.25;
  }
}
while($rowcht9 = mysqli_fetch_assoc($chtcabai)){
  if($curahhujan == $rowcht9['s1']){
    $c25c=1; 
  }elseif($curahhujan == $rowcht9['s2']){
    $c25c=0.75; 
  }elseif($curahhujan == $rowcht9['s3']){
    $c25c=0.5;
  }elseif($curahhujan == $rowcht9['n']){
    $c25c=0.25;
  }elseif($curahhujan == $rowcht9['kosong']){
    $c25c=0.25;
  }
}


//KELAPA SAWIT
while($rowtemp10 = mysqli_fetch_assoc($tempsawit)){
  if($temperatur == $rowtemp10['s1']){
    $c1s=1;
  }elseif($temperatur == $rowtemp10['s2']){
    $c1s=0.75;
  }elseif($temperatur == $rowtemp10['s3']){
    $c1s=0.5;
  }elseif($temperatur == $rowtemp10['n']){
    $c1s=0.25;
  }elseif($temperatur == $rowtemp10['kosong']){
    $c1s=0.25;
  }
}
while($rowka10 = mysqli_fetch_assoc($kasawit)){
  if($ketersediaanair == $rowka10['s1']){
    $c2s=1;
  }elseif($ketersediaanair == $rowka10['s2']){
    $c2s=0.75;
  }elseif($ketersediaanair == $rowka10['s3']){
    $c2s=0.5;
  }elseif($ketersediaanair == $rowka10['n']){
    $c2s=0.25;
  }elseif($ketersediaanair == $rowka10['kosong']){
    $c2s=0.25;
  }
}
while($rowdrain10 = mysqli_fetch_assoc($drainsawit)){
  if($drainase == $rowdrain10['s1']){
    $c3s=1;
  }elseif($drainase == $rowdrain10['s2']){
    $c3s=0.75;
  }elseif($drainase == $rowdrain10['s3']){
    $c3s=0.5;
  }elseif($drainase == $rowdrain10['n']){
    $c3s=0.25;
  }elseif($drainase == $rowdrain10['kosong']){
    $c3s=0.25;
  }
}
while($rowteks10 = mysqli_fetch_assoc($tekssawit)){
  if($tekstur == $rowteks10['s1']){
    $c4s=1;
  }elseif($tekstur == $rowteks10['s2']){
    $c4s=0.75;
  }elseif($tekstur == $rowteks10['s3']){
    $c4s=0.5;
  }elseif($tekstur == $rowteks10['n']){
    $c4s=0.25;
  }elseif($tekstur == $rowteks10['kosong']){
    $c4s=0.25;
  }
}
while($rowbk10 = mysqli_fetch_assoc($bksawit)){
  if($bahankasar == $rowbk10['s1']){
    $c5s=1;
  }elseif($bahankasar == $rowbk10['s2']){
    $c5s=0.75;
  }elseif($bahankasar == $rowbk10['s3']){
    $c5s=0.5;
  }elseif($bahankasar == $rowbk10['n']){
    $c5s=0.25;
  }elseif($bahankasar == $rowbk10['kosong']){
    $c5s=0.25;
  }
}
while($rowkt10 = mysqli_fetch_assoc($ktsawit)){
  if($kedalamantanah == $rowkt10['s1']){
    $c6s=1;
  }elseif($kedalamantanah == $rowkt10['s2']){
    $c6s=0.75;
  }elseif($kedalamantanah == $rowkt10['s3']){
    $c6s=0.5;
  }elseif($kedalamantanah == $rowkt10['n']){
    $c6s=0.25;
  }elseif($kedalamantanah == $rowkt10['kosong']){
    $c6s=0.25;
  }
}
while($rowkg10 = mysqli_fetch_assoc($kgsawit)){
  if($ketebalangambut == $rowkg10['s1']){
    $c7s=1;
  }elseif($ketebalangambut == $rowkg10['s2']){
    $c7s=0.75;
  }elseif($ketebalangambut == $rowkg10['s3']){
    $c7s=0.5;
  }elseif($ketebalangambut == $rowkg10['n']){
    $c7s=0.25;
  }elseif($ketebalangambut == $rowkg10['kosong']){
    $c7s=0.25;
  }
}
while($rowktg10 = mysqli_fetch_assoc($ktgsawit)){
  if($kematangan == $rowktg10['s1']){
    $c8s=1;
  }elseif($kematangan == $rowktg10['s2']){
    $c8s=0.75;
  }elseif($kematangan == $rowktg10['s3']){
    $c8s=0.5;
  }elseif($kematangan == $rowktg10['n']){
    $c8s=0.25;
  }elseif($kematangan == $rowktg10['kosong']){
    $c8s=0.25;
  }
}
while($rowktk10 = mysqli_fetch_assoc($ktksawit)){
  if($ktktanah == $rowktk10['s1']){
    $c9s=1;
  }elseif($ktktanah == $rowktk10['s2']){
    $c9s=0.75;
  }elseif($ktktanah == $rowktk10['s3']){
    $c9s=0.5;
  }elseif($ktktanah == $rowktk10['n']){
    $c9s=0.25;
  }elseif($ktktanah == $rowktk10['kosong']){
    $c9s=0.25;
  }
}
while($rowkb10 = mysqli_fetch_assoc($kbsawit)){
  if($kejenuhanbasa == $rowkb10['s1']){
    $c10s=1;
  }elseif($kejenuhanbasa == $rowkb10['s2']){
    $c10s=0.75;
  }elseif($kejenuhanbasa == $rowkb10['s3']){
    $c10s=0.5;
  }elseif($kejenuhanbasa == $rowkb10['n']){
    $c10s=0.25;
  }elseif($kejenuhanbasa == $rowkb10['kosong']){
    $c10s=0.25;
  }
}
while($rowph10 = mysqli_fetch_assoc($phsawit)){
  if($phh2o == $rowph10['s1']){
    $c11s=1;
  }elseif($phh2o == $rowph10['s2']){
    $c11s=0.75;
  }elseif($phh2o == $rowph10['s3']){
    $c11s=0.5;
  }elseif($phh2o == $rowph10['n']){
    $c11s=0.25;
  }elseif($phh2o == $rowph10['kosong']){
    $c11s=0.25;
  }
}
while($rowcorg10 = mysqli_fetch_assoc($corgsawit)){
  if($corganik == $rowcorg10['s1']){
    $c12s=1;
  }elseif($corganik == $rowcorg10['s2']){
    $c12s=0.75;
  }elseif($corganik == $rowcorg10['s3']){
    $c12s=0.5;
  }elseif($corganik == $rowcorg10['n']){
    $c12s=0.25;
  }elseif($corganik == $rowcorg10['kosong']){
    $c12s=0.25;
  }
}
while($rowntotal10 = mysqli_fetch_assoc($ntotalsawit)){
  if($ntotal == $rowntotal10['s1']){
    $c13s=1;
  }elseif($ntotal == $rowntotal10['s2']){
    $c13s=0.75;
  }elseif($ntotal == $rowntotal10['s3']){
    $c13s=0.5;
  }elseif($ntotal == $rowntotal10['n']){
    $c13s=0.25;
  }elseif($ntotal == $rowntotal10['kosong']){
    $c13s=0.25;
  }
}
while($rowp210 = mysqli_fetch_assoc($p2sawit)){
  if($p2o5 == $rowp210['s1']){
    $c14s=1;
  }elseif($p2o5 == $rowp210['s2']){
    $c14s=0.75;
  }elseif($p2o5 == $rowp210['s3']){
    $c14s=0.5;
  }elseif($p2o5 == $rowp210['n']){
    $c14s=0.25;
  }elseif($p2o5 == $rowp210['kosong']){
    $c14s=0.25;
  }
}
while($rowk210 = mysqli_fetch_assoc($k2sawit)){
  if($k2o == $rowk210['s1']){
    $c15s=1;
  }elseif($k2o == $rowk210['s2']){
    $c15s=0.75;
  }elseif($k2o == $rowk210['s3']){
    $c15s=0.5;
  }elseif($k2o == $rowk210['n']){
    $c15s=0.25;
  }elseif($k2o == $rowk210['kosong']){
    $c15s=0.25;
  }
}
while($rowsali10 = mysqli_fetch_assoc($salisawit)){
  if($salinitas == $rowsali10['s1']){
    $c16s=1;
  }elseif($salinitas == $rowsali10['s2']){
    $c16s=0.75;
  }elseif($salinitas == $rowsali10['s3']){
    $c16s=0.5;
  }elseif($salinitas == $rowsali10['n']){
    $c16s=0.25;
  }elseif($salinitas == $rowsali10['kosong']){
    $c16s=0.25;
  }
}
while($rowalkali10 = mysqli_fetch_assoc($alkalisawit)){
  if($alkalinitas == $rowalkali10['s1']){
    $c17s=1;
  }elseif($alkalinitas == $rowalkali10['s2']){
    $c17s=0.75;
  }elseif($alkalinitas == $rowalkali10['s3']){
    $c17s=0.5;
  }elseif($alkalinitas == $rowalkali10['n']){
    $c17s=0.25;
  }elseif($alkalinitas == $rowalkali10['kosong']){
    $c17s=0.25;
  }
}
while($rowks10 = mysqli_fetch_assoc($kssawit)){
  if($kedalamansulfidik == $rowks10['s1']){
    $c18s=1;
  }elseif($kedalamansulfidik == $rowks10['s2']){
    $c18s=0.75;
  }elseif($kedalamansulfidik == $rowks10['s3']){
    $c18s=0.5;
  }elseif($kedalamansulfidik == $rowks10['n']){
    $c18s=0.25;
  }elseif($kedalamansulfidik == $rowks10['kosong']){
    $c18s=0.25;
  }
}
while($rowler10 = mysqli_fetch_assoc($lersawit)){
  if($lereng == $rowler10['s1']){
    $c19s=1;
  }elseif($lereng == $rowler10['s2']){
    $c19s=0.75;
  }elseif($lereng == $rowler10['s3']){
    $c19s=0.5;
  }elseif($lereng == $rowler10['n']){
    $c19s=0.25;
  }elseif($lereng == $rowler10['kosong']){
    $c19s=0.25;
  }
}
while($rowbe10 = mysqli_fetch_assoc($besawit)){
  if($bahayaerosi == $rowbe10['s1']){
    $c20s=1;
  }elseif($bahayaerosi == $rowbe10['s2']){
    $c20s=0.75;
  }elseif($bahayaerosi == $rowbe10['s3']){
    $c20s=0.5;
  }elseif($bahayaerosi == $rowbe10['n']){
    $c20s=0.25;
  }elseif($bahayaerosi == $rowbe10['kosong']){
    $c20s=0.25;
  }
}
while($rowtb10 = mysqli_fetch_assoc($tbsawit)){
  if($tinggigenangan == $rowtb10['s1']){
    $c21s=1;
  }elseif($tinggigenangan == $rowtb10['s2']){
    $c21s=0.75;
  }elseif($tinggigenangan == $rowtb10['s3']){
    $c21s=0.5;
  }elseif($tinggigenangan == $rowtb10['n']){
    $c21s=0.25;
  }elseif($tinggigenangan == $rowtb10['kosong']){
    $c21s=0.25;
  }
}
while($rowlb10 = mysqli_fetch_assoc($lbsawit)){
  if($lamagenangan == $rowlb10['s1']){
    $c22s=1;
  }elseif($lamagenangan == $rowlb10['s2']){
    $c22s=0.75;
  }elseif($lamagenangan == $rowlb10['s3']){
    $c22s=0.5;
  }elseif($lamagenangan == $rowlb10['n']){
    $c22s=0.25;
  }elseif($lamagenangan == $rowlb10['kosong']){
    $c22s=0.25;
  }
}
while($rowbatu10 = mysqli_fetch_assoc($batusawit)){
  if($batuan == $rowbatu10['s1']){
    $c23s=1;
  }elseif($batuan == $rowbatu10['s2']){
    $c23s=0.75;
  }elseif($batuan == $rowbatu10['s3']){
    $c23s=0.5;
  }elseif($batuan == $rowbatu10['n']){
    $c23s=0.25;
  }elseif($batuan == $rowbatu10['kosong']){
    $c23s=0.25;
  }
}
while($rowsing10 = mysqli_fetch_assoc($singsawit)){
  if($singkapan == $rowsing10['s1']){
    $c24s=1;
  }elseif($singkapan == $rowsing10['s2']){
    $c24s=0.75;
  }elseif($singkapan == $rowsing10['s3']){
    $c24s=0.5;
  }elseif($singkapan == $rowsing10['n']){
    $c24s=0.25;
  }elseif($singkapan == $rowsing10['kosong']){
    $c24s=0.25;
  }
}
while($rowcht10 = mysqli_fetch_assoc($chtsawit)){
  if($curahhujan == $rowcht10['s1']){
    $c25s=1; 
  }elseif($curahhujan == $rowcht10['s2']){
    $c25s=0.75; 
  }elseif($curahhujan == $rowcht10['s3']){
    $c25s=0.5;
  }elseif($curahhujan == $rowcht10['n']){
    $c25s=0.25;
  }elseif($curahhujan == $rowcht10['kosong']){
    $c25s=0.25;
  }
}


//KAKAO
while($rowtemp11 = mysqli_fetch_assoc($tempkakao)){
  if($temperatur == $rowtemp11['s1']){
    $c1ka=1;
  }elseif($temperatur == $rowtemp11['s2']){
    $c1ka=0.75;
  }elseif($temperatur == $rowtemp11['s3']){
    $c1ka=0.5;
  }elseif($temperatur == $rowtemp11['n']){
    $c1ka=0.25;
  }elseif($temperatur == $rowtemp11['kosong']){
    $c1ka=0.25;
  }
}
while($rowka11 = mysqli_fetch_assoc($kakakao)){
  if($ketersediaanair == $rowka11['s1']){
    $c2ka=1;
  }elseif($ketersediaanair == $rowka11['s2']){
    $c2ka=0.75;
  }elseif($ketersediaanair == $rowka11['s3']){
    $c2ka=0.5;
  }elseif($ketersediaanair == $rowka11['n']){
    $c2ka=0.25;
  }elseif($ketersediaanair == $rowka11['kosong']){
    $c2ka=0.25;
  }
}
while($rowdrain11 = mysqli_fetch_assoc($drainkakao)){
  if($drainase == $rowdrain11['s1']){
    $c3ka=1;
  }elseif($drainase == $rowdrain11['s2']){
    $c3ka=0.75;
  }elseif($drainase == $rowdrain11['s3']){
    $c3ka=0.5;
  }elseif($drainase == $rowdrain11['n']){
    $c3ka=0.25;
  }elseif($drainase == $rowdrain11['kosong']){
    $c3ka=0.25;
  }
}
while($rowteks11 = mysqli_fetch_assoc($tekskakao)){
  if($tekstur == $rowteks11['s1']){
    $c4ka=1;
  }elseif($tekstur == $rowteks11['s2']){
    $c4ka=0.75;
  }elseif($tekstur == $rowteks11['s3']){
    $c4ka=0.5;
  }elseif($tekstur == $rowteks11['n']){
    $c4ka=0.25;
  }elseif($tekstur == $rowteks11['kosong']){
    $c4ka=0.25;
  }
}
while($rowbk11 = mysqli_fetch_assoc($bkkakao)){
  if($bahankasar == $rowbk11['s1']){
    $c5ka=1;
  }elseif($bahankasar == $rowbk11['s2']){
    $c5ka=0.75;
  }elseif($bahankasar == $rowbk11['s3']){
    $c5ka=0.5;
  }elseif($bahankasar == $rowbk11['n']){
    $c5ka=0.25;
  }elseif($bahankasar == $rowbk11['kosong']){
    $c5ka=0.25;
  }
}
while($rowkt11 = mysqli_fetch_assoc($ktkakao)){
  if($kedalamantanah == $rowkt11['s1']){
    $c6ka=1;
  }elseif($kedalamantanah == $rowkt11['s2']){
    $c6ka=0.75;
  }elseif($kedalamantanah == $rowkt11['s3']){
    $c6ka=0.5;
  }elseif($kedalamantanah == $rowkt11['n']){
    $c6ka=0.25;
  }elseif($kedalamantanah == $rowkt11['kosong']){
    $c6ka=0.25;
  }
}
while($rowkg11 = mysqli_fetch_assoc($kgkakao)){
  if($ketebalangambut == $rowkg11['s1']){
    $c7ka=1;
  }elseif($ketebalangambut == $rowkg11['s2']){
    $c7ka=0.75;
  }elseif($ketebalangambut == $rowkg11['s3']){
    $c7ka=0.5;
  }elseif($ketebalangambut == $rowkg11['n']){
    $c7ka=0.25;
  }elseif($ketebalangambut == $rowkg11['kosong']){
    $c7ka=0.25;
  }
}
while($rowktg11 = mysqli_fetch_assoc($ktgkakao)){
  if($kematangan == $rowktg11['s1']){
    $c8ka=1;
  }elseif($kematangan == $rowktg11['s2']){
    $c8ka=0.75;
  }elseif($kematangan == $rowktg11['s3']){
    $c8ka=0.5;
  }elseif($kematangan == $rowktg11['n']){
    $c8ka=0.25;
  }elseif($kematangan == $rowktg11['kosong']){
    $c8ka=0.25;
  }
}
while($rowktk11 = mysqli_fetch_assoc($ktkkakao)){
  if($ktktanah == $rowktk11['s1']){
    $c9ka=1;
  }elseif($ktktanah == $rowktk11['s2']){
    $c9ka=0.75;
  }elseif($ktktanah == $rowktk11['s3']){
    $c9ka=0.5;
  }elseif($ktktanah == $rowktk11['n']){
    $c9ka=0.25;
  }elseif($ktktanah == $rowktk11['kosong']){
    $c9ka=0.25;
  }
}
while($rowkb11 = mysqli_fetch_assoc($kbkakao)){
  if($kejenuhanbasa == $rowkb11['s1']){
    $c10ka=1;
  }elseif($kejenuhanbasa == $rowkb11['s2']){
    $c10ka=0.75;
  }elseif($kejenuhanbasa == $rowkb11['s3']){
    $c10ka=0.5;
  }elseif($kejenuhanbasa == $rowkb11['n']){
    $c10ka=0.25;
  }elseif($kejenuhanbasa == $rowkb11['kosong']){
    $c10ka=0.25;
  }
}
while($rowph11 = mysqli_fetch_assoc($phkakao)){
  if($phh2o == $rowph11['s1']){
    $c11ka=1;
  }elseif($phh2o == $rowph11['s2']){
    $c11ka=0.75;
  }elseif($phh2o == $rowph11['s3']){
    $c11ka=0.5;
  }elseif($phh2o == $rowph11['n']){
    $c11ka=0.25;
  }elseif($phh2o == $rowph11['kosong']){
    $c11ka=0.25;
  }
}
while($rowcorg11 = mysqli_fetch_assoc($corgkakao)){
  if($corganik == $rowcorg11['s1']){
    $c12ka=1;
  }elseif($corganik == $rowcorg11['s2']){
    $c12ka=0.75;
  }elseif($corganik == $rowcorg11['s3']){
    $c12ka=0.5;
  }elseif($corganik == $rowcorg11['n']){
    $c12ka=0.25;
  }elseif($corganik == $rowcorg11['kosong']){
    $c12ka=0.25;
  }
}
while($rowntotal11 = mysqli_fetch_assoc($ntotalkakao)){
  if($ntotal == $rowntotal11['s1']){
    $c13ka=1;
  }elseif($ntotal == $rowntotal11['s2']){
    $c13ka=0.75;
  }elseif($ntotal == $rowntotal11['s3']){
    $c13ka=0.5;
  }elseif($ntotal == $rowntotal11['n']){
    $c13ka=0.25;
  }elseif($ntotal == $rowntotal11['kosong']){
    $c13ka=0.25;
  }
}
while($rowp211 = mysqli_fetch_assoc($p2kakao)){
  if($p2o5 == $rowp211['s1']){
    $c14ka=1;
  }elseif($p2o5 == $rowp211['s2']){
    $c14ka=0.75;
  }elseif($p2o5 == $rowp211['s3']){
    $c14ka=0.5;
  }elseif($p2o5 == $rowp211['n']){
    $c14ka=0.25;
  }elseif($p2o5 == $rowp211['kosong']){
    $c14ka=0.25;
  }
}
while($rowk211 = mysqli_fetch_assoc($k2kakao)){
  if($k2o == $rowk211['s1']){
    $c15ka=1;
  }elseif($k2o == $rowk211['s2']){
    $c15ka=0.75;
  }elseif($k2o == $rowk211['s3']){
    $c15ka=0.5;
  }elseif($k2o == $rowk211['n']){
    $c15ka=0.25;
  }elseif($k2o == $rowk211['kosong']){
    $c15ka=0.25;
  }
}
while($rowsali11 = mysqli_fetch_assoc($salikakao)){
  if($salinitas == $rowsali11['s1']){
    $c16ka=1;
  }elseif($salinitas == $rowsali11['s2']){
    $c16ka=0.75;
  }elseif($salinitas == $rowsali11['s3']){
    $c16ka=0.5;
  }elseif($salinitas == $rowsali11['n']){
    $c16ka=0.25;
  }elseif($salinitas == $rowsali11['kosong']){
    $c16ka=0.25;
  }
}
while($rowalkali11 = mysqli_fetch_assoc($alkalikakao)){
  if($alkalinitas == $rowalkali11['s1']){
    $c17ka=1;
  }elseif($alkalinitas == $rowalkali11['s2']){
    $c17ka=0.75;
  }elseif($alkalinitas == $rowalkali11['s3']){
    $c17ka=0.5;
  }elseif($alkalinitas == $rowalkali['n']){
    $c17ka=0.25;
  }elseif($alkalinitas == $rowalkali11['kosong']){
    $c17ka=0.25;
  }
}
while($rowks11 = mysqli_fetch_assoc($kskakao)){
  if($kedalamansulfidik == $rowks11['s1']){
    $c18ka=1;
  }elseif($kedalamansulfidik == $rowks11['s2']){
    $c18ka=0.75;
  }elseif($kedalamansulfidik == $rowks11['s3']){
    $c18ka=0.5;
  }elseif($kedalamansulfidik == $rowks11['n']){
    $c18ka=0.25;
  }elseif($kedalamansulfidik == $rowks11['kosong']){
    $c18ka=0.25;
  }
}
while($rowler11 = mysqli_fetch_assoc($lerkakao)){
  if($lereng == $rowler11['s1']){
    $c19ka=1;
  }elseif($lereng == $rowler11['s2']){
    $c19ka=0.75;
  }elseif($lereng == $rowler11['s3']){
    $c19ka=0.5;
  }elseif($lereng == $rowler11['n']){
    $c19ka=0.25;
  }elseif($lereng == $rowler11['kosong']){
    $c19ka=0.25;
  }
}
while($rowbe11 = mysqli_fetch_assoc($bekakao)){
  if($bahayaerosi == $rowbe11['s1']){
    $c20ka=1;
  }elseif($bahayaerosi == $rowbe11['s2']){
    $c20ka=0.75;
  }elseif($bahayaerosi == $rowbe11['s3']){
    $c20ka=0.5;
  }elseif($bahayaerosi == $rowbe11['n']){
    $c20ka=0.25;
  }elseif($bahayaerosi == $rowbe11['kosong']){
    $c20ka=0.25;
  }
}
while($rowtb11 = mysqli_fetch_assoc($tbkakao)){
  if($tinggigenangan == $rowtb11['s1']){
    $c21ka=1;
  }elseif($tinggigenangan == $rowtb11['s2']){
    $c21ka=0.75;
  }elseif($tinggigenangan == $rowtb11['s3']){
    $c21ka=0.5;
  }elseif($tinggigenangan == $rowtb11['n']){
    $c21ka=0.25;
  }elseif($tinggigenangan == $rowtb11['kosong']){
    $c21ka=0.25;
  }
}
while($rowlb11 = mysqli_fetch_assoc($lbkakao)){
  if($lamagenangan == $rowlb11['s1']){
    $c22ka=1;
  }elseif($lamagenangan == $rowlb11['s2']){
    $c22ka=0.75;
  }elseif($lamagenangan == $rowlb11['s3']){
    $c22ka=0.5;
  }elseif($lamagenangan == $rowlb11['n']){
    $c22ka=0.25;
  }elseif($lamagenangan == $rowlb11['kosong']){
    $c22ka=0.25;
  }
}
while($rowbatu11 = mysqli_fetch_assoc($batukakao)){
  if($batuan == $rowbatu11['s1']){
    $c23ka=1;
  }elseif($batuan == $rowbatu11['s2']){
    $c23ka=0.75;
  }elseif($batuan == $rowbatu11['s3']){
    $c23ka=0.5;
  }elseif($batuan == $rowbatu11['n']){
    $c23ka=0.25;
  }elseif($batuan == $rowbatu11['kosong']){
    $c23ka=0.25;
  }
}
while($rowsing11 = mysqli_fetch_assoc($singkakao)){
  if($singkapan == $rowsing11['s1']){
    $c24ka=1;
  }elseif($singkapan == $rowsing11['s2']){
    $c24ka=0.75;
  }elseif($singkapan == $rowsing11['s3']){
    $c24ka=0.5;
  }elseif($singkapan == $rowsing11['n']){
    $c24ka=0.25;
  }elseif($singkapan == $rowsing11['kosong']){
    $c24ka=0.25;
  }
}
while($rowcht11 = mysqli_fetch_assoc($chtkakao)){
  if($curahhujan == $rowcht11['s1']){
    $c25ka=1; 
  }elseif($curahhujan == $rowcht11['s2']){
    $c25ka=0.75; 
  }elseif($curahhujan == $rowcht11['s3']){
    $c25ka=0.5;
  }elseif($curahhujan == $rowcht11['n']){
    $c25ka=0.25;
  }elseif($curahhujan == $rowcht11['kosong']){
    $c25ka=0.25;
  }
}


//TEBU
while($rowtemp12 = mysqli_fetch_assoc($temptebu)){
  if($temperatur == $rowtemp12['s1']){
    $c1t=1;
  }elseif($temperatur == $rowtemp12['s2']){
    $c1t=0.75;
  }elseif($temperatur == $rowtemp12['s3']){
    $c1t=0.5;
  }elseif($temperatur == $rowtemp12['n']){
    $c1t=0.25;
  }elseif($temperatur == $rowtemp12['kosong']){
    $c1t=0.25;
  }
}
while($rowka12 = mysqli_fetch_assoc($katebu)){
  if($ketersediaanair == $rowka12['s1']){
    $c2t=1;
  }elseif($ketersediaanair == $rowka12['s2']){
    $c2t=0.75;
  }elseif($ketersediaanair == $rowka12['s3']){
    $c2t=0.5;
  }elseif($ketersediaanair == $rowka12['n']){
    $c2t=0.25;
  }elseif($ketersediaanair == $rowka12['kosong']){
    $c2t=0.25;
  }
}
while($rowdrain12 = mysqli_fetch_assoc($draintebu)){
  if($drainase == $rowdrain12['s1']){
    $c3t=1;
  }elseif($drainase == $rowdrain12['s2']){
    $c3t=0.75;
  }elseif($drainase == $rowdrain12['s3']){
    $c3t=0.5;
  }elseif($drainase == $rowdrain12['n']){
    $c3t=0.25;
  }elseif($drainase == $rowdrain12['kosong']){
    $c3t=0.25;
  }
}
while($rowteks12 = mysqli_fetch_assoc($tekstebu)){
  if($tekstur == $rowteks12['s1']){
    $c4t=1;
  }elseif($tekstur == $rowteks12['s2']){
    $c4t=0.75;
  }elseif($tekstur == $rowteks12['s3']){
    $c4t=0.5;
  }elseif($tekstur == $rowteks12['n']){
    $c4t=0.25;
  }elseif($tekstur == $rowteks12['kosong']){
    $c4t=0.25;
  }
}
while($rowbk12 = mysqli_fetch_assoc($bktebu)){
  if($bahankasar == $rowbk12['s1']){
    $c5t=1;
  }elseif($bahankasar == $rowbk12['s2']){
    $c5t=0.75;
  }elseif($bahankasar == $rowbk12['s3']){
    $c5t=0.5;
  }elseif($bahankasar == $rowbk12['n']){
    $c5t=0.25;
  }elseif($bahankasar == $rowbk12['kosong']){
    $c5t=0.25;
  }
}
while($rowkt12 = mysqli_fetch_assoc($kttebu)){
  if($kedalamantanah == $rowkt12['s1']){
    $c6t=1;
  }elseif($kedalamantanah == $rowkt12['s2']){
    $c6t=0.75;
  }elseif($kedalamantanah == $rowkt12['s3']){
    $c6t=0.5;
  }elseif($kedalamantanah == $rowkt12['n']){
    $c6t=0.25;
  }elseif($kedalamantanah == $rowkt12['kosong']){
    $c6t=0.25;
  }
}
while($rowkg12 = mysqli_fetch_assoc($kgtebu)){
  if($ketebalangambut == $rowkg12['s1']){
    $c7t=1;
  }elseif($ketebalangambut == $rowkg12['s2']){
    $c7t=0.75;
  }elseif($ketebalangambut == $rowkg12['s3']){
    $c7t=0.5;
  }elseif($ketebalangambut == $rowkg12['n']){
    $c7t=0.25;
  }elseif($ketebalangambut == $rowkg12['kosong']){
    $c7t=0.25;
  }
}
while($rowktg12 = mysqli_fetch_assoc($ktgtebu)){
  if($kematangan == $rowktg12['s1']){
    $c8t=1;
  }elseif($kematangan == $rowktg12['s2']){
    $c8t=0.75;
  }elseif($kematangan == $rowktg12['s3']){
    $c8t=0.5;
  }elseif($kematangan == $rowktg12['n']){
    $c8t=0.25;
  }elseif($kematangan == $rowktg12['kosong']){
    $c8t=0.25;
  }
}
while($rowktk12 = mysqli_fetch_assoc($ktktebu)){
  if($ktktanah == $rowktk12['s1']){
    $c9t=1;
  }elseif($ktktanah == $rowktk12['s2']){
    $c9t=0.75;
  }elseif($ktktanah == $rowktk12['s3']){
    $c9t=0.5;
  }elseif($ktktanah == $rowktk12['n']){
    $c9t=0.25;
  }elseif($ktktanah == $rowktk12['kosong']){
    $c9t=0.25;
  }
}
while($rowkb12 = mysqli_fetch_assoc($kbtebu)){
  if($kejenuhanbasa == $rowkb12['s1']){
    $c10t=1;
  }elseif($kejenuhanbasa == $rowkb12['s2']){
    $c10t=0.75;
  }elseif($kejenuhanbasa == $rowkb12['s3']){
    $c10t=0.5;
  }elseif($kejenuhanbasa == $rowkb12['n']){
    $c10t=0.25;
  }elseif($kejenuhanbasa == $rowkb12['kosong']){
    $c10t=0.25;
  }
}
while($rowph12 = mysqli_fetch_assoc($phtebu)){
  if($phh2o == $rowph12['s1']){
    $c11t=1;
  }elseif($phh2o == $rowph12['s2']){
    $c11t=0.75;
  }elseif($phh2o == $rowph12['s3']){
    $c11t=0.5;
  }elseif($phh2o == $rowph12['n']){
    $c11t=0.25;
  }elseif($phh2o == $rowph12['kosong']){
    $c11t=0.25;
  }
}
while($rowcorg12 = mysqli_fetch_assoc($corgtebu)){
  if($corganik == $rowcorg12['s1']){
    $c12t=1;
  }elseif($corganik == $rowcorg12['s2']){
    $c12t=0.75;
  }elseif($corganik == $rowcorg12['s3']){
    $c12t=0.5;
  }elseif($corganik == $rowcorg12['n']){
    $c12t=0.25;
  }elseif($corganik == $rowcorg12['kosong']){
    $c12t=0.25;
  }
}
while($rowntotal12 = mysqli_fetch_assoc($ntotaltebu)){
  if($ntotal == $rowntotal12['s1']){
    $c13t=1;
  }elseif($ntotal == $rowntotal12['s2']){
    $c13t=0.75;
  }elseif($ntotal == $rowntotal12['s3']){
    $c13t=0.5;
  }elseif($ntotal == $rowntotal12['n']){
    $c13t=0.25;
  }elseif($ntotal == $rowntotal12['kosong']){
    $c13t=0.25;
  }
}
while($rowp212 = mysqli_fetch_assoc($p2tebu)){
  if($p2o5 == $rowp212['s1']){
    $c14t=1;
  }elseif($p2o5 == $rowp212['s2']){
    $c14t=0.75;
  }elseif($p2o5 == $rowp212['s3']){
    $c14t=0.5;
  }elseif($p2o5 == $rowp212['n']){
    $c14t=0.25;
  }elseif($p2o5 == $rowp212['kosong']){
    $c14t=0.25;
  }
}
while($rowk212 = mysqli_fetch_assoc($k2tebu)){
  if($k2o == $rowk212['s1']){
    $c15t=1;
  }elseif($k2o == $rowk212['s2']){
    $c15t=0.75;
  }elseif($k2o == $rowk212['s3']){
    $c15t=0.5;
  }elseif($k2o == $rowk212['n']){
    $c15t=0.25;
  }elseif($k2o == $rowk212['kosong']){
    $c15t=0.25;
  }
}
while($rowsali12 = mysqli_fetch_assoc($salitebu)){
  if($salinitas == $rowsali12['s1']){
    $c16t=1;
  }elseif($salinitas == $rowsali12['s2']){
    $c16t=0.75;
  }elseif($salinitas == $rowsali12['s3']){
    $c16t=0.5;
  }elseif($salinitas == $rowsali12['n']){
    $c16t=0.25;
  }elseif($salinitas == $rowsali12['kosong']){
    $c16t=0.25;
  }
}
while($rowalkali12 = mysqli_fetch_assoc($alkalitebu)){
  if($alkalinitas == $rowalkali12['s1']){
    $c17t=1;
  }elseif($alkalinitas == $rowalkali12['s2']){
    $c17t=0.75;
  }elseif($alkalinitas == $rowalkali12['s3']){
    $c17t=0.5;
  }elseif($alkalinitas == $rowalkali12['n']){
    $c17t=0.25;
  }elseif($alkalinitas == $rowalkali12['kosong']){
    $c17t=0.25;
  }
}
while($rowks12 = mysqli_fetch_assoc($kstebu)){
  if($kedalamansulfidik == $rowks12['s1']){
    $c18t=1;
  }elseif($kedalamansulfidik == $rowks12['s2']){
    $c18t=0.75;
  }elseif($kedalamansulfidik == $rowks12['s3']){
    $c18t=0.5;
  }elseif($kedalamansulfidik == $rowks12['n']){
    $c18t=0.25;
  }elseif($kedalamansulfidik == $rowks12['kosong']){
    $c18t=0.25;
  }
}
while($rowler12 = mysqli_fetch_assoc($lertebu)){
  if($lereng == $rowler12['s1']){
    $c19t=1;
  }elseif($lereng == $rowler12['s2']){
    $c19t=0.75;
  }elseif($lereng == $rowler12['s3']){
    $c19t=0.5;
  }elseif($lereng == $rowler12['n']){
    $c19t=0.25;
  }elseif($lereng == $rowler12['kosong']){
    $c19t=0.25;
  }
}
while($rowbe12 = mysqli_fetch_assoc($betebu)){
  if($bahayaerosi == $rowbe12['s1']){
    $c20t=1;
  }elseif($bahayaerosi == $rowbe12['s2']){
    $c20t=0.75;
  }elseif($bahayaerosi == $rowbe12['s3']){
    $c20t=0.5;
  }elseif($bahayaerosi == $rowbe12['n']){
    $c20t=0.25;
  }elseif($bahayaerosi == $rowbe12['kosong']){
    $c20t=0.25;
  }
}
while($rowtb12 = mysqli_fetch_assoc($tbtebu)){
  if($tinggigenangan == $rowtb12['s1']){
    $c21t=1;
  }elseif($tinggigenangan == $rowtb12['s2']){
    $c21t=0.75;
  }elseif($tinggigenangan == $rowtb12['s3']){
    $c21t=0.5;
  }elseif($tinggigenangan == $rowtb12['n']){
    $c21t=0.25;
  }elseif($tinggigenangan == $rowtb12['kosong']){
    $c21t=0.25;
  }
}
while($rowlb12 = mysqli_fetch_assoc($lbtebu)){
  if($lamagenangan == $rowlb12['s1']){
    $c22t=1;
  }elseif($lamagenangan == $rowlb12['s2']){
    $c22t=0.75;
  }elseif($lamagenangan == $rowlb12['s3']){
    $c22t=0.5;
  }elseif($lamagenangan == $rowlb12['n']){
    $c22t=0.25;
  }elseif($lamagenangan == $rowlb12['kosong']){
    $c22t=0.25;
  }
}
while($rowbatu12 = mysqli_fetch_assoc($batutebu)){
  if($batuan == $rowbatu12['s1']){
    $c23t=1;
  }elseif($batuan == $rowbatu12['s2']){
    $c23t=0.75;
  }elseif($batuan == $rowbatu12['s3']){
    $c23t=0.5;
  }elseif($batuan == $rowbatu12['n']){
    $c23t=0.25;
  }elseif($batuan == $rowbatu12['kosong']){
    $c23t=0.25;
  }
}
while($rowsing12 = mysqli_fetch_assoc($singtebu)){
  if($singkapan == $rowsing12['s1']){
    $c24t=1;
  }elseif($singkapan == $rowsing12['s2']){
    $c24t=0.75;
  }elseif($singkapan == $rowsing12['s3']){
    $c24t=0.5;
  }elseif($singkapan == $rowsing12['n']){
    $c24t=0.25;
  }elseif($singkapan == $rowsing12['kosong']){
    $c24t=0.25;
  }
}
while($rowcht12 = mysqli_fetch_assoc($chttebu)){
  if($curahhujan == $rowcht12['s1']){
    $c25t=1; 
  }elseif($curahhujan == $rowcht12['s2']){
    $c25t=0.75; 
  }elseif($curahhujan == $rowcht12['s3']){
    $c25t=0.5;
  }elseif($curahhujan == $rowcht12['n']){
    $c25t=0.25;
  }elseif($curahhujan == $rowcht12['kosong']){
    $c25t=0.25;
  }
}


//RUMPUT GAJAH
while($rowtemp13 = mysqli_fetch_assoc($temprumput)){
  if($temperatur == $rowtemp13['s1']){
    $c1r=1;
  }elseif($temperatur == $rowtemp13['s2']){
    $c1r=0.75;
  }elseif($temperatur == $rowtemp13['s3']){
    $c1r=0.5;
  }elseif($temperatur == $rowtemp13['n']){
    $c1r=0.25;
  }elseif($temperatur == $rowtemp13['kosong']){
    $c1r=0.25;
  }
}
while($rowka13 = mysqli_fetch_assoc($karumput)){
  if($ketersediaanair == $rowka13['s1']){
    $c2r=1;
  }elseif($ketersediaanair == $rowka13['s2']){
    $c2r=0.75;
  }elseif($ketersediaanair == $rowka13['s3']){
    $c2r=0.5;
  }elseif($ketersediaanair == $rowka13['n']){
    $c2r=0.25;
  }elseif($ketersediaanair == $rowka13['kosong']){
    $c2r=0.25;
  }
}
while($rowdrain13 = mysqli_fetch_assoc($drainrumput)){
  if($drainase == $rowdrain13['s1']){
    $c3r=1;
  }elseif($drainase == $rowdrain13['s2']){
    $c3r=0.75;
  }elseif($drainase == $rowdrain13['s3']){
    $c3r=0.5;
  }elseif($drainase == $rowdrain13['n']){
    $c3r=0.25;
  }elseif($drainase == $rowdrain13['kosong']){
    $c3r=0.25;
  }
}
while($rowteks13 = mysqli_fetch_assoc($teksrumput)){
  if($tekstur == $rowteks13['s1']){
    $c4r=1;
  }elseif($tekstur == $rowteks13['s2']){
    $c4r=0.75;
  }elseif($tekstur == $rowteks13['s3']){
    $c4r=0.5;
  }elseif($tekstur == $rowteks13['n']){
    $c4r=0.25;
  }elseif($tekstur == $rowteks13['kosong']){
    $c4r=0.25;
  }
}
while($rowbk13 = mysqli_fetch_assoc($bkrumput)){
  if($bahankasar == $rowbk13['s1']){
    $c5r=1;
  }elseif($bahankasar == $rowbk13['s2']){
    $c5r=0.75;
  }elseif($bahankasar == $rowbk13['s3']){
    $c5r=0.5;
  }elseif($bahankasar == $rowbk13['n']){
    $c5r=0.25;
  }elseif($bahankasar == $rowbk13['kosong']){
    $c5r=0.25;
  }
}
while($rowkt13 = mysqli_fetch_assoc($ktrumput)){
  if($kedalamantanah == $rowkt13['s1']){
    $c6r=1;
  }elseif($kedalamantanah == $rowkt13['s2']){
    $c6r=0.75;
  }elseif($kedalamantanah == $rowkt13['s3']){
    $c6r=0.5;
  }elseif($kedalamantanah == $rowkt13['n']){
    $c6r=0.25;
  }elseif($kedalamantanah == $rowkt13['kosong']){
    $c6r=0.25;
  }
}
while($rowkg13 = mysqli_fetch_assoc($kgrumput)){
  if($ketebalangambut == $rowkg13['s1']){
    $c7r=1;
  }elseif($ketebalangambut == $rowkg13['s2']){
    $c7r=0.75;
  }elseif($ketebalangambut == $rowkg13['s3']){
    $c7r=0.5;
  }elseif($ketebalangambut == $rowkg13['n']){
    $c7r=0.25;
  }elseif($ketebalangambut == $rowkg13['kosong']){
    $c7r=0.25;
  }
}
while($rowktg13 = mysqli_fetch_assoc($ktgrumput)){
  if($kematangan == $rowktg13['s1']){
    $c8r=1;
  }elseif($kematangan == $rowktg13['s2']){
    $c8r=0.75;
  }elseif($kematangan == $rowktg13['s3']){
    $c8r=0.5;
  }elseif($kematangan == $rowktg13['n']){
    $c8r=0.25;
  }elseif($kematangan == $rowktg13['kosong']){
    $c8r=0.25;
  }
}
while($rowktk13 = mysqli_fetch_assoc($ktkrumput)){
  if($ktktanah == $rowktk13['s1']){
    $c9r=1;
  }elseif($ktktanah == $rowktk13['s2']){
    $c9r=0.75;
  }elseif($ktktanah == $rowktk13['s3']){
    $c9r=0.5;
  }elseif($ktktanah == $rowktk13['n']){
    $c9r=0.25;
  }elseif($ktktanah == $rowktk13['kosong']){
    $c9r=0.25;
  }
}
while($rowkb13 = mysqli_fetch_assoc($kbrumput)){
  if($kejenuhanbasa == $rowkb13['s1']){
    $c10r=1;
  }elseif($kejenuhanbasa == $rowkb13['s2']){
    $c10r=0.75;
  }elseif($kejenuhanbasa == $rowkb13['s3']){
    $c10r=0.5;
  }elseif($kejenuhanbasa == $rowkb13['n']){
    $c10r=0.25;
  }elseif($kejenuhanbasa == $rowkb13['kosong']){
    $c10r=0.25;
  }
}
while($rowph13 = mysqli_fetch_assoc($phrumput)){
  if($phh2o == $rowph13['s1']){
    $c11r=1;
  }elseif($phh2o == $rowph13['s2']){
    $c11r=0.75;
  }elseif($phh2o == $rowph13['s3']){
    $c11r=0.5;
  }elseif($phh2o == $rowph13['n']){
    $c11r=0.25;
  }elseif($phh2o == $rowph13['kosong']){
    $c11r=0.25;
  }
}
while($rowcorg13 = mysqli_fetch_assoc($corgrumput)){
  if($corganik == $rowcorg13['s1']){
    $c12r=1;
  }elseif($corganik == $rowcorg13['s2']){
    $c12r=0.75;
  }elseif($corganik == $rowcorg13['s3']){
    $c12r=0.5;
  }elseif($corganik == $rowcorg13['n']){
    $c12r=0.25;
  }elseif($corganik == $rowcorg13['kosong']){
    $c12r=0.25;
  }
}
while($rowntotal13 = mysqli_fetch_assoc($ntotalrumput)){
  if($ntotal == $rowntotal13['s1']){
    $c13r=1;
  }elseif($ntotal == $rowntotal13['s2']){
    $c13r=0.75;
  }elseif($ntotal == $rowntotal13['s3']){
    $c13r=0.5;
  }elseif($ntotal == $rowntotal13['n']){
    $c13r=0.25;
  }elseif($ntotal == $rowntotal13['kosong']){
    $c13r=0.25;
  }
}
while($rowp213 = mysqli_fetch_assoc($p2rumput)){
  if($p2o5 == $rowp213['s1']){
    $c14r=1;
  }elseif($p2o5 == $rowp213['s2']){
    $c14r=0.75;
  }elseif($p2o5 == $rowp213['s3']){
    $c14r=0.5;
  }elseif($p2o5 == $rowp213['n']){
    $c14r=0.25;
  }elseif($p2o5 == $rowp213['kosong']){
    $c14r=0.25;
  }
}
while($rowk213 = mysqli_fetch_assoc($k2rumput)){
  if($k2o == $rowk213['s1']){
    $c15r=1;
  }elseif($k2o == $rowk213['s2']){
    $c15r=0.75;
  }elseif($k2o == $rowk213['s3']){
    $c15r=0.5;
  }elseif($k2o == $rowk213['n']){
    $c15r=0.25;
  }elseif($k2o == $rowk213['kosong']){
    $c15r=0.25;
  }
}
while($rowsali13 = mysqli_fetch_assoc($salirumput)){
  if($salinitas == $rowsali13['s1']){
    $c16r=1;
  }elseif($salinitas == $rowsali13['s2']){
    $c16r=0.75;
  }elseif($salinitas == $rowsali13['s3']){
    $c16r=0.5;
  }elseif($salinitas == $rowsali13['n']){
    $c16r=0.25;
  }elseif($salinitas == $rowsali13['kosong']){
    $c16r=0.25;
  }
}
while($rowalkali13 = mysqli_fetch_assoc($alkalirumput)){
  if($alkalinitas == $rowalkali13['s1']){
    $c17r=1;
  }elseif($alkalinitas == $rowalkali13['s2']){
    $c17r=0.75;
  }elseif($alkalinitas == $rowalkali13['s3']){
    $c17r=0.5;
  }elseif($alkalinitas == $rowalkali13['n']){
    $c17r=0.25;
  }elseif($alkalinitas == $rowalkali13['kosong']){
    $c17r=0.25;
  }
}
while($rowks13 = mysqli_fetch_assoc($ksrumput)){
  if($kedalamansulfidik == $rowks13['s1']){
    $c18r=1;
  }elseif($kedalamansulfidik == $rowks13['s2']){
    $c18r=0.75;
  }elseif($kedalamansulfidik == $rowks13['s3']){
    $c18r=0.5;
  }elseif($kedalamansulfidik == $rowks13['n']){
    $c18r=0.25;
  }elseif($kedalamansulfidik == $rowks13['kosong']){
    $c18r=0.25;
  }
}
while($rowler13 = mysqli_fetch_assoc($lerrumput)){
  if($lereng == $rowler13['s1']){
    $c19r=1;
  }elseif($lereng == $rowler13['s2']){
    $c19r=0.75;
  }elseif($lereng == $rowler13['s3']){
    $c19r=0.5;
  }elseif($lereng == $rowler13['n']){
    $c19r=0.25;
  }elseif($lereng == $rowler13['kosong']){
    $c19r=0.25;
  }
}
while($rowbe13 = mysqli_fetch_assoc($berumput)){
  if($bahayaerosi == $rowbe13['s1']){
    $c20r=1;
  }elseif($bahayaerosi == $rowbe13['s2']){
    $c20r=0.75;
  }elseif($bahayaerosi == $rowbe13['s3']){
    $c20r=0.5;
  }elseif($bahayaerosi == $rowbe13['n']){
    $c20r=0.25;
  }elseif($bahayaerosi == $rowbe13['kosong']){
    $c20r=0.25;
  }
}
while($rowtb13 = mysqli_fetch_assoc($tbrumput)){
  if($tinggigenangan == $rowtb13['s1']){
    $c21r=1;
  }elseif($tinggigenangan == $rowtb13['s2']){
    $c21r=0.75;
  }elseif($tinggigenangan == $rowtb13['s3']){
    $c21r=0.5;
  }elseif($tinggigenangan == $rowtb13['n']){
    $c21r=0.25;
  }elseif($tinggigenangan == $rowtb13['kosong']){
    $c21r=0.25;
  }
}
while($rowlb13 = mysqli_fetch_assoc($lbrumput)){
  if($lamagenangan == $rowlb13['s1']){
    $c22r=1;
  }elseif($lamagenangan == $rowlb13['s2']){
    $c22r=0.75;
  }elseif($lamagenangan == $rowlb13['s3']){
    $c22r=0.5;
  }elseif($lamagenangan == $rowlb13['n']){
    $c22r=0.25;
  }elseif($lamagenangan == $rowlb13['kosong']){
    $c22r=0.25;
  }
}
while($rowbatu13 = mysqli_fetch_assoc($baturumput)){
  if($batuan == $rowbatu13['s1']){
    $c23r=1;
  }elseif($batuan == $rowbatu13['s2']){
    $c23r=0.75;
  }elseif($batuan == $rowbatu13['s3']){
    $c23r=0.5;
  }elseif($batuan == $rowbatu13['n']){
    $c23r=0.25;
  }elseif($batuan == $rowbatu13['kosong']){
    $c23r=0.25;
  }
}
while($rowsing13 = mysqli_fetch_assoc($singrumput)){
  if($singkapan == $rowsing13['s1']){
    $c24r=1;
  }elseif($singkapan == $rowsing13['s2']){
    $c24r=0.75;
  }elseif($singkapan == $rowsing13['s3']){
    $c24r=0.5;
  }elseif($singkapan == $rowsing13['n']){
    $c24r=0.25;
  }elseif($singkapan == $rowsing13['kosong']){
    $c24r=0.25;
  }
}
while($rowcht13 = mysqli_fetch_assoc($chtrumput)){
  if($curahhujan == $rowcht13['s1']){
    $c25r=1; 
  }elseif($curahhujan == $rowcht13['s2']){
    $c25r=0.75; 
  }elseif($curahhujan == $rowcht13['s3']){
    $c25r=0.5;
  }elseif($curahhujan == $rowcht13['n']){
    $c25r=0.25;
  }elseif($curahhujan == $rowcht13['kosong']){
    $c25r=0.25;
  }
}


//SETARIA
while($rowtemp14 = mysqli_fetch_assoc($tempsetaria)){
  if($temperatur == $rowtemp14['s1']){
    $c1set=1;
  }elseif($temperatur == $rowtemp14['s2']){
    $c1set=0.75;
  }elseif($temperatur == $rowtemp14['s3']){
    $c1set=0.5;
  }elseif($temperatur == $rowtemp14['n']){
    $c1set=0.25;
  }elseif($temperatur == $rowtemp14['kosong']){
    $c1set=0.25;
  }
}
while($rowka14 = mysqli_fetch_assoc($kasetaria)){
  if($ketersediaanair == $rowka14['s1']){
    $c2set=1;
  }elseif($ketersediaanair == $rowka14['s2']){
    $c2set=0.75;
  }elseif($ketersediaanair == $rowka14['s3']){
    $c2set=0.5;
  }elseif($ketersediaanair == $rowka14['n']){
    $c2set=0.25;
  }elseif($ketersediaanair == $rowka14['kosong']){
    $c2set=0.25;
  }
}
while($rowdrain14 = mysqli_fetch_assoc($drainsetaria)){
  if($drainase == $rowdrain14['s1']){
    $c3set=1;
  }elseif($drainase == $rowdrain14['s2']){
    $c3set=0.75;
  }elseif($drainase == $rowdrain14['s3']){
    $c3set=0.5;
  }elseif($drainase == $rowdrain14['n']){
    $c3set=0.25;
  }elseif($drainase == $rowdrain14['kosong']){
    $c3set=0.25;
  }
}
while($rowteks14 = mysqli_fetch_assoc($tekssetaria)){
  if($tekstur == $rowteks14['s1']){
    $c4set=1;
  }elseif($tekstur == $rowteks14['s2']){
    $c4set=0.75;
  }elseif($tekstur == $rowteks14['s3']){
    $c4set=0.5;
  }elseif($tekstur == $rowteks14['n']){
    $c4set=0.25;
  }elseif($tekstur == $rowteks14['kosong']){
    $c4set=0.25;
  }
}
while($rowbk14 = mysqli_fetch_assoc($bksetaria)){
  if($bahankasar == $rowbk14['s1']){
    $c5set=1;
  }elseif($bahankasar == $rowbk14['s2']){
    $c5set=0.75;
  }elseif($bahankasar == $rowbk14['s3']){
    $c5set=0.5;
  }elseif($bahankasar == $rowbk14['n']){
    $c5set=0.25;
  }elseif($bahankasar == $rowbk14['kosong']){
    $c5set=0.25;
  }
}
while($rowkt14 = mysqli_fetch_assoc($ktsetaria)){
  if($kedalamantanah == $rowkt14['s1']){
    $c6set=1;
  }elseif($kedalamantanah == $rowkt14['s2']){
    $c6set=0.75;
  }elseif($kedalamantanah == $rowkt14['s3']){
    $c6set=0.5;
  }elseif($kedalamantanah == $rowkt14['n']){
    $c6set=0.25;
  }elseif($kedalamantanah == $rowkt14['kosong']){
    $c6set=0.25;
  }
}
while($rowkg14 = mysqli_fetch_assoc($kgsetaria)){
  if($ketebalangambut == $rowkg14['s1']){
    $c7set=1;
  }elseif($ketebalangambut == $rowkg14['s2']){
    $c7set=0.75;
  }elseif($ketebalangambut == $rowkg14['s3']){
    $c7set=0.5;
  }elseif($ketebalangambut == $rowkg14['n']){
    $c7set=0.25;
  }elseif($ketebalangambut == $rowkg14['kosong']){
    $c7set=0.25;
  }
}
while($rowktg14 = mysqli_fetch_assoc($ktgsetaria)){
  if($kematangan == $rowktg14['s1']){
    $c8set=1;
  }elseif($kematangan == $rowktg14['s2']){
    $c8set=0.75;
  }elseif($kematangan == $rowktg14['s3']){
    $c8set=0.5;
  }elseif($kematangan == $rowktg14['n']){
    $c8set=0.25;
  }elseif($kematangan == $rowktg14['kosong']){
    $c8set=0.25;
  }
}
while($rowktk14 = mysqli_fetch_assoc($ktksetaria)){
  if($ktktanah == $rowktk14['s1']){
    $c9set=1;
  }elseif($ktktanah == $rowktk14['s2']){
    $c9set=0.75;
  }elseif($ktktanah == $rowktk14['s3']){
    $c9set=0.5;
  }elseif($ktktanah == $rowktk14['n']){
    $c9set=0.25;
  }elseif($ktktanah == $rowktk14['kosong']){
    $c9set=0.25;
  }
}
while($rowkb14 = mysqli_fetch_assoc($kbsetaria)){
  if($kejenuhanbasa == $rowkb14['s1']){
    $c10set=1;
  }elseif($kejenuhanbasa == $rowkb14['s2']){
    $c10set=0.75;
  }elseif($kejenuhanbasa == $rowkb14['s3']){
    $c10set=0.5;
  }elseif($kejenuhanbasa == $rowkb14['n']){
    $c10set=0.25;
  }elseif($kejenuhanbasa == $rowkb14['kosong']){
    $c10set=0.25;
  }
}
while($rowph14 = mysqli_fetch_assoc($phsetaria)){
  if($phh2o == $rowph14['s1']){
    $c11set=1;
  }elseif($phh2o == $rowph14['s2']){
    $c11set=0.75;
  }elseif($phh2o == $rowph14['s3']){
    $c11set=0.5;
  }elseif($phh2o == $rowph14['n']){
    $c11set=0.25;
  }elseif($phh2o == $rowph14['kosong']){
    $c11set=0.25;
  }
}
while($rowcorg14 = mysqli_fetch_assoc($corgsetaria)){
  if($corganik == $rowcorg14['s1']){
    $c12set=1;
  }elseif($corganik == $rowcorg14['s2']){
    $c12set=0.75;
  }elseif($corganik == $rowcorg14['s3']){
    $c12set=0.5;
  }elseif($corganik == $rowcorg14['n']){
    $c12set=0.25;
  }elseif($corganik == $rowcorg14['kosong']){
    $c12set=0.25;
  }
}
while($rowntotal14 = mysqli_fetch_assoc($ntotalsetaria)){
  if($ntotal == $rowntotal14['s1']){
    $c13set=1;
  }elseif($ntotal == $rowntotal14['s2']){
    $c13set=0.75;
  }elseif($ntotal == $rowntotal14['s3']){
    $c13set=0.5;
  }elseif($ntotal == $rowntotal14['n']){
    $c13set=0.25;
  }elseif($ntotal == $rowntotal14['kosong']){
    $c13set=0.25;
  }
}
while($rowp214 = mysqli_fetch_assoc($p2setaria)){
  if($p2o5 == $rowp214['s1']){
    $c14set=1;
  }elseif($p2o5 == $rowp214['s2']){
    $c14set=0.75;
  }elseif($p2o5 == $rowp214['s3']){
    $c14set=0.5;
  }elseif($p2o5 == $rowp214['n']){
    $c14set=0.25;
  }elseif($p2o5 == $rowp214['kosong']){
    $c14set=0.25;
  }
}
while($rowk214 = mysqli_fetch_assoc($k2setaria)){
  if($k2o == $rowk214['s1']){
    $c15set=1;
  }elseif($k2o == $rowk214['s2']){
    $c15set=0.75;
  }elseif($k2o == $rowk214['s3']){
    $c15set=0.5;
  }elseif($k2o == $rowk214['n']){
    $c15set=0.25;
  }elseif($k2o == $rowk214['kosong']){
    $c15set=0.25;
  }
}
while($rowsali14 = mysqli_fetch_assoc($salisetaria)){
  if($salinitas == $rowsali14['s1']){
    $c16set=1;
  }elseif($salinitas == $rowsali14['s2']){
    $c16set=0.75;
  }elseif($salinitas == $rowsali14['s3']){
    $c16set=0.5;
  }elseif($salinitas == $rowsali14['n']){
    $c16set=0.25;
  }elseif($salinitas == $rowsali14['kosong']){
    $c16set=0.25;
  }
}
while($rowalkali14 = mysqli_fetch_assoc($alkalisetaria)){
  if($alkalinitas == $rowalkali14['s1']){
    $c17set=1;
  }elseif($alkalinitas == $rowalkali14['s2']){
    $c17set=0.75;
  }elseif($alkalinitas == $rowalkali14['s3']){
    $c17set=0.5;
  }elseif($alkalinitas == $rowalkali14['n']){
    $c17set=0.25;
  }elseif($alkalinitas == $rowalkali14['kosong']){
    $c17set=0.25;
  }
}
while($rowks14 = mysqli_fetch_assoc($kssetaria)){
  if($kedalamansulfidik == $rowks14['s1']){
    $c18set=1;
  }elseif($kedalamansulfidik == $rowks14['s2']){
    $c18set=0.75;
  }elseif($kedalamansulfidik == $rowks14['s3']){
    $c18set=0.5;
  }elseif($kedalamansulfidik == $rowks14['n']){
    $c18set=0.25;
  }elseif($kedalamansulfidik == $rowks14['kosong']){
    $c18set=0.25;
  }
}
while($rowler14 = mysqli_fetch_assoc($lersetaria)){
  if($lereng == $rowler14['s1']){
    $c19set=1;
  }elseif($lereng == $rowler14['s2']){
    $c19set=0.75;
  }elseif($lereng == $rowler14['s3']){
    $c19set=0.5;
  }elseif($lereng == $rowler14['n']){
    $c19set=0.25;
  }elseif($lereng == $rowler14['kosong']){
    $c19set=0.25;
  }
}
while($rowbe14 = mysqli_fetch_assoc($besetaria)){
  if($bahayaerosi == $rowbe14['s1']){
    $c20set=1;
  }elseif($bahayaerosi == $rowbe14['s2']){
    $c20set=0.75;
  }elseif($bahayaerosi == $rowbe14['s3']){
    $c20set=0.5;
  }elseif($bahayaerosi == $rowbe14['n']){
    $c20set=0.25;
  }elseif($bahayaerosi == $rowbe14['kosong']){
    $c20set=0.25;
  }
}
while($rowtb14 = mysqli_fetch_assoc($tbsetaria)){
  if($tinggigenangan == $rowtb14['s1']){
    $c21set=1;
  }elseif($tinggigenangan == $rowtb14['s2']){
    $c21set=0.75;
  }elseif($tinggigenangan == $rowtb14['s3']){
    $c21set=0.5;
  }elseif($tinggigenangan == $rowtb14['n']){
    $c21set=0.25;
  }elseif($tinggigenangan == $rowtb14['kosong']){
    $c21set=0.25;
  }
}
while($rowlb14 = mysqli_fetch_assoc($lbsetaria)){
  if($lamagenangan == $rowlb14['s1']){
    $c22set=1;
  }elseif($lamagenangan == $rowlb14['s2']){
    $c22set=0.75;
  }elseif($lamagenangan == $rowlb14['s3']){
    $c22set=0.5;
  }elseif($lamagenangan == $rowlb14['n']){
    $c22set=0.25;
  }elseif($lamagenangan == $rowlb14['kosong']){
    $c22set=0.25;
  }
}
while($rowbatu14 = mysqli_fetch_assoc($batusetaria)){
  if($batuan == $rowbatu14['s1']){
    $c23set=1;
  }elseif($batuan == $rowbatu14['s2']){
    $c23set=0.75;
  }elseif($batuan == $rowbatu14['s3']){
    $c23set=0.5;
  }elseif($batuan == $rowbatu14['n']){
    $c23set=0.25;
  }elseif($batuan == $rowbatu14['kosong']){
    $c23set=0.25;
  }
}
while($rowsing14 = mysqli_fetch_assoc($singsetaria)){
  if($singkapan == $rowsing14['s1']){
    $c24set=1;
  }elseif($singkapan == $rowsing14['s2']){
    $c24set=0.75;
  }elseif($singkapan == $rowsing14['s3']){
    $c24set=0.5;
  }elseif($singkapan == $rowsing14['n']){
    $c24set=0.25;
  }elseif($singkapan == $rowsing14['kosong']){
    $c24set=0.25;
  }
}
while($rowcht14 = mysqli_fetch_assoc($chtsetaria)){
  if($curahhujan == $rowcht14['s1']){
    $c25set=1; 
  }elseif($curahhujan == $rowcht14['s2']){
    $c25set=0.75; 
  }elseif($curahhujan == $rowcht14['s3']){
    $c25set=0.5;
  }elseif($curahhujan == $rowcht14['n']){
    $c25set=0.25;
  }elseif($curahhujan == $rowcht14['kosong']){
    $c25set=0.25;
  }
}


$sqlm1="insert into matching (tanaman, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14) values ('Padi Sawah Irigasi','$c1p','$c2p','$c3p','$c4p','$c5p','$c6p','$c7p','$c8p','$c9p','$c10p','$c11p','$c12p','$c13p','$c14p')"; 
$hasilm1=mysqli_query($kon,$sqlm1);
$sqlm4="insert into matching (tanaman, c1, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14) values ('Padi Sawah Tadah Hujan','$c1psth','$c2psth','$c3psth','$c4psth','$c5psth','$c6psth','$c7psth','$c8psth','$c9psth','$c10psth','$c11psth','$c12psth','$c13psth','$c14psth')";
$hasilm4=mysqli_query($kon,$sqlm4);
$sqlm5="insert into matching (tanaman, c1, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14) values ('Padi Gogo','$c1pgogo','$c2pgogo','$c3pgogo','$c4pgogo','$c5pgogo','$c6pgogo','$c7pgogo','$c8pgogo','$c9pgogo','$c10pgogo','$c11pgogo','$c12pgogo','$c13pgogo','$c14pgogo')";
$hasilm5=mysqli_query($kon,$sqlm5);
$sqlm6="insert into matching (tanaman, c1, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14) values ('Padi Sawah Rawa Pasang Surut','$c1psrps','$c2psrps','$c3psrps','$c4psrps','$c5psrps','$c6psrps','$c7psrps','$c8psrps','$c9psrps','$c10psrps','$c11psrps','$c12psrps','$c13psrps','$c14psrps')";
$hasilm6=mysqli_query($kon,$sqlm6);
$sqlm7="insert into matching (tanaman, c1, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14) values ('Padi Sawah Rawa Lebak','$c1psrl','$c2psrl','$c3psrl','$c4psrl','$c5psrl','$c6psrl','$c7psrl','$c8psrl','$c9psrl','$c10psrl','$c11psrl','$c12psrl','$c13psrl','$c14psrl')";
$hasilm7=mysqli_query($kon,$sqlm7);
$sqlm2="insert into matching (tanaman, c1, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14) values ('Jagung','$c1j','$c2j','$c3j','$c4j','$c5j','$c6j','$c7j','$c8j','$c9j','$c10j','$c11j','$c12j','$c13j','$c14j')";
$hasilm2=mysqli_query($kon,$sqlm2);
$sqlm3="insert into matching (tanaman, c1, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14) values ('Kedelai','$c1k','$c2k','$c3k','$c4k','$c5k','$c6k','$c7k','$c8k','$c9k','$c10k','$c11k','$c12k','$c13k','$c14k')";
$hasilm3=mysqli_query($kon,$sqlm3);
$sqlm8="insert into matching (tanaman, c1, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14) values ('Bawang Merah','$c1b','$c2b','$c3b','$c4b','$c5b','$c6b','$c7b','$c8b','$c9b','$c10b','$c11b','$c12b','$c13b','$c14b')";
$hasilm8=mysqli_query($kon,$sqlm8);
$sqlm9="insert into matching (tanaman, c1, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14) values ('Cabai Merah','$c1c','$c2c','$c3c','$c4c','$c5c','$c6c','$c7c','$c8c','$c9c','$c10c','$c11c','$c12c','$c13c','$c14c')";
$hasilm9=mysqli_query($kon,$sqlm9);
$sqlm10="insert into matching (tanaman, c1, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14) values ('Kelapa Sawit','$c1s','$c2s','$c3s','$c4s','$c5s','$c6s','$c7s','$c8s','$c9s','$c10s','$c11s','$c12s','$c13s','$c14s')";
$hasilm10=mysqli_query($kon,$sqlm10);
$sqlm11="insert into matching (tanaman, c1, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14) values ('Kakao','$c1ka','$c2ka','$c3ka','$c4ka','$c5ka','$c6ka','$c7ka','$c8ka','$c9ka','$c10ka','$c11ka','$c12ka','$c13ka','$c14ka')";
$hasilm11=mysqli_query($kon,$sqlm11);
$sqlm12="insert into matching (tanaman, c1, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14) values ('Tebu','$c1t','$c2t','$c3t','$c4t','$c5t','$c6t','$c7t','$c8t','$c9t','$c10t','$c11t','$c12t','$c13t','$c14t')";
$hasilm12=mysqli_query($kon,$sqlm12);
$sqlm13="insert into matching (tanaman, c1, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14) values ('Rumput Gajah','$c1r','$c2r','$c3r','$c4r','$c5r','$c6r','$c7r','$c8r','$c9r','$c10r','$c11r','$c12r','$c13r','$c14r')";
$hasilm13=mysqli_query($kon,$sqlm13);
$sqlm14="insert into matching (tanaman, c1, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14) values ('Setaria','$c1set','$c2set','$c3set','$c4set','$c5set','$c6set','$c7set','$c8set','$c9set','$c10set','$c11set','$c12set','$c13set','$c14set')";
$hasilm14=mysqli_query($kon,$sqlm14);


?>
