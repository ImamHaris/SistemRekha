<?php
          
//C1
$maxc1 = max($c1p,$c1j,$c1k,$c1psth,$c1pgogo,$c1psrps,$c1psrl,$c1b,$c1c,$c1s,$c1ka,$c1t,$c1r,$c1set);
$minc1 = min($c1p,$c1j,$c1k,$c1psth,$c1pgogo,$c1psrps,$c1psrl,$c1b,$c1c,$c1s,$c1ka,$c1t,$c1r,$c1set);

//C2
$maxc2 = max($c2p,$c2j,$c2k,$c2psth,$c2pgogo,$c2psrps,$c2psrl,$c2b,$c2c,$c2s,$c2ka,$c2t,$c2r,$c2set);
$minc2 = min($c2p,$c2j,$c2k,$c2psth,$c2pgogo,$c2psrps,$c2psrl,$c2b,$c2c,$c2s,$c2ka,$c2t,$c2r,$c2set);

//C3
$maxc3 = max($c3p,$c3j,$c3k,$c3psth,$c3pgogo,$c3psrps,$c3psrl,$c3b,$c3c,$c3s,$c3ka,$c3t,$c3r,$c3set);
$minc3 = min($c3p,$c3j,$c3k,$c3psth,$c3pgogo,$c3psrps,$c3psrl,$c3b,$c3c,$c3s,$c3ka,$c3t,$c3r,$c3set);

//C4
$maxc4 = max($c4p,$c4j,$c4k,$c4psth,$c4pgogo,$c4psrps,$c4psrl,$c4b,$c4c,$c4s,$c4ka,$c4t,$c4r,$c4set);
$minc4 = min($c4p,$c4j,$c4k,$c4psth,$c4pgogo,$c4psrps,$c4psrl,$c4b,$c4c,$c4s,$c4ka,$c4t,$c4r,$c4set);

//C5
$maxc5 = max($c5p,$c5j,$c5k,$c5psth,$c5pgogo,$c5psrps,$c5psrl,$c5b,$c5c,$c5s,$c5ka,$c5t,$c5r,$c5set);
$minc5 = min($c5p,$c5j,$c5k,$c5psth,$c5pgogo,$c5psrps,$c5psrl,$c5b,$c5c,$c5s,$c5ka,$c5t,$c5r,$c5set);

//C6
$maxc6 = max($c6p,$c6j,$c6k,$c6psth,$c6pgogo,$c6psrps,$c6psrl,$c6b,$c6c,$c6s,$c6ka,$c6t,$c6r,$c6set);
$minc6 = min($c6p,$c6j,$c6k,$c6psth,$c6pgogo,$c6psrps,$c6psrl,$c6b,$c6c,$c6s,$c6ka,$c6t,$c6r,$c6set);


//C7
$maxc7 = max($c7p,$c7j,$c7k,$c7psth,$c7pgogo,$c7psrps,$c7psrl,$c7b,$c7c,$c7s,$c7ka,$c7t,$c7r,$c7set);
$minc7 = min($c7p,$c7j,$c7k,$c7psth,$c7pgogo,$c7psrps,$c7psrl,$c7b,$c7c,$c7s,$c7ka,$c7t,$c7r,$c7set);

//C8
$maxc8 = max($c8p,$c8j,$c8k,$c8psth,$c8pgogo,$c8psrps,$c8psrl,$c8b,$c8c,$c8s,$c8ka,$c8t,$c8r,$c8set);
$minc8 = min($c8p,$c8j,$c8k,$c8psth,$c8pgogo,$c8psrps,$c8psrl,$c8b,$c8c,$c8s,$c8ka,$c8t,$c8r,$c8set);

//C9
$maxc9 = max($c9p,$c9j,$c9k,$c9psth,$c9pgogo,$c9psrps,$c9psrl,$c9b,$c9c,$c9s,$c9ka,$c9t,$c9r,$c9set);
$minc9 = min($c9p,$c9j,$c9k,$c9psth,$c9pgogo,$c9psrps,$c9psrl,$c9b,$c9c,$c9s,$c9ka,$c9t,$c9r,$c9set);

//C10
$maxc10 = max($c10p,$c10j,$c10k,$c10psth,$c10pgogo,$c10psrps,$c10psrl,$c10b,$c10c,$c10s,$c10ka,$c10t,$c10r,$c10set);
$minc10 = min($c10p,$c10j,$c10k,$c10psth,$c10pgogo,$c10psrps,$c10psrl,$c10b,$c10c,$c10s,$c10ka,$c10t,$c10r,$c10set);

//C11
$maxc11 = max($c11p,$c11j,$c11k,$c11psth,$c11pgogo,$c11psrps,$c11psrl,$c11b,$c11c,$c11s,$c11ka,$c11t,$c11r,$c11set);
$minc11 = min($c11p,$c11j,$c11k,$c11psth,$c11pgogo,$c11psrps,$c11psrl,$c11b,$c11c,$c11s,$c11ka,$c11t,$c11r,$c11set);

//C12
$maxc12 = max($c12p,$c12j,$c12k,$c12psth,$c12pgogo,$c12psrps,$c12psrl,$c12b,$c12c,$c12s,$c12ka,$c12t,$c12r,$c12set);
$minc12 = min($c12p,$c12j,$c12k,$c12psth,$c12pgogo,$c12psrps,$c12psrl,$c12b,$c12c,$c12s,$c12ka,$c12t,$c12r,$c12set);

//C13
$maxc13 = max($c13p,$c13j,$c13k,$c13psth,$c13pgogo,$c13psrps,$c13psrl,$c13b,$c13c,$c13s,$c13ka,$c13t,$c13r,$c13set);
$minc13 = min($c13p,$c13j,$c13k,$c13psth,$c13pgogo,$c13psrps,$c13psrl,$c13b,$c13c,$c13s,$c13ka,$c13t,$c13r,$c13set);

//C14
$maxc14 = max($c14p,$c14j,$c14k,$c14psth,$c14pgogo,$c14psrps,$c14psrl,$c14b,$c14c,$c14s,$c14ka,$c14t,$c14r,$c14set);
$minc14 = min($c14p,$c14j,$c14k,$c14psth,$c14pgogo,$c14psrps,$c14psrl,$c14b,$c14c,$c14s,$c14ka,$c14t,$c14r,$c14set);

//C15
$maxc15 = max($c15p,$c15j,$c15k,$c15psth,$c15pgogo,$c15psrps,$c15psrl,$c15b,$c15c,$c15s,$c15ka,$c15t,$c15r,$c15set);
$minc15 = min($c15p,$c15j,$c15k,$c15psth,$c15pgogo,$c15psrps,$c15psrl,$c15b,$c15c,$c15s,$c15ka,$c15t,$c15r,$c15set);

//C16
$maxc16 = max($c16p,$c16j,$c16k,$c16psth,$c16pgogo,$c16psrps,$c16psrl,$c16b,$c16c,$c16s,$c16ka,$c16t,$c16r,$c16set);
$minc16 = min($c16p,$c16j,$c16k,$c16psth,$c16pgogo,$c16psrps,$c16psrl,$c16b,$c16c,$c16s,$c16ka,$c16t,$c16r,$c16set);

//C17
$maxc17 = max($c17p,$c17j,$c17k,$c17psth,$c17pgogo,$c17psrps,$c17psrl,$c17b,$c17c,$c17s,$c17ka,$c17t,$c17r,$c17set);
$minc17 = min($c17p,$c17j,$c17k,$c17psth,$c17pgogo,$c17psrps,$c17psrl,$c17b,$c17c,$c17s,$c17ka,$c17t,$c17r,$c17set);

//C18
$maxc18 = max($c18p,$c18j,$c18k,$c18psth,$c18pgogo,$c18psrps,$c18psrl,$c18b,$c18c,$c18s,$c18ka,$c18t,$c18r,$c18set);
$minc18 = min($c18p,$c18j,$c18k,$c18psth,$c18pgogo,$c18psrps,$c18psrl,$c18b,$c18c,$c18s,$c18ka,$c18t,$c18r,$c18set);

//C19
$maxc19 = max($c19p,$c19j,$c19k,$c19psth,$c19pgogo,$c19psrps,$c19psrl,$c19b,$c19c,$c19s,$c19ka,$c19t,$c19r,$c19set);
$minc19 = min($c19p,$c19j,$c19k,$c19psth,$c19pgogo,$c19psrps,$c19psrl,$c19b,$c19c,$c19s,$c19ka,$c19t,$c19r,$c19set);

//C20
$maxc20 = max($c20p,$c20j,$c20k,$c20psth,$c20pgogo,$c20psrps,$c20psrl,$c20b,$c20c,$c20s,$c20ka,$c20t,$c20r,$c20set);
$minc20 = min($c20p,$c20j,$c20k,$c20psth,$c20pgogo,$c20psrps,$c20psrl,$c20b,$c20c,$c20s,$c20ka,$c20t,$c20r,$c20set);

//C21
$maxc21 = max($c21p,$c21j,$c21k,$c21psth,$c21pgogo,$c21psrps,$c21psrl,$c21b,$c21c,$c21s,$c21ka,$c21t,$c21r,$c21set);
$minc21 = min($c21p,$c21j,$c21k,$c21psth,$c21pgogo,$c21psrps,$c21psrl,$c21b,$c21c,$c21s,$c21ka,$c21t,$c21r,$c21set);

//C22
$maxc22 = max($c22p,$c22j,$c22k,$c22psth,$c22pgogo,$c22psrps,$c22psrl,$c22b,$c22c,$c22s,$c22ka,$c22t,$c22r,$c22set);
$minc22 = min($c22p,$c22j,$c22k,$c22psth,$c22pgogo,$c22psrps,$c22psrl,$c22b,$c22c,$c22s,$c22ka,$c22t,$c22r,$c22set);

//C23
$maxc23 = max($c23p,$c23j,$c23k,$c23psth,$c23pgogo,$c23psrps,$c23psrl,$c23b,$c23c,$c23s,$c23ka,$c23t,$c23r,$c23set);
$minc23 = min($c23p,$c23j,$c23k,$c23psth,$c23pgogo,$c23psrps,$c23psrl,$c23b,$c23c,$c23s,$c23ka,$c23t,$c23r,$c23set);

//C24
$maxc24 = max($c24p,$c24j,$c24k,$c24psth,$c24pgogo,$c24psrps,$c24psrl,$c24b,$c24c,$c24s,$c24ka,$c24t,$c24r,$c24set);
$minc24 = min($c24p,$c24j,$c24k,$c24psth,$c24pgogo,$c24psrps,$c24psrl,$c24b,$c24c,$c24s,$c24ka,$c24t,$c24r,$c24set);

//C25
$maxc25 = max($c25p,$c25j,$c25k,$c25psth,$c25pgogo,$c25psrps,$c25psrl,$c25b,$c25c,$c25s,$c25ka,$c25t,$c25r,$c25set);
$minc25 = min($c25p,$c25j,$c25k,$c25psth,$c25pgogo,$c25psrps,$c25psrl,$c25b,$c25c,$c25s,$c25ka,$c25t,$c25r,$c25set);


?>