<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?");
	}
?>
<!doctype html>
<html class="no-js h-100" lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Sistem Rekomendasi Kesesuaian Lahan</title>
    <meta name="description" content="A high-quality &amp; free Bootstrap admin dashboard template pack that comes with lots of templates and components.">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" id="main-stylesheet" data-version="1.1.0" href="styles/shards-dashboards.1.1.0.min.css">
    <link rel="stylesheet" href="styles/extras.1.1.0.min.css">
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </head>
  <body class="h-100">
    <div class="container-fluid">
      <div class="row">
        <!-- Main Sidebar -->
        <aside class="main-sidebar col-12 col-md-3 col-lg-2 px-0">
          <div class="main-navbar">
            <nav class="navbar align-items-stretch navbar-light bg-white flex-md-nowrap border-bottom p-0">
              <a class="navbar-brand w-100 mr-0" href="#" style="line-height: 25px;">
                <div class="d-table m-auto">
                  <img id="main-logo" class="d-inline-block align-top mr-1" style="max-width: 25px;" src="images/logo.png" alt="Shards Dashboard">
                  <span class="d-none d-md-inline ml-1">Sistem Rekomendasi</span>
                </div>
              </a>
              <a class="toggle-sidebar d-sm-inline d-md-none d-lg-none">
                <i class="material-icons">&#xE5C4;</i>
              </a>
            </nav>
          </div>
          <form action="#" class="main-sidebar__search w-100 border-right d-sm-flex d-md-none d-lg-none">
            <div class="input-group input-group-seamless ml-3">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fas fa-search"></i>
                </div>
              </div>
              <input class="navbar-search form-control" type="text" placeholder="Search for something..." aria-label="Search"> </div>
          </form>
          <div class="nav-wrapper">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link " href="index.php">
                  <i class="material-icons">edit</i>
                  <span>Dashboard</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="prediksi.php">
                  <i class="material-icons">view_module</i>
                  <span>Prediksi</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="tipsbertani.php">
                  <i class="material-icons">view_module</i>
                  <span>Tips Bertani</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="user-profile.php">
                  <i class="material-icons">person</i>
                  <span>Profil Pengguna</span>
                </a>
              </li>
            </ul>
          </div>
        </aside>
        <!-- End Main Sidebar -->
        <main class="main-content col-lg-10 col-md-9 col-sm-12 p-0 offset-lg-2 offset-md-3">
          <div class="main-navbar sticky-top bg-white">
            <!-- Main Navbar -->
            <nav class="navbar align-items-stretch navbar-light flex-md-nowrap p-0">
              <form action="#" class="main-navbar__search w-100 d-none d-md-flex d-lg-flex">
                <div class="input-group input-group-seamless ml-3">
                  <div class="input-group-prepend">
                    <div class="input-group-text">
                      <i class="fas fa-search"></i>
                    </div>
                  </div>
                  <input class="navbar-search form-control" type="text" placeholder="Cari..." aria-label="Search"> </div>
              </form>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle text-nowrap px-3" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <img class="user-avatar rounded-circle mr-2" src="images/avatars/unnamed.png" alt="User Avatar">
                    <span class="d-none d-md-inline-block"><?php echo $_SESSION['username']; ?></span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-small">
                    <a class="dropdown-item" href="user-profile.php">
                      <i class="material-icons">&#xE7FD;</i> Profile</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item text-danger" href="logout.php">
                      <i class="material-icons text-danger">&#xE879;</i> Logout </a>
                  </div>
                </li>
              </ul>
              <nav class="nav">
                <a href="#" class="nav-link nav-link-icon toggle-sidebar d-md-inline d-lg-none text-center border-left" data-toggle="collapse" data-target=".header-navbar" aria-expanded="false" aria-controls="header-navbar">
                  <i class="material-icons">&#xE5D2;</i>
                </a>
              </nav>
            </nav>
          </div>
          <!-- / .main-navbar -->
          <div class="main-content-container container-fluid px-4">
            <!-- Page Header -->
            <div class="page-header row no-gutters py-4 mb-3 border-bottom">
              <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
                <span class="text-uppercase page-subtitle">Prediksi</span>
                <h3 class="page-title">Masukkan Data Tanah</h3>
              </div>
            </div>
            <!-- End Page Header -->
            <div class="row">
              <div class="col">
                <form action="hasilprediksi.php" method="post">
                <div class="card card-small mb-4">
                  <div class="card-header border-bottom">
                    <h6 class="m-0">Form Masukkan</h6>
                  </div>
                  
                  <ul class="list-group list-group-flush">
                    <li class="list-group-item p-3">
                      <div class="row">
                        <div class="col-sm-12 col-md-6">
                          <strong class="text-muted d-block mb-2">Lokasi :</strong>
                              <div class="form-row">
                                <div class="form-group col-md-7">
                                  <input type="text" name="lokasi" class="form-control" required="" autofocus=""> 
                                </div>
                              </div> 
                          </div> 
                      </div>
                    </li>
                    <li class="list-group-item p-3">
                      <div class="row">
                        <div class="col-sm-12 col-md-4 mb-3">                        
                            <strong class="text-muted d-block mb-0">Temperatur (tc)</strong>
                            <h9 class="m-0">Temperatur rata-rata tahunan (C) :</h9>
                            <div class="form-row">
                              <div class="form-group col-md-7">
                                <select id="inputState" name="temperatur" class="form-control">
                                  <option selected>Pilih...</option>
                                  <option>0</option>
                                  <option>1</option>
                                  <option>2</option>
                                  <option>3</option>
                                  <option>4</option>
                                  <option>5</option>
                                  <option>6</option>
                                  <option>7</option>
                                  <option>8</option>
                                  <option>9</option>
                                  <option>10</option>
                                  <option>11</option>
                                  <option>12</option>
                                  <option>13</option>
                                  <option>14</option>
                                  <option>15</option>
                                  <option>16</option>
                                  <option>17</option>
                                  <option>18</option>
                                  <option>19</option>
                                  <option>20</option>
                                  <option>21</option>
                                  <option>22</option>
                                  <option>23</option>
                                  <option>24</option>
                                  <option>25</option>
                                  <option>26</option>
                                  <option>27</option>
                                  <option>28</option>
                                  <option>29</option>
                                  <option>30</option>
                                  <option>31</option>
                                  <option>32</option>
                                  <option>33</option>
                                  <option>34</option>
                                  <option>35</option>
                                  <option>36</option>
                                  <option>37</option>
                                  <option>38</option>
                                </select>
                              </div>
                            </div>
                            </br>
                            <strong class="text-muted d-block mb-0">Ketersediaan Air (wa)</strong>
                            <h9 class="m-0">Curah Hujan Tahunan (mm/th) :</h9>
                            <div class="form-row">
                              <div class="form-group col-md-7">
                                <select id="inputState" name="curahhujan" class="form-control">
                                  <option selected>Pilih...</option>
                                  <option>0</option>
                                  <option>100</option>
                                  <option>200</option>
                                  <option>300</option>
                                  <option>400</option>
                                  <option>500</option>
                                  <option>600</option>
                                  <option>700</option>
                                  <option>800</option>
                                  <option>900</option>
                                  <option>1000</option>
                                  <option>1100</option>
                                  <option>1200</option>
                                  <option>1300</option>
                                  <option>1400</option>
                                  <option>1500</option>
                                  <option>1600</option>
                                  <option>1700</option>
                                  <option>1800</option>
                                  <option>1900</option>
                                  <option>2000</option>
                                  <option>2100</option>
                                  <option>2200</option>
                                  <option>2300</option>
                                  <option>2400</option>
                                  <option>25000</option>
                                  <option>2600</option>
                                  <option>2700</option>
                                  <option>2800</option>
                                  <option>2900</option>
                                  <option>3000</option>
                                  <option>3100</option>
                                  <option>3200</option>
                                  <option>3300</option>
                                  <option>3400</option>
                                  <option>35000</option>
                                  <option>3600</option>
                                  <option>3700</option>
                                  <option>3800</option>
                                  <option>3900</option>
                                  <option>4000</option>
                                </select>
                              </div>
                            </div>
                            <h9 class="m-0">Jumlah Bulan Basah (>200 mm/bl) :</h9>
                            <div class="form-row">
                              <div class="form-group col-md-7">
                                <select id="inputState" name="ketersediaanair" class="form-control">
                                  <option selected>Pilih...</option>
                                  <option>0</option>
                                  <option>1</option>
                                  <option>2</option>
                                  <option>3</option>
                                  <option>4</option>
                                  <option>5</option>
                                  <option>6</option>
                                  <option>7</option>
                                  <option>8</option>
                                  <option>9</option>
                                  <option>10</option>
                                  <option>11</option>
                                  <option>12</option>
                                  <option>13</option>
                                  <option>14</option>
                                  <option>15</option>
                                </select>
                              </div>
                            </div>
                            </br>
                            <strong class="text-muted d-block mb-0">Media Perakaran (rc)</strong>
                            <h9 class="m-0">Drainase :</h9>
                            <div class="form-row">
                              <div class="form-group col-md-7">
                                <select id="inputState" name="drainase" class="form-control">
                                  <option selected>Pilih...</option>
                                  <option>Sangat Terhambat</option>
                                  <option>Terhambat</option>
                                  <option>Agak Terhambat</option>
                                  <option>Agak Baik</option>
                                  <option>Baik</option>
                                  <option>Agak Cepat</option>
                                  <option>Cepat</option>
                                  <option>Sangat Cepat</option>
                                </select>
                              </div>
                            </div>
                            <h9 class="m-0">Tekstur :</h9>
                            <div class="form-row">
                              <div class="form-group col-md-7">
                                <select id="inputState" name="tekstur" class="form-control">
                                  <option selected>Pilih...</option>
                                  <option>Sangat Halus</option>
                                  <option>Halus</option>
                                  <option>Agak Halus</option>
                                  <option>Sedang</option>
                                  <option>Agak Kasar</option>
                                  <option>Kasar</option>
                                  <option>Sangat Kasar</option>
                                </select>
                              </div>
                            </div>
                            <h9 class="m-0">Bahan Kasar (%) :</h9>
                            <div class="form-row">
                              <div class="form-group col-md-7">
                                <select id="inputState" name="bahankasar" class="form-control">
                                  <option selected>Pilih...</option>
                                  <option>0</option>
                                  <option>1</option>
                                  <option>2</option>
                                  <option>3</option>
                                  <option>4</option>
                                  <option>5</option>
                                  <option>6</option>
                                  <option>7</option>
                                  <option>8</option>
                                  <option>9</option>
                                  <option>10</option>
                                  <option>11</option>
                                  <option>12</option>
                                  <option>13</option>
                                  <option>14</option>
                                  <option>15</option>
                                  <option>16</option>
                                  <option>17</option>
                                  <option>18</option>
                                  <option>19</option>
                                  <option>20</option>
                                  <option>21</option>
                                  <option>22</option>
                                  <option>23</option>
                                  <option>24</option>
                                  <option>25</option>
                                  <option>26</option>
                                  <option>27</option>
                                  <option>28</option>
                                  <option>29</option>
                                  <option>30</option>
                                  <option>31</option>
                                  <option>32</option>
                                  <option>33</option>
                                  <option>34</option>
                                  <option>35</option>
                                  <option>36</option>
                                  <option>37</option>
                                  <option>38</option>
                                  <option>39</option>
                                  <option>40</option>
                                  <option>41</option>
                                  <option>42</option>
                                  <option>43</option>
                                  <option>44</option>
                                  <option>45</option>
                                  <option>46</option>
                                  <option>47</option>
                                  <option>48</option>
                                  <option>49</option>
                                  <option>50</option>
                                  <option>51</option>
                                  <option>52</option>
                                  <option>53</option>
                                  <option>54</option>
                                  <option>55</option>
                                  <option>56</option>
                                  <option>57</option>
                                  <option>58</option>
                                </select>
                              </div>
                            </div>
                            <h9 class="m-0">Kedalaman Tanah (cm) :</h9>
                            <div class="form-row">
                              <div class="form-group col-md-7">
                                <select id="inputState" name="kedalamantanah" class="form-control">
                                  <option selected>Pilih...</option>
                                  <option>0</option>
                                  <option>5</option>
                                  <option>10</option>
                                  <option>15</option>
                                  <option>20</option>
                                  <option>25</option>
                                  <option>30</option>
                                  <option>35</option>
                                  <option>40</option>
                                  <option>45</option>
                                  <option>50</option>
                                  <option>55</option>
                                  <option>60</option>
                                  <option>65</option>
                                  <option>70</option>
                                  <option>75</option>
                                  <option>80</option>
                                  <option>85</option>
                                  <option>90</option>
                                  <option>95</option>
                                  <option>100</option>
                                  <option>105</option>
                                  <option>110</option>
                                  <option>115</option>
                                  <option>120</option>
                                </select>
                              </div>
                            </div>
                            </br>
                            <strong class="text-muted d-block mb-0">Gambut</strong>
                            <h9 class="m-0">Ketebalan (cm) :</h9>
                            <div class="form-row">
                              <div class="form-group col-md-7">
                                <select id="inputState" name="ketebalangambut" class="form-control">
                                  <option selected>Pilih...</option>
                                  <option>0</option>
                                  <option>10</option>
                                  <option>20</option>
                                  <option>30</option>
                                  <option>40</option>
                                  <option>50</option>
                                  <option>60</option>
                                  <option>70</option>
                                  <option>80</option>
                                  <option>90</option>
                                  <option>100</option>
                                  <option>110</option>
                                  <option>120</option>
                                  <option>130</option>
                                  <option>140</option>
                                  <option>150</option>
                                  <option>160</option>
                                  <option>170</option>
                                  <option>180</option>
                                  <option>190</option>
                                  <option>200</option>
                                  <option>210</option>
                                  <option>220</option>
                                  <option>230</option>
                                  <option>240</option>
                                  <option>250</option>
                                  <option>260</option>
                                  <option>270</option>
                                  <option>280</option>
                                  <option>290</option>
                                  <option>300</option>
                                </select>
                              </div>
                            </div>
                            <h9 class="m-0">Kematangan :</h9>
                            <div class="form-row">
                              <div class="form-group col-md-7">
                                <select id="inputState" name="kematangan" class="form-control">
                                  <option selected>Pilih...</option>
                                  <option>Saprik</option>
                                  <option>Hemik</option>
                                  <option>Fibrik</option>
                                </select>
                              </div>
                            </div>
                        </div>

                        <div class="col-sm-12 col-md-4 mb-3">
                          <strong class="text-muted d-block mb-0">Retensi Hara (nr)</strong>
                            <h9 class="m-0">KTK Tanah (cmol/kg) :</h9>
                            <div class="form-row">
                              <div class="form-group col-md-7">
                                <select id="inputState" name="ktktanah" class="form-control">
                                  <option selected>Pilih...</option>
                                  <option>0</option>
                                  <option>1</option>
                                  <option>2</option>
                                  <option>3</option>
                                  <option>4</option>
                                  <option>5</option>
                                  <option>6</option>
                                  <option>7</option>
                                  <option>8</option>
                                  <option>9</option>
                                  <option>10</option>
                                  <option>11</option>
                                  <option>12</option>
                                  <option>13</option>
                                  <option>14</option>
                                  <option>15</option>
                                  <option>16</option>
                                  <option>17</option>
                                  <option>18</option>
                                  <option>19</option>
                                  <option>20</option>
                                  <option>21</option>
                                  <option>22</option>
                                  <option>23</option>
                                  <option>24</option>
                                  <option>25</option>
                                  <option>26</option>
                                  <option>27</option>
                                  <option>28</option>
                                  <option>29</option>
                                  <option>30</option>
                                </select>
                              </div>
                            </div>
                            <h9 class="m-0">Kejenuhan Basa (%) :</h9>
                            <div class="form-row">
                              <div class="form-group col-md-7">
                                <select id="inputState" name="kejenuhanbasa" class="form-control">
                                  <option selected>Pilih...</option>
                                  <option>1</option>
                                  <option>2</option>
                                  <option>3</option>
                                  <option>4</option>
                                  <option>5</option>
                                  <option>6</option>
                                  <option>7</option>
                                  <option>8</option>
                                  <option>9</option>
                                  <option>10</option>
                                  <option>11</option>
                                  <option>12</option>
                                  <option>13</option>
                                  <option>14</option>
                                  <option>15</option>
                                  <option>16</option>
                                  <option>17</option>
                                  <option>18</option>
                                  <option>19</option>
                                  <option>20</option>
                                  <option>21</option>
                                  <option>22</option>
                                  <option>23</option>
                                  <option>24</option>
                                  <option>25</option>
                                  <option>26</option>
                                  <option>27</option>
                                  <option>28</option>
                                  <option>29</option>
                                  <option>30</option>
                                  <option>31</option>
                                  <option>32</option>
                                  <option>33</option>
                                  <option>34</option>
                                  <option>35</option>
                                  <option>36</option>
                                  <option>37</option>
                                  <option>38</option>
                                  <option>39</option>
                                  <option>40</option>
                                  <option>41</option>
                                  <option>42</option>
                                  <option>43</option>
                                  <option>44</option>
                                  <option>45</option>
                                  <option>46</option>
                                  <option>47</option>
                                  <option>48</option>
                                  <option>49</option>
                                  <option>50</option>
                                  <option>51</option>
                                  <option>52</option>
                                  <option>53</option>
                                  <option>54</option>
                                  <option>55</option>
                                  <option>56</option>
                                  <option>57</option>
                                  <option>58</option>
                                  <option>59</option>
                                  <option>60</option>
                                </select>
                              </div>
                            </div> 
                            <h9 class="m-0">pH H2O :</h9>
                            <div class="form-row">
                              <div class="form-group col-md-7">
                                <select id="inputState" name="phh2o" class="form-control">
                                  <option selected>Pilih...</option>
                                  <option>0</option>
                                  <option>0,5</option>
                                  <option>1,0</option>
                                  <option>1,5</option>
                                  <option>2,0</option>
                                  <option>2,5</option>
                                  <option>3,0</option>
                                  <option>3,5</option>
                                  <option>4,0</option>
                                  <option>4,5</option>
                                  <option>5,0</option>
                                  <option>5,5</option>
                                  <option>6,0</option>
                                  <option>6,5</option>
                                  <option>7,0</option>
                                  <option>7,5</option>
                                  <option>8,0</option>
                                  <option>8,5</option>
                                  <option>9,0</option>
                                  <option>9,5</option>
                                  <option>10,0</option>
                                  <option>10,5</option>
                                  <option>11,0</option>
                                  <option>11,5</option>
                                  <option>12,0</option>
                                  <option>13,5</option>
                                  <option>14,0</option>
                                  <option>14,5</option>
                                  <option>15,0</option>
                                </select>
                              </div>
                            </div> 
                            <h9 class="m-0">C-Organik (%) :</h9>
                            <div class="form-row">
                              <div class="form-group col-md-7">
                                <select id="inputState" name="corganik" class="form-control">
                                  <option selected>Pilih...</option>
                                  <option>0,1</option>
                                  <option>0,2</option>
                                  <option>0,3</option>
                                  <option>0,4</option>
                                  <option>0,5</option>
                                  <option>0,6</option>
                                  <option>0,7</option>
                                  <option>0,8</option>
                                  <option>0,9</option>
                                  <option>1,0</option>
                                  <option>1,1</option>
                                  <option>1,2</option>
                                  <option>1,3</option>
                                  <option>1,4</option>
                                  <option>1,5</option>
                                  <option>1,6</option>
                                  <option>1,7</option>
                                  <option>1,8</option>
                                  <option>1,9</option>
                                  <option>2,0</option>
                                  <option>2,1</option>
                                  <option>2,2</option>
                                  <option>2,3</option>
                                  <option>2,4</option>
                                  <option>2,5</option>
                                </select>
                              </div>
                            </div> 
                          </br>
                            <strong class="text-muted d-block mb-0">Hara Tersedia (na)</strong>
                            <h9 class="m-0">N Total (%) :</h9>
                            <div class="form-row">
                              <div class="form-group col-md-7">
                                <select id="inputState" name="ntotal" class="form-control">
                                  <option selected>Pilih...</option>
                                  <option>Sangat Rendah</option>
                                  <option>Rendah</option>
                                  <option>Sedang</option>
                                  <option>Tinggi</option>
                                  <option>Sangat Tinggi</option>
                                </select>
                              </div>
                            </div>
                            <h9 class="m-0">P2O5 (mg/100g) :</h9>
                            <div class="form-row">
                              <div class="form-group col-md-7">
                                <select id="inputState" name="p2o5" class="form-control">
                                  <option selected>Pilih...</option>
                                  <option>Sangat Rendah</option>
                                  <option>Rendah</option>
                                  <option>Sedang</option>
                                  <option>Tinggi</option>
                                  <option>Sangat Tinggi</option>
                                </select>
                              </div>
                            </div> 
                            <h9 class="m-0">K2O (mg/100g) :</h9>
                            <div class="form-row">
                              <div class="form-group col-md-7">
                                <select id="inputState" name="k2o" class="form-control">
                                  <option selected>Pilih...</option>
                                  <option>Sangat Rendah</option>
                                  <option>Rendah</option>
                                  <option>Sedang</option>
                                  <option>Tinggi</option>
                                  <option>Sangat Tinggi</option>
                                </select>
                              </div>
                            </div> 
                          </br>
                          <strong class="text-muted d-block mb-0">Toksitas (xc)</strong>
                          <h9 class="m-0">Salinitas (dS/m) :</h9>
                          <div class="form-row">
                            <div class="form-group col-md-7">
                              <select id="inputState" name="salinitas" class="form-control">
                                <option selected>Pilih...</option>
                                <option>0</option>
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                                <option>6</option>
                                <option>7</option>
                                <option>8</option>
                                <option>9</option>
                                <option>10</option>
                                <option>11</option>
                                <option>12</option>
                                <option>13</option>
                                <option>14</option>
                                <option>15</option>
                                <option>16</option>
                                <option>17</option>
                                <option>18</option>
                                <option>19</option>
                                <option>20</option>
                              </select>
                            </div>
                          </div>
                          
                        </div>

                        <div class="col-sm-12 col-md-4 mb-3"> 
                          <strong class="text-muted d-block mb-0">Sodisitas (xn)</strong>
                          <h9 class="m-0">Alkalinitas/ESP (%) :</h9>
                          <div class="form-row">
                            <div class="form-group col-md-7">
                              <select id="inputState" name="alkalinitas" class="form-control">
                                <option selected>Pilih...</option>
                                <option>0</option>
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                                <option>6</option>
                                <option>7</option>
                                <option>8</option>
                                <option>9</option>
                                <option>10</option>
                                <option>11</option>
                                <option>12</option>
                                <option>13</option>
                                <option>14</option>
                                <option>15</option>
                                <option>16</option>
                                <option>17</option>
                                <option>18</option>
                                <option>19</option>
                                <option>20</option>
                                <option>21</option>
                                <option>22</option>
                                <option>23</option>
                                <option>24</option>
                                <option>25</option>
                                <option>26</option>
                                <option>27</option>
                                <option>28</option>
                                <option>29</option>
                                <option>30</option>
                                <option>31</option>
                                <option>32</option>
                                <option>33</option>
                                <option>34</option>
                                <option>35</option>
                                <option>36</option>
                                <option>37</option>
                                <option>38</option>
                                <option>39</option>
                                <option>40</option>
                                <option>41</option>
                                <option>42</option>
                                <option>43</option>
                                <option>44</option>
                                <option>45</option>
                                <option>46</option>
                                <option>47</option>
                                <option>48</option>
                                <option>49</option>
                                <option>50</option>
                                <option>51</option>
                                <option>52</option>
                                <option>53</option>
                                <option>54</option>
                                <option>55</option>
                                <option>56</option>
                                <option>57</option>
                                <option>58</option>
                                <option>59</option>
                                <option>60</option>
                              </select>
                            </div>
                          </div>
                        </br>
                          <strong class="text-muted d-block mb-0">Bahaya Sulfidik (xs)</strong>
                          <h9 class="m-0">Kedalaman Sulfidik (cm) :</h9>
                          <div class="form-row">
                            <div class="form-group col-md-7">
                              <select id="inputState" name="kedalamansulfidik" class="form-control">
                                <option selected>Pilih...</option>
                                <option>0</option>
                                <option>5</option>
                                <option>10</option>
                                <option>15</option>
                                <option>20</option>
                                <option>25</option>
                                <option>30</option>
                                <option>35</option>
                                <option>40</option>
                                <option>45</option>
                                <option>50</option>
                                <option>55</option>
                                <option>60</option>
                                <option>65</option>
                                <option>70</option>
                                <option>75</option>
                                <option>80</option>
                                <option>85</option>
                                <option>90</option>
                                <option>95</option>
                                <option>100</option>
                                <option>105</option>
                                <option>110</option>
                                <option>115</option>
                                <option>120</option>
                                <option>125</option>
                                <option>130</option>
                                <option>135</option>
                                <option>140</option>
                                <option>145</option>
                                <option>150</option>
                              </select>
                            </div>
                          </div>
                          <strong class="text-muted d-block mb-0">Bahaya Erosi (eh)</strong>
                          <h9 class="m-0">Lereng (%) :</h9>
                          <div class="form-row">
                            <div class="form-group col-md-7">
                              <select id="inputState" name="lereng" class="form-control">
                                <option selected>Pilih...</option>
                                <option>0</option>
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                                <option>6</option>
                                <option>7</option>
                                <option>8</option>
                                <option>9</option>
                                <option>10</option>
                                <option>11</option>
                                <option>12</option>
                                <option>13</option>
                                <option>14</option>
                                <option>15</option>
                                <option>16</option>
                                <option>17</option>
                                <option>18</option>
                                <option>19</option>
                                <option>20</option>
                                <option>21</option>
                                <option>22</option>
                                <option>23</option>
                                <option>24</option>
                                <option>25</option>
                                <option>26</option>
                                <option>27</option>
                                <option>28</option>
                                <option>29</option>
                                <option>30</option>
                                <option>31</option>
                                <option>32</option>
                                <option>33</option>
                                <option>34</option>
                                <option>35</option>
                                <option>36</option>
                                <option>37</option>
                                <option>38</option>
                                <option>39</option>
                                <option>40</option>
                                <option>41</option>
                                <option>42</option>
                                <option>43</option>
                                <option>44</option>
                                <option>45</option>
                                <option>46</option>
                                <option>47</option>
                                <option>48</option>
                                <option>49</option>
                                <option>50</option>
                              </select>
                            </div>
                          </div>
                          <h9 class="m-0">Bahaya Erosi :</h9>
                          <div class="form-row">
                            <div class="form-group col-md-7">
                              <select id="inputState" name="bahayaerosi" class="form-control">
                                <option selected>Pilih...</option>
                                <option>Sangat Ringan</option>
                                <option>Ringan</option>
                                <option>Sedang</option>
                                <option>Berat</option>
                                <option>Sangat Berat</option>
                              </select>
                            </div>
                          </div>
                        </br>
                          <strong class="text-muted d-block mb-0">Bahaya Banjir Pada Masa Tanam (fh)</strong>
                          <h9 class="m-0">Tinggi (cm) :</h9>
                          <div class="form-row">
                            <div class="form-group col-md-7">
                              <select id="inputState" name="tinggigenangan" class="form-control">
                                <option selected>Pilih...</option>
                                <option>0</option>
                                <option>5</option>
                                <option>10</option>
                                <option>15</option>
                                <option>20</option>
                                <option>25</option>
                                <option>30</option>
                                <option>35</option>
                                <option>40</option>
                                <option>45</option>
                                <option>50</option>
                                <option>55</option>
                                <option>60</option>
                                <option>65</option>
                                <option>70</option>
                                <option>75</option>
                                <option>80</option>
                                <option>85</option>
                                <option>90</option>
                                <option>95</option>
                                <option>100</option>
                                <option>105</option>
                                <option>110</option>
                                <option>115</option>
                                <option>120</option>
                                <option>125</option>
                                <option>130</option>
                                <option>135</option>
                                <option>140</option>
                                <option>145</option>
                                <option>150</option>
                              </select>
                            </div>
                          </div>
                          <h9 class="m-0">Lama (hari) :</h9>
                          <div class="form-row">
                            <div class="form-group col-md-7">
                              <select id="inputState" name="lamagenangan" class="form-control">
                                <option selected>Pilih...</option>
                                <option>0</option>
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                                <option>6</option>
                                <option>7</option>
                                <option>8</option>
                                <option>9</option>
                                <option>10</option>
                                <option>11</option>
                                <option>12</option>
                                <option>13</option>
                                <option>14</option>
                                <option>15</option>
                                <option>16</option>
                                <option>17</option>
                                <option>18</option>
                                <option>19</option>
                                <option>20</option>
                                <option>21</option>
                                <option>22</option>
                                <option>23</option>
                                <option>24</option>
                                <option>25</option>
                                <option>26</option>
                                <option>27</option>
                                <option>28</option>
                                <option>29</option>
                                <option>30</option>
                              </select>
                            </div>
                          </div>
                        </br>
                        <strong class="text-muted d-block mb-0">Penyiapan Lahan (lp)</strong>
                        <h9 class="m-0">Batuan Dipermukaan (%) :</h9>
                        <div class="form-row">
                          <div class="form-group col-md-7">
                            <select id="inputState" name="batuan" class="form-control">
                              <option selected>Pilih...</option>
                              <option>0</option>
                              <option>1</option>
                              <option>2</option>
                              <option>3</option>
                              <option>4</option>
                              <option>5</option>
                              <option>6</option>
                              <option>7</option>
                              <option>8</option>
                              <option>9</option>
                              <option>10</option>
                              <option>11</option>
                              <option>12</option>
                              <option>13</option>
                              <option>14</option>
                              <option>15</option>
                              <option>16</option>
                              <option>17</option>
                              <option>18</option>
                              <option>19</option>
                              <option>20</option>
                              <option>21</option>
                              <option>22</option>
                              <option>23</option>
                              <option>24</option>
                              <option>25</option>
                              <option>26</option>
                              <option>27</option>
                              <option>28</option>
                              <option>29</option>
                              <option>30</option>
                              <option>31</option>
                              <option>32</option>
                              <option>33</option>
                              <option>34</option>
                              <option>35</option>
                              <option>36</option>
                              <option>37</option>
                              <option>38</option>
                              <option>39</option>
                              <option>40</option>
                              <option>41</option>
                              <option>42</option>
                              <option>43</option>
                              <option>44</option>
                              <option>45</option>
                              <option>46</option>
                              <option>47</option>
                              <option>48</option>
                              <option>49</option>
                              <option>50</option>
                              <option>51</option>
                              <option>52</option>
                              <option>53</option>
                              <option>54</option>
                              <option>55</option>
                              <option>56</option>
                              <option>57</option>
                              <option>58</option>
                              <option>59</option>
                              <option>60</option>
                              <option>61</option>
                              <option>62</option>
                              <option>63</option>
                              <option>64</option>
                              <option>65</option>
                              <option>66</option>
                              <option>67</option>
                              <option>68</option>
                            </select>
                          </div>
                        </div>
                        <h9 class="m-0">Singkapan Batuan (%) :</h9>
                        <div class="form-row">
                          <div class="form-group col-md-7">
                            <select id="inputState" name="singkapan" class="form-control">
                              <option selected>Pilih...</option>
                              <option>0</option>
                              <option>1</option>
                              <option>2</option>
                              <option>3</option>
                              <option>4</option>
                              <option>5</option>
                              <option>6</option>
                              <option>7</option>
                              <option>8</option>
                              <option>9</option>
                              <option>10</option>
                              <option>11</option>
                              <option>12</option>
                              <option>13</option>
                              <option>14</option>
                              <option>15</option>
                              <option>16</option>
                              <option>17</option>
                              <option>18</option>
                              <option>19</option>
                              <option>20</option>
                              <option>21</option>
                              <option>22</option>
                              <option>23</option>
                              <option>24</option>
                              <option>25</option>
                              <option>26</option>
                              <option>27</option>
                              <option>28</option>
                              <option>29</option>
                              <option>30</option>
                            </select>
                          </div>
                        </div>
                        </div>
                        
                      </div>
                      <li class="list-group-item d-flex px-3">
                        <button class="btn btn-sm btn-outline-accent">Hapus</button>
                        <button type="submit" name="submit" class="btn btn-sm btn-accent ml-auto"> Prediksi</button>
                      </li>
                    </li>
                  </ul>
                </div>
              </form>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>
    <script src="https://unpkg.com/shards-ui@latest/dist/js/shards.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sharrre/2.0.1/jquery.sharrre.min.js"></script>
    <script src="scripts/extras.1.1.0.min.js"></script>
    <script src="scripts/shards-dashboards.1.1.0.min.js"></script>
    <script src="scripts/app/app-components-overview.1.1.0.js"></script>
  </body>
</html>