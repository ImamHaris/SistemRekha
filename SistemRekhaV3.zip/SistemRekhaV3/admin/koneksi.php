<?php
    $host="localhost";
    $user="root";
    $password="";
    $db="dbsistemrekomendasi";

    $kon= mysqli_connect($host,$user,$password,$db);

    if (!$kon){
        die("koneksi gagal:".mysqli_connect_error());
    }

    //PADI
    $host1="localhost";
    $user1="root";
    $password1="";
    $db1="rule_padi";

    $kon1= mysqli_connect($host1,$user1,$password1,$db1);

    if (!$kon1){
        die("koneksi gagal:".mysqli_connect_error());
    }

    //JAGUNG
    $host2="localhost";
    $user2="root";
    $password2="";
    $db2="rule_jagung";

    $kon2= mysqli_connect($host2,$user2,$password2,$db2);

    if (!$kon2){
        die("koneksi gagal:".mysqli_connect_error());
    }

    //KEDELAI
    $host3="localhost";
    $user3="root";
    $password3="";
    $db3="rule_kedelai";

    $kon3= mysqli_connect($host3,$user3,$password3,$db3);

    if (!$kon3){
        die("koneksi gagal:".mysqli_connect_error());
    }

    //PADISTH
    $host4="localhost";
    $user4="root";
    $password4="";
    $db4="rule_padisth";

    $kon4= mysqli_connect($host4,$user4,$password4,$db4);

    if (!$kon4){
        die("koneksi gagal:".mysqli_connect_error());
    }

    //PADIGOGO
    $host5="localhost";
    $user5="root";
    $password5="";
    $db5="rule_padigogo";

    $kon5= mysqli_connect($host5,$user5,$password5,$db5);

    if (!$kon5){
        die("koneksi gagal:".mysqli_connect_error());
    }

    //PADISRPS
    $host6="localhost";
    $user6="root";
    $password6="";
    $db6="rule_padisrps";

    $kon6= mysqli_connect($host6,$user6,$password6,$db6);

    if (!$kon6){
        die("koneksi gagal:".mysqli_connect_error());
    }

    //PADISRL
    $host7="localhost";
    $user7="root";
    $password7="";
    $db7="rule_padisrl";

    $kon7= mysqli_connect($host7,$user7,$password7,$db7);

    if (!$kon7){
        die("koneksi gagal:".mysqli_connect_error());
    }

    //BAWANG
    $host8="localhost";
    $user8="root";
    $password8="";
    $db8="rule_bawang";

    $kon8= mysqli_connect($host8,$user8,$password8,$db8);

    if (!$kon8){
        die("koneksi gagal:".mysqli_connect_error());
    }

    //CABAI
    $host9="localhost";
    $user9="root";
    $password9="";
    $db9="rule_cabai";

    $kon9= mysqli_connect($host9,$user9,$password9,$db9);

    if (!$kon9){
        die("koneksi gagal:".mysqli_connect_error());
    }

    //SAWIT
    $host10="localhost";
    $user10="root";
    $password10="";
    $db10="rule_sawit";

    $kon10= mysqli_connect($host10,$user10,$password10,$db10);

    if (!$kon10){
        die("koneksi gagal:".mysqli_connect_error());
    }

    //KAKAO
    $host11="localhost";
    $user11="root";
    $password11="";
    $db11="rule_kakao";

    $kon11= mysqli_connect($host11,$user11,$password11,$db11);

    if (!$kon11){
        die("koneksi gagal:".mysqli_connect_error());
    }

    //TEBU
    $host12="localhost";
    $user12="root";
    $password12="";
    $db12="rule_tebu";

    $kon12= mysqli_connect($host12,$user12,$password12,$db12);

    if (!$kon12){
        die("koneksi gagal:".mysqli_connect_error());
    }

    //RUMPUT GAJAH
    $host13="localhost";
    $user13="root";
    $password13="";
    $db13="rule_rumput";

    $kon13= mysqli_connect($host13,$user13,$password13,$db13);

    if (!$kon13){
        die("koneksi gagal:".mysqli_connect_error());
    }

    //SETARIA
    $host14="localhost";
    $user14="root";
    $password14="";
    $db14="rule_setaria";

    $kon14= mysqli_connect($host14,$user14,$password14,$db14);

    if (!$kon14){
        die("koneksi gagal:".mysqli_connect_error());
    }

?>