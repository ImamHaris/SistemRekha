<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?");
	}
?>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Sistem Rekomendasi Kesesuaian Lahan</title>
    <meta name="description" content="A high-quality &amp; free Bootstrap admin dashboard template pack that comes with lots of templates and components.">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" id="main-stylesheet" data-version="1.1.0" href="/SistemRekha/admin/styles/shards-dashboards.1.1.0.min.css">
    <link rel="stylesheet" href="styles/extras.1.1.0.min.css">
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </head>
  <body class="h-100">
    <div class="container-fluid">
      <div class="row">
        <!-- Main Sidebar -->
        <aside class="main-sidebar col-12 col-md-3 col-lg-2 px-0">
          <div class="main-navbar">
            <nav class="navbar align-items-stretch navbar-light bg-white flex-md-nowrap border-bottom p-0">
              <a class="navbar-brand w-100 mr-0" href="#" style="line-height: 25px;">
                <div class="d-table m-auto">
                  <img id="main-logo" class="d-inline-block align-top mr-1" style="max-width: 25px;" src="/SistemRekha/admin/images/logo.png" alt="Shards Dashboard">
                  <span class="d-none d-md-inline ml-1">Sistem Rekomendasi</span>
                </div>
              </a>
              <a class="toggle-sidebar d-sm-inline d-md-none d-lg-none">
                <i class="material-icons">&#xE5C4;</i>
              </a>
            </nav>
          </div>
          <form action="#" class="main-sidebar__search w-100 border-right d-sm-flex d-md-none d-lg-none">
            <div class="input-group input-group-seamless ml-3">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fas fa-search"></i>
                </div>
              </div>
              <input class="navbar-search form-control" type="text" placeholder="Search for something..." aria-label="Search"> </div>
          </form>
          <div class="nav-wrapper">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link " href="/SistemRekha/admin/index.php">
                  <i class="material-icons">edit</i>
                  <span>Dashboard</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/SistemRekha/admin/prediksi.php">
                  <i class="material-icons">view_module</i>
                  <span>Prediksi</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="/SistemRekha/admin/tipsbertani.php">
                  <i class="material-icons">view_module</i>
                  <span>Tips Bertani</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="/SistemRekha/admin/user-profile.php">
                  <i class="material-icons">person</i>
                  <span>Profil Pengguna</span>
                </a>
              </li>
            </ul>
          </div>
        </aside>
        <!-- End Main Sidebar -->
        <main class="main-content col-lg-10 col-md-9 col-sm-12 p-0 offset-lg-2 offset-md-3">
          <div class="main-navbar sticky-top bg-white">
            <!-- Main Navbar -->
            <nav class="navbar align-items-stretch navbar-light flex-md-nowrap p-0">
              <form action="#" class="main-navbar__search w-100 d-none d-md-flex d-lg-flex">
                <div class="input-group input-group-seamless ml-3">
                  <div class="input-group-prepend">
                    <div class="input-group-text">
                      <i class="fas fa-search"></i>
                    </div>
                  </div>
                  <input class="navbar-search form-control" type="text" placeholder="Cari..." aria-label="Search"> </div>
              </form>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle text-nowrap px-3" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <img class="user-avatar rounded-circle mr-2" src="/SistemRekha/admin/images/avatars/unnamed.png" alt="User Avatar">
                    <span class="d-none d-md-inline-block"><?php echo $_SESSION['username']; ?></span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-small">
                    <a class="dropdown-item" href="user-profile.php">
                      <i class="material-icons">&#xE7FD;</i> Profile</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item text-danger" href="logout.php">
                      <i class="material-icons text-danger">&#xE879;</i> Logout </a>
                  </div>
                </li>
              </ul>
              <nav class="nav">
                <a href="#" class="nav-link nav-link-icon toggle-sidebar d-md-inline d-lg-none text-center border-left" data-toggle="collapse" data-target=".header-navbar" aria-expanded="false" aria-controls="header-navbar">
                  <i class="material-icons">&#xE5D2;</i>
                </a>
              </nav>
            </nav>
          </div>
          <!-- / .main-navbar -->
          <div class="main-content-container container-fluid px-4">
            <!-- Page Header -->
            <div class="page-header row no-gutters py-4 mb-3 border-bottom">
              <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
                <span class="text-uppercase page-subtitle">Tips</span>
                <h3 class="page-title">Kakao</h3>
              </div>
            </div>
            <!-- End Page Header -->
            
            <!-- Isi Konten -->
            
            <li class="list-group-item p-4">
                <strong class="text-muted d-block mb-2">Cara Cerdas Menanam Kakao</strong>
                <span>Kakao atau Theobroma cacao L adalah jenid tanaman pohon yang sangat populer dengan olahan buahnya. Cokelat adalah olahan yang berasal dari biji kakao. Kakao diduga berasal dari daratan Amerika dan tepatnya di Amerika Selatan.
                      Pohon kakao di alam bebas dapat mencapai ketinggian hingga belasan meter. Namun untuk pohon kakao budidaya ketinggiannya hanya dibuat mencapai 5 meter saja karena untuk memaksimalkan produksi buahnya. Indonesia adalah penghasil kakao terbesar ketiga di dunia dengan kontribusi sebesar 13?ri kebutuhan dunia.
                      Hal tersebut didukung karena lokasi geografis Indonesia yang sangat cocok untuk budidaya kakao. Maka dari itu sangat tidak heran petani di Indonesia sangat banyak yang membudidayakan kakao. Tanaman kakao tumbuh baik pada dataran rendah dengan ketinggian maksimum 1200 mdpl.
                      Tanaman kakao membutuhkan curah hujan berkisar 1100-3000 mm/tahun. Suhu ideal tanaman kakao yaitu 30-32 derajat celcius dan pH terbaik untuk tanaman kakao berkisar antara 6-7,5.
                </span>
                <br/>
                <br/>

                <strong class="text-muted d-block mb-2">Teknik Budidaya Tanaman Kakao</strong>
                <span>Budidaya kakao sangat mengharapkan tanah yang kaya akan nutrisi di dalamnya. Pengolahan lahan dilakukan dengan membersihkan lahan dari gulma dan kotoran yang mengganggu. Gunakan tanaman penutup tanah seperti jenis tanaman polong-polongan dan pengolahan tanah budidaya kakao dapat dilakukan dengan cara mekanis.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Tanaman Pelindung atau Naungan</strong>
                <span>Tanaman pelindung dalam budidaya kakao sangatlah penting kegunaannya. Kegunaan utama dari pohon pelindung yaitu melindungi tanaman kakao dari paparan sinar matahari langsung. Pohon pelindung juga berguna sebagai peredam suhu maksimum pada musim kemarau yang dapat merusak tanaman kakao.
                      Kegunaan lainnya adalah sebagai penahan angina sebab daun muda pada tanaman kakao sangat mudah rontok apabila angin yang kencang. Pohon pelindung pada tanaman kakao sebaiknya ditanam 1 tahun sebelum tanaman kakao ditanam. Tanaman penaung yang populer digunakan petani kakao adalah pohon gamal, lamtoro, dan albazia.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Pembibitan Tanaman Kakao</strong>
                <span>Tanaman Kakao dapat diperbanyak secara generatif dengan generatif dan juga vegetatif. Perbanyakan secara generatif dapat dilakukan dengan penyemaian biji kakao. Selain itu perbanyakan secara vegetatif dapat dilakukan dengan menggunakan stek ataupun okulasi.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Kebutuhan Bibit Tanaman Kakao</strong>
                <span>Jumlah bibit tanaman kakao yang dibutuhkan sangat tergantung dengan luas lahan tanaman kakao serta jarak tanaman yang akan digunakan. Pada jarak tanam 2,5 x 2,5 m membutuhkan bibit sekitar 1600 hingga 1650 batang bibit. Sedangkan untuk jarak tanam 3 x 3 m hanya membutuhkan bibit 1000 hingga 1100 batang.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Penanaman Bibit Kakao</strong>
                <span>Sebelum masuk ke tahap penanaman sebaiknya pastikan terlebih dahulu bibit yang akan digunakan. Bibit kakao yang sudah siap untuk ditanam ke lahan adalah bibit yang telah berumur 5 bulan. Pada umur tersebut bibit sudah mencapai ketinggian 50 cm dengan daun berjumlah 20-35 helai daun, sedangkan batang sudah berdiameter 8 mm.
                      Selanjutnya setelah semua hal tersebut dipastikan maka hal yang selanjutnya harus dilakukan adalah membuat ajir tanaman dengan ketinggian 1 m. Pengaturan jarak tanam harus disesuaikan dengan jumlah bibit yang sudah disiapkan.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Pemeliharaan Tanaman Kakao</strong>
                <span>Pada pemeliharaan tanaman kakao ada beberapa hal yang harus dilakukan antara lain pemangkasan, penyiangan, pemupukan dan pengendalian hama dan penyakit. Pemangkasan bentuk pada tanaman buah kakao bertujuan untuk membentuk tajuk tanaman kakao. Budidaya tanaman kakao sangat tergantung pada pertumbuhan cabang lateralnya sehingga pemangkasan cabang sangat bertujuan untuk membentuk cabang-cabang lateral, di mana cabang-cabang lateral adalah cabang yang akan memunculkan buah kakao.
                      Penyiangan harus dilakukan secara teratur agar pertumbuhan hama dan penyakit dapat dicegah sejak dini. Penyiangan sebaiknya dilakukan setiap satu bulan sekali. Penyiangan dilakukan dengan cara membersihkan tanaman liar yang tumbuh di sekitar wilayah pertanaman, dengan begitu unsur hara dapat maksimal diserap oleh tanaman kakao dan bukan tanaman pengganggu.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Pemupukan</strong>
                <span>Pemupukan dilakukan dengan cara ditugal dengan menggunakan pupuk urea TSP dan KCl. Dosis pupuk sendiri ditetapkan berdasarkan umur tanaman. Pemupukan pertama pada tanaman kakao dilakukan ketika tanaman telah berumur 2 bulan setelah tanam.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Pengendalian Hama dan Penyakit</strong>
                <span>Tanaman kakao adalah salah satu jenis tanaman yang sangat rentan terserang hama dan penyakit. Maka dari itu diperlukan kemampuan dan pengetahuan lebih dalam mengelolanya. Hal yang dapat dilakukan untuk menjaga tanaman kakao agar tidak mudah terserang hama dan penyakit yaitu sanitasi lahan.
                      Tanaman kakao yang terserang penyakit harus dibakar agar tidak menyebar ketanaman yang lainnya. Selain itu, pengendalian menggunakan pestisida juga penting dilakukan. Untuk hama seperti ulat kilan, ulat jaran, kutu, ngengat buah dapat dilakukan dengan mengaplikasikan insektisida, sedangkan untuk penyakit yang diakibatkan oleh jamur dapat dikendalikan dengan fungisida.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Panen</strong>
                <span>Panen buah kakao sudah dapat dilakukan ketika buah telah berumur 5-6 bulan setelah bunga muncul. Buah kakao yang sudah dapat dipanen memiliki warna yang kuning. Pemanenan dilakukan dengan cara memetik buah langsung dari pohonnya dapat menggunakan pisau atau gunting buah yang tajam dengan menyisakan 1/3 bagian tangkai buah pada pohon.
                      Setelah buah dipanen lakukan pemecahan buah untuk mengeluarkan bijinya, selanjutnya biji buah dilakukan pengeringan dengan cara dijemur. Penjemuran ketika cuaca cerah dapat memakan waktu selama 2 hari. Setelah biji kakao kering dapat dilakukan sortasi berdasarkan bentuk dan kualitas, setelah itu buah barulah bisa dijual ke pengepul ataupun tengkulak.
                </span>

            </li>

            <!-- End of Isi Konten -->
            
          </div>
        </main>
      </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>
    <script src="https://unpkg.com/shards-ui@latest/dist/js/shards.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sharrre/2.0.1/jquery.sharrre.min.js"></script>
    <script src="scripts/extras.1.1.0.min.js"></script>
    <script src="scripts/shards-dashboards.1.1.0.min.js"></script>
    <script src="scripts/app/app-components-overview.1.1.0.js"></script>
  </body>
