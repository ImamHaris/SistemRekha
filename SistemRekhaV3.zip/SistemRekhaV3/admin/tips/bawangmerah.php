<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?");
	}
?>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Sistem Rekomendasi Kesesuaian Lahan</title>
    <meta name="description" content="A high-quality &amp; free Bootstrap admin dashboard template pack that comes with lots of templates and components.">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" id="main-stylesheet" data-version="1.1.0" href="/SistemRekha/admin/styles/shards-dashboards.1.1.0.min.css">
    <link rel="stylesheet" href="styles/extras.1.1.0.min.css">
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </head>
  <body class="h-100">
    <div class="container-fluid">
      <div class="row">
        <!-- Main Sidebar -->
        <aside class="main-sidebar col-12 col-md-3 col-lg-2 px-0">
          <div class="main-navbar">
            <nav class="navbar align-items-stretch navbar-light bg-white flex-md-nowrap border-bottom p-0">
              <a class="navbar-brand w-100 mr-0" href="#" style="line-height: 25px;">
                <div class="d-table m-auto">
                  <img id="main-logo" class="d-inline-block align-top mr-1" style="max-width: 25px;" src="/SistemRekha/admin/images/logo.png" alt="Shards Dashboard">
                  <span class="d-none d-md-inline ml-1">Sistem Rekomendasi</span>
                </div>
              </a>
              <a class="toggle-sidebar d-sm-inline d-md-none d-lg-none">
                <i class="material-icons">&#xE5C4;</i>
              </a>
            </nav>
          </div>
          <form action="#" class="main-sidebar__search w-100 border-right d-sm-flex d-md-none d-lg-none">
            <div class="input-group input-group-seamless ml-3">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fas fa-search"></i>
                </div>
              </div>
              <input class="navbar-search form-control" type="text" placeholder="Search for something..." aria-label="Search"> </div>
          </form>
          <div class="nav-wrapper">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link " href="/SistemRekha/admin/index.php">
                  <i class="material-icons">edit</i>
                  <span>Dashboard</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/SistemRekha/admin/prediksi.php">
                  <i class="material-icons">view_module</i>
                  <span>Prediksi</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="/SistemRekha/admin/tipsbertani.php">
                  <i class="material-icons">view_module</i>
                  <span>Tips Bertani</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="/SistemRekha/admin/user-profile.php">
                  <i class="material-icons">person</i>
                  <span>Profil Pengguna</span>
                </a>
              </li>
            </ul>
          </div>
        </aside>
        <!-- End Main Sidebar -->
        <main class="main-content col-lg-10 col-md-9 col-sm-12 p-0 offset-lg-2 offset-md-3">
          <div class="main-navbar sticky-top bg-white">
            <!-- Main Navbar -->
            <nav class="navbar align-items-stretch navbar-light flex-md-nowrap p-0">
              <form action="#" class="main-navbar__search w-100 d-none d-md-flex d-lg-flex">
                <div class="input-group input-group-seamless ml-3">
                  <div class="input-group-prepend">
                    <div class="input-group-text">
                      <i class="fas fa-search"></i>
                    </div>
                  </div>
                  <input class="navbar-search form-control" type="text" placeholder="Cari..." aria-label="Search"> </div>
              </form>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle text-nowrap px-3" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <img class="user-avatar rounded-circle mr-2" src="/SistemRekha/admin/images/avatars/unnamed.png" alt="User Avatar">
                    <span class="d-none d-md-inline-block"><?php echo $_SESSION['username']; ?></span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-small">
                    <a class="dropdown-item" href="user-profile.php">
                      <i class="material-icons">&#xE7FD;</i> Profile</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item text-danger" href="logout.php">
                      <i class="material-icons text-danger">&#xE879;</i> Logout </a>
                  </div>
                </li>
              </ul>
              <nav class="nav">
                <a href="#" class="nav-link nav-link-icon toggle-sidebar d-md-inline d-lg-none text-center border-left" data-toggle="collapse" data-target=".header-navbar" aria-expanded="false" aria-controls="header-navbar">
                  <i class="material-icons">&#xE5D2;</i>
                </a>
              </nav>
            </nav>
          </div>
          <!-- / .main-navbar -->
          <div class="main-content-container container-fluid px-4">
            <!-- Page Header -->
            <div class="page-header row no-gutters py-4 mb-3 border-bottom">
              <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
                <span class="text-uppercase page-subtitle">Tips</span>
                <h3 class="page-title">Bawang Merah</h3>
              </div>
            </div>
            <!-- End Page Header -->
            <li class="list-group-item p-4">
                      <strong class="text-muted d-block mb-2">Cara Budidaya Bawang Merah Anti Hama Hingga Panen</strong>
                      <span>Budidaya bawang merah menjadi salah satu peluang usaha yang menjanjikan. Bagaimana tidak, umbi yang biasa dijadikan sebagai bumbu dapur ini selalu dibutuhkan masyarakat Indonesia. Harga jualnya juga stabil, bahkan selalu terjual mahal saat momen hari raya dan akhir tahun.
                      Tanaman dengan nama latin Allium Ascalonicum ini sangat mudah untuk dilakukan budidaya. Pastikan pula kamu mengetahui cara antisipasi hinggapnya hama, agar budidaya bawang merah sukses besar. Berikut cara budidaya bawang merah, mulai dari pemilihan bibit hingga masa siap panen.
                      </span>
                      <br/>
                      <br/>
                      <strong class="text-muted d-block mb-2">Kelebihan Budidaya Bawang Merah</strong>
                      <span>
Banyak Manfaat<br/>
Bawang merah memiliki banyak manfaat. Mulai dari untuk kebutuhan bumbu dapur, hingga dijadikan obat untuk mencegah mual dan muntah.

Bawang merah juga dapat meningkatkan kesehatan karena kandungan vitamin C, B6, B9, yang berguna untuk mengoptimalkan penyerapan zat besi, membantu pembentukan sel darah merah, dan sederet manfaat lainnya.<br/><br/>

Laku Keras di Pasaran<br/>
Dengan banyaknya manfaat bawang merah, maka permintaan pasar pun selalu ada untuk tanaman yang satu ini. Bawang merah bisa dijual di daerah mana saja (baik di daerah desa maupun perkotaan), dengan harga yang relatif sama. Harga jualnya memang terbilang stabil.<br/><br/>
<strong class="text-muted d-block mb-2">Cara Budidaya Bawang Merah</strong>
1. Memilih Bibit<br/>
Langkah pertama dalam budidaya bawang merah adalah memilih bibit. Tanaman bawang merah ditanam dengan cara menaruh umbi. Pastikan umbi bawang merah yang dijadikan bibit berkualitas baik.

Ciri-cirinya adalah warna bawang yang mengkilat, tidak keropos atau terlihat dirusak hama maupun terkena penyakit hama.

Berat umbi yang dijadikan bibit sekitar 3 sampai 4 gram. Bibit direndam dahulu dengan cairan Hormon Organik sehari sebelum ditanam, selama 10 menit saja.

Kemudian, taburi dengan serbuk Gliocladium dan Trichoderma yang bisa dibeli di toko kebutuhan pertanian. Tujuannya adalah untuk mencegah penyakit pada bibit. Potong bagian atas umbi sedikit sebelum ditanam.

<br/><br/>2. Mengolah Lahan<br/>
Budidaya bawang merah dilakukan di atas tanah yang sudah diolah sedemikian rupa, serta aerasi yang baik. Cara mengolah lahan budidaya bawang merah yakni dengan membajak tanah dengan kedalaman 30 cm, lalu taburkan pupuk kandang dan serbuk Gliocladium dan Trichoderma. Biarkan selama seminggu.

Lalu, buat lah bedengan dengan tinggi sekitar 30 cm dan lebar 75 cm. pasang mulsa plastik untuk menjaga kelembaban tanah dan mencegah tumbuhnya rumput liar.

<br/><br/>3. Menanam Bibit<br/>
Sebelum memasukkan bibit ke tanah, basahi dulu tanah tersebut. Lalu dilubangi sesuai penempatan setiap satu bibit dengan jarak 15 cm x 15 cm, 15 cm x 20 cm, atau 20 cm x 20 cm. Tak perlu memasukkan bibit terlalu dalam ke tanah, cukup sekadar tertutup dengan tanah saja.

<br/><br/>4. Memelihara Pertumbuhan<br/>
<br/>- Pemberian Nutrisi<br/>
Cara budidaya bawang merah selanjutnya adalah dengan memelihara dan memantau pertumbuhan bibit. Setelah 7 hari ditanam, berikan semprotan POC GDM sebanyak 2 gelas air mineral untuk setiap tangkinya seminggu sekali.

Fungsinya untuk mendorong pertumbuhan bawang merah agar lebih maksimal. Penyemprotan dilakukan pagi hari pukul 09.00 dan sore hari pukul 16.00.

Saat bawang merah berusia 10 hari, 20 hari dan 35 hari, baru diberi pupuk anorganik. Pemberian pupuk anorganik sebenarnya merupakan pilihan.

Sebab saat ini sudah banyak pelaku usaha budidaya bawang merah organik yang tak menggunakannya. Harga jual bawang merah organik tentu saja lebih mahal, karena membutuhkan pemeliharaan yang ekstra.

<br/><br/>- Penyiraman<br/>
Tanaman bawang merah harus disiram dua kali sehari pada pagi dan sore hari. Jika hujan atau embun turun, penyiraman dengan air bersih juga diperlukan untuk mencegah penyebaran penyakit.

Setidaknya, kamu harus tahu kebutuhan penyiraman ini diperlukan agar tanaman tidak layu. Jika ada tanaman yang tumbuh kurang baik atau bahkan mati, segera tanam dengan tanaman yang baru.

<br/><br/>- Pengendalian Hama dan Penyakit<br/>
Untuk mencegah datangnya hama dan penyakit pada budidaya bawang merah, penggunaan pestisida kimia adalah pilihan terakhir yang dilakukan. Jadi, terapkan dulu pengendalian hama terpadu dengan bahan-bahan alami.

Di antaranya seperti menyiram tanaman dengan air bersih setelah hujan, pengaplikasian fungisida (kandungan tembaga hidroksida dan iprodiom) untuk menghindari bercak daun, pengaplikasian serbuk Gliocladium dan Trichoderma, memotong daun yang termakan ulat, serta pengaplikasian insektisida.

<br/><br/>5. Panen<br/>
Bawang merah akan memasuki masa panennya pada hari ke-70 atau 80 setelah ditanam. Tanaman yang siap panen ditandai dengan umbi bawang merah yang menyembul ke permukaan tanah, serta daun yang merebah.

Cabut tanaman dan langsung bersihkan dari segala kotoran. Jemur di bawah sinar matahari agar tak lembab, kemudian gantung atau diletakkan di atas para-para.

Jika kamu melakukan penyimpanan dengan cara tepat seperti ini, umbi bawang merah bisa bertahan hingga 1 sampai 2 tahun lamanya.</span>
                    </li>
            <!-- Isi Konten -->
            

            <!-- End of Isi Konten -->
            
          </div>
        </main>
      </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>
    <script src="https://unpkg.com/shards-ui@latest/dist/js/shards.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sharrre/2.0.1/jquery.sharrre.min.js"></script>
    <script src="scripts/extras.1.1.0.min.js"></script>
    <script src="scripts/shards-dashboards.1.1.0.min.js"></script>
    <script src="scripts/app/app-components-overview.1.1.0.js"></script>
  </body>
