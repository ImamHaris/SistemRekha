<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?");
	}
?>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Sistem Rekomendasi Kesesuaian Lahan</title>
    <meta name="description" content="A high-quality &amp; free Bootstrap admin dashboard template pack that comes with lots of templates and components.">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" id="main-stylesheet" data-version="1.1.0" href="/SistemRekha/admin/styles/shards-dashboards.1.1.0.min.css">
    <link rel="stylesheet" href="styles/extras.1.1.0.min.css">
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </head>
  <body class="h-100">
    <div class="container-fluid">
      <div class="row">
        <!-- Main Sidebar -->
        <aside class="main-sidebar col-12 col-md-3 col-lg-2 px-0">
          <div class="main-navbar">
            <nav class="navbar align-items-stretch navbar-light bg-white flex-md-nowrap border-bottom p-0">
              <a class="navbar-brand w-100 mr-0" href="#" style="line-height: 25px;">
                <div class="d-table m-auto">
                  <img id="main-logo" class="d-inline-block align-top mr-1" style="max-width: 25px;" src="/SistemRekha/admin/images/logo.png" alt="Shards Dashboard">
                  <span class="d-none d-md-inline ml-1">Sistem Rekomendasi</span>
                </div>
              </a>
              <a class="toggle-sidebar d-sm-inline d-md-none d-lg-none">
                <i class="material-icons">&#xE5C4;</i>
              </a>
            </nav>
          </div>
          <form action="#" class="main-sidebar__search w-100 border-right d-sm-flex d-md-none d-lg-none">
            <div class="input-group input-group-seamless ml-3">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fas fa-search"></i>
                </div>
              </div>
              <input class="navbar-search form-control" type="text" placeholder="Search for something..." aria-label="Search"> </div>
          </form>
          <div class="nav-wrapper">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link " href="/SistemRekha/admin/index.php">
                  <i class="material-icons">edit</i>
                  <span>Dashboard</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/SistemRekha/admin/prediksi.php">
                  <i class="material-icons">view_module</i>
                  <span>Prediksi</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="/SistemRekha/admin/tipsbertani.php">
                  <i class="material-icons">view_module</i>
                  <span>Tips Bertani</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="/SistemRekha/admin/user-profile.php">
                  <i class="material-icons">person</i>
                  <span>Profil Pengguna</span>
                </a>
              </li>
            </ul>
          </div>
        </aside>
        <!-- End Main Sidebar -->
        <main class="main-content col-lg-10 col-md-9 col-sm-12 p-0 offset-lg-2 offset-md-3">
          <div class="main-navbar sticky-top bg-white">
            <!-- Main Navbar -->
            <nav class="navbar align-items-stretch navbar-light flex-md-nowrap p-0">
              <form action="#" class="main-navbar__search w-100 d-none d-md-flex d-lg-flex">
                <div class="input-group input-group-seamless ml-3">
                  <div class="input-group-prepend">
                    <div class="input-group-text">
                      <i class="fas fa-search"></i>
                    </div>
                  </div>
                  <input class="navbar-search form-control" type="text" placeholder="Cari..." aria-label="Search"> </div>
              </form>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle text-nowrap px-3" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <img class="user-avatar rounded-circle mr-2" src="/SistemRekha/admin/images/avatars/unnamed.png" alt="User Avatar">
                    <span class="d-none d-md-inline-block"><?php echo $_SESSION['username']; ?></span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-small">
                    <a class="dropdown-item" href="user-profile.php">
                      <i class="material-icons">&#xE7FD;</i> Profile</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item text-danger" href="logout.php">
                      <i class="material-icons text-danger">&#xE879;</i> Logout </a>
                  </div>
                </li>
              </ul>
              <nav class="nav">
                <a href="#" class="nav-link nav-link-icon toggle-sidebar d-md-inline d-lg-none text-center border-left" data-toggle="collapse" data-target=".header-navbar" aria-expanded="false" aria-controls="header-navbar">
                  <i class="material-icons">&#xE5D2;</i>
                </a>
              </nav>
            </nav>
          </div>
          <!-- / .main-navbar -->
          <div class="main-content-container container-fluid px-4">
            <!-- Page Header -->
            <div class="page-header row no-gutters py-4 mb-3 border-bottom">
              <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
                <span class="text-uppercase page-subtitle">Tips</span>
                <h3 class="page-title">Padi Sawah Rawa Lebak</h3>
              </div>
            </div>
            <!-- End Page Header -->
            
            <!-- Isi Konten -->
            
            <li class="list-group-item p-4">
                <strong class="text-muted d-block mb-2">Budidaya Padi di Lahan Rawa Lebak Tergantung pada Keramahan Alam</strong>
                <span>Lahan rawa lebak telah diusahakan petani Banjar dan petani Bugis secara tradisional di sepanjang pedalaman sungai di Kalimantan dan petani Melayu di Sumatera sejak ratusan tahun yang lalu.

                      Usahatani, khususnya padi di lahan rawa lebak ini semakin berkembang setelah pemerintah membangun polder di sepanjang sungai sehingga air banjir dapat terkontrol, seperti halnya polder Alabio dan polder Manteren di Kalimantan. Di lahan rawa lebak ini petani bisa tanam padi dua kali setahun bahkan tiga kali dengan menanam palawija dan sayuran.

                      Dalam terminologi petani Kalimantan,  lahan rawa lebak yang ditanami padi pada musim hujan disebut sawah barat dan jenis padinya disebut padi surung atau disebut juga padi air dalam (deepwater rice). Padi surung atau padi air dalam ini  mempunyai sifat khusus, yaitu dapat memanjang (elongate) mengikuti kenaikan genangan air dan dapat bangkit kembali apabila rebah.

<br/><br/>Kemampuan memanjang ini karena pertumbuhan buku akar yang terus menerus yang pada padi sawah umumnya tidak ditemukan. Contoh jenis padi ini yang sudah dilepas antara lain varietas Nagara, Tapus, dan Alabio dengan potensi hasil 2,0-2,5 ton per hektar. 

Namun sayang perkembangan padi air dalam ini tidak sepesat padi sawah umumnya. Dalam perkembangannya padi-padi sawah pasang surut dan sawah irigasi juga dapat ditanam di lahan rawa lebak pada musim hujan pada daerah-daerah yang air genangannya cepat surut. 

Adapun  lahan rawa lebak yang ditanami padi pada musim kemarau disebut sawah timur dan jenis padinya disebut padi rintak disebut juga padi rawa lebak.  Jenis padi ini  tidak bergantung musim seperti umumnya pada lokal yang dibudidayakan di lahan rawa dan berumur pendek (4 bulan).

Dalam kelompok padi rintak ini termasuk juga padi sawah irigasi, seperti Cisokan, Cisanggarung, Ciherang, Cikonga. Varietas IR 66, 64 dan 42 sekarang ini sangat diminati karena bentuk gabah/beras ramping (butir kecil)  dan cita rasa agak pera sesuai dengan preferensi masyarakat setempat di Kalimantan Selatan dan Kalimantan Tengah. 

<br/><br/>Keberhasilan budidaya padi di lahan rawa lebak ini sangat tergantung pada keramahan alam karena umumnya sering mengalami banjir. Banjir  di lahan rawa lebak, khususnya di kawasan Kalimantan sering bersifat mendadak, berbeda dengan di negara Thailand atau Vietnam  datangnya air secara bertahap sehingga kenaikan genangan dapat diikuti petumbuhan padi yang memanjang (elongate). 

Oleh karena itu, hal yang perlu diperhatikan dalam budidaya padi di lahan rawa lebak adalah penetapan waktu tanam.  Adakalanya penurunan air terasa lambat, tetapi penurunan dapat terjadi dengan sangat cepat.  Keterlambatan tanam juga mempunyai resiko akan panen saat air datang.

Oleh karena itu diperlukan varietas yang berumur pendek  sehingga dapat panen sebelum air datang. Beberapa wilayah rawa lebak dangkal atau pematang seperti lebak Babirik, Kabupaten Hulu Sungai Utara, Kalimantan Selatan sejak tahun 1980an  sudah menerapkan tanam padi dua kali setahun.

<br/><br/>Sistem tanam padi di lahan rawa lebak sangat beragam tergantung pada keadaan musim dan ketinggian genangan di lahan.  Sistem tanam padi di lahan rawa lebak dapat dengan beberapa sistem antara lain sistem sawah,  gogo rancah, rancah gogo, atau gogo tergantung keadaan musim atau ketersediaan air.

Bila pilihan sistem sawah maka pelaksanaan tanam dilakukan musim hujan atau menjelang akhir musim hujan. Tanam sistem gogo biasanya pada musim kemarau apabila masih ada hujan dengan air yang cukup tersedia. Pada sistem gogo rancah penanaman dilakukan pada akhir musim kemarau atau awal musim hujan, dan disebut sistem rancah gogo apabila tanam dilakukan akhir-akhir musim hujan menjelang musim kemarau. 

Pola tanam padi di lahan rawa lebak dapat mengikuti pola musim atau  waktu  genangan. Dalam hal ini petani di Kalimantan, menggunakan istilah watun I, watun II, dan Watun III untuk masing-masing lebak dangkal, tengahan dan dalam. (Shr)
                </span>
                
            </li>

            <!-- End of Isi Konten -->
            
          </div>
        </main>
      </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>
    <script src="https://unpkg.com/shards-ui@latest/dist/js/shards.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sharrre/2.0.1/jquery.sharrre.min.js"></script>
    <script src="scripts/extras.1.1.0.min.js"></script>
    <script src="scripts/shards-dashboards.1.1.0.min.js"></script>
    <script src="scripts/app/app-components-overview.1.1.0.js"></script>
  </body>
