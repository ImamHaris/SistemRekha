<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?");
	}
?>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Sistem Rekomendasi Kesesuaian Lahan</title>
    <meta name="description" content="A high-quality &amp; free Bootstrap admin dashboard template pack that comes with lots of templates and components.">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" id="main-stylesheet" data-version="1.1.0" href="/SistemRekha/admin/styles/shards-dashboards.1.1.0.min.css">
    <link rel="stylesheet" href="styles/extras.1.1.0.min.css">
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </head>
  <body class="h-100">
    <div class="container-fluid">
      <div class="row">
        <!-- Main Sidebar -->
        <aside class="main-sidebar col-12 col-md-3 col-lg-2 px-0">
          <div class="main-navbar">
            <nav class="navbar align-items-stretch navbar-light bg-white flex-md-nowrap border-bottom p-0">
              <a class="navbar-brand w-100 mr-0" href="#" style="line-height: 25px;">
                <div class="d-table m-auto">
                  <img id="main-logo" class="d-inline-block align-top mr-1" style="max-width: 25px;" src="/SistemRekha/admin/images/logo.png" alt="Shards Dashboard">
                  <span class="d-none d-md-inline ml-1">Sistem Rekomendasi</span>
                </div>
              </a>
              <a class="toggle-sidebar d-sm-inline d-md-none d-lg-none">
                <i class="material-icons">&#xE5C4;</i>
              </a>
            </nav>
          </div>
          <form action="#" class="main-sidebar__search w-100 border-right d-sm-flex d-md-none d-lg-none">
            <div class="input-group input-group-seamless ml-3">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fas fa-search"></i>
                </div>
              </div>
              <input class="navbar-search form-control" type="text" placeholder="Search for something..." aria-label="Search"> </div>
          </form>
          <div class="nav-wrapper">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link " href="/SistemRekha/admin/index.php">
                  <i class="material-icons">edit</i>
                  <span>Dashboard</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/SistemRekha/admin/prediksi.php">
                  <i class="material-icons">view_module</i>
                  <span>Prediksi</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="/SistemRekha/admin/tipsbertani.php">
                  <i class="material-icons">view_module</i>
                  <span>Tips Bertani</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="/SistemRekha/admin/user-profile.php">
                  <i class="material-icons">person</i>
                  <span>Profil Pengguna</span>
                </a>
              </li>
            </ul>
          </div>
        </aside>
        <!-- End Main Sidebar -->
        <main class="main-content col-lg-10 col-md-9 col-sm-12 p-0 offset-lg-2 offset-md-3">
          <div class="main-navbar sticky-top bg-white">
            <!-- Main Navbar -->
            <nav class="navbar align-items-stretch navbar-light flex-md-nowrap p-0">
              <form action="#" class="main-navbar__search w-100 d-none d-md-flex d-lg-flex">
                <div class="input-group input-group-seamless ml-3">
                  <div class="input-group-prepend">
                    <div class="input-group-text">
                      <i class="fas fa-search"></i>
                    </div>
                  </div>
                  <input class="navbar-search form-control" type="text" placeholder="Cari..." aria-label="Search"> </div>
              </form>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle text-nowrap px-3" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <img class="user-avatar rounded-circle mr-2" src="/SistemRekha/admin/images/avatars/unnamed.png" alt="User Avatar">
                    <span class="d-none d-md-inline-block"><?php echo $_SESSION['username']; ?></span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-small">
                    <a class="dropdown-item" href="user-profile.php">
                      <i class="material-icons">&#xE7FD;</i> Profile</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item text-danger" href="logout.php">
                      <i class="material-icons text-danger">&#xE879;</i> Logout </a>
                  </div>
                </li>
              </ul>
              <nav class="nav">
                <a href="#" class="nav-link nav-link-icon toggle-sidebar d-md-inline d-lg-none text-center border-left" data-toggle="collapse" data-target=".header-navbar" aria-expanded="false" aria-controls="header-navbar">
                  <i class="material-icons">&#xE5D2;</i>
                </a>
              </nav>
            </nav>
          </div>
          <!-- / .main-navbar -->
          <div class="main-content-container container-fluid px-4">
            <!-- Page Header -->
            <div class="page-header row no-gutters py-4 mb-3 border-bottom">
              <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
                <span class="text-uppercase page-subtitle">Tips</span>
                <h3 class="page-title">Kelapa Sawit</h3>
              </div>
            </div>
            <!-- End Page Header -->
            
            <!-- Isi Konten -->
            
            <li class="list-group-item p-4">
                <strong class="text-muted d-block mb-2">Cara Bertanam Sawit Agar Tumbuh Optimal</strong>
                <span>Cara Bertanam Sawit yang benar akan mempengaruhi kualitas tanaman dan buah yang akan dihasilkan. Setelah mengetahui tentang cara melakukan pembibitan kelapa sawit yang benar, maka langkah selanjutnya adalah menanam bibit kelapa sawit yang sudah siap tanam ke kebun. Bibit kelapa sawit sudah siap tanam setelah berumur 8 bulan dari pembibitan.
                      Dalam Cara Bertanam Sawit yang harus diperhatikan adalah jarak tanam antar pohon, dan bentuk segitiga sama sisi sehingga memungkinkan adanya gang dari segala arah. Jarak tanam yang dianjurkan adalah 9 meter antar tanaman, hal ini selain untuk memberikan ruang tumbuh bagi pohon kelapa sawit juga memberikan ruang bagi akar-akar kelapa sawit agar tidak saling berebut nutrisi makanan pada tanah.
                </span>
                <br/>
                <br/>

                <strong class="text-muted d-block mb-2">Menentukan Jenis Tanah</strong>
                <span>Kelapa sawit memerlukan tanah yang relatif datar dengan lapisan tanah yang tebal, tidak tergenang dan jenis-jenis tanah subur untuk mendukung sehingga pertumbuhan-nya akan berlangsung secara optimal sehingga produksi TBS dapat meningkat secara signifikan. Berikut Jenis Tanah yang Baik untuk Kelapa Sawit :
                      <br/>Latosol
                      <br/>Merupakan tanah yang memiliki warna merah hingga coklat sehingga sering disebut dengan tanah merah. Sifat sifatnya seperti mudah menyerap air, merupakan tanah dalam, memiliki kandungan bahan organik yang sedang dengan pH tanah netral hingga asam. Jenis tanah Latosol ini banyak dijumpai di Sumatera Utara, Sumatera Barat, Bali, Jawa, Sulawesi Utara dan Papua. Selain untuk kelapa sawit, tanah Latosol juga sangat baik untuk tanaman Palawija, Padi, Karet dan Kopi.
                      <br/>Organosol
                      <br/>Merupakan tanah yang terbentuk dari hasil pelapukan bahan organik dan merupakan salah satu jenis tanah yang subur dan terbagi menjadi dua yaitu tanah humus dan tanah gambut. Jika tanah humus tidak perlu dibahas lagi karena banyak yang sudah tahu kekayaan unsur hara didalamnya, sedangkan untuk tanah gambut cenderung masam sehingga kurang cocok untuk tanaman lain, hingga saat ini baru kelapa sawit yang cocok tumbuh di tanah gambut.
                      <br/>Alluvial
                      <br/>Tanah aluvial merupakan tanah dengan ciri ciri mirip dengan latosol yang terbentuk dari hasil pengendapan material halus dari aliran sungai. Jenis tanah ini sering ditemukan di Daerah Aliran Sungai (DAS). Berwarna kelabu dengan struktur dengan sedikit lepas lepas dan mengenai tingkat kesuburan tanah Alluvial tergantung dari jenis material yang dibawah oleh aliran sungai. Tanah ini sangat cocok ditanami padi, palawija, buah buahan, tembakau dan berbagai tanaman palma seperti aren dan kelapa.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Menentukan Pola Tanam Sawit</strong>
                <span>Pola menanam yang dapat diterapkan pada budidaya sawit yaitu pola monokultur atau tumpang sari. Tanaman penutup tanah pada areal lahan perkebunan sawit sangat penting adanya untuk memperbaiki sifat fisika, kimia dan biologi pada tanah. Selain itu bermanfaat juga untuk mempertahankan kelembaban, mencegah erosi dan untuk menekan pertumbuhan tanaman pengganggu atau gulma. Tanaman penutup tanah yang dimaksud lebih baik berupa tanaman kacang-kacangan. Tanaman penutup sebaiknya segera ditanam segera setelah persiapan lahan selesai.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Pembuatan Lubang Tanam</strong>
                <span>Lubang tanam dibuat beberapa hari sebelum penanaman dilakukan. Lubang tanam dibuat dengan ukuran 50 x 40 cm dan kedalaman 40 cm. Tanah galian bagian atas setebal 20 cm dipisahkan dari tanah bagian bawah. Jarak antar lubang tanam yaitu 9 x 9 x 9 m. Apabila kebun kelapa sawit ebrupa area berbukit, harus dibuat teras melingkari bukit dengan jarak 1,5 m dari sisi lereng.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Cara Menanam Sawit</strong>
                <span>Waktu paling baik untuk menanam yaitu pada musim hujan, setelah hujan turun. Hal ini dimaksudkan agar cukup air untuk tumbuh. Lepaskan plastik polybag yang berisi bibit sawit dengan hati-hati jangan sampai bola tanahnya rusak karena dapat merusak perakaran bibit sawit. Kemudian masukkan bibit ke dalam lubang tanam. Tebarkan Natural Glio yang telah difermentasi dengan pupuk kandnag selama 1 minggu. Tebarkan pada sekitar perakaran tanaman. Setelah itu, segera timbun dengan tanah galian bagian atas. Setelah selesai penanaman bibit, siramkan POC NASA secara merata dengan dosis 5 – 10 ml per 1 liter air per pohon.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Pemakaian Pupuk Makro</strong>
                <span>Urea
                      <br/>Bulan ke-6, 12, 18, 24, 30 dan 36 : 225 kg/ha
                      <br/>Bulan ke-42, 48, 54, 60, dst : 1.000 kg/ha
                      <br/>TSP
                      <br/>Bulan ke-6, 12, 18, 24, 30 dan 36 : 115 kg/ha
                      <br/>Bulan ke-48 dan 60 : 750 kg/ha
                      <br/>MOP/KCL
                      <br/>Bulan ke-6, 12, 18, 24, 30 dan 36 : 200 kg/ha
                      <br/>Bulan ke-42, 48, 54, 60, dst : 1.200 kg/ha
                      <br/>Kieserite
                      <br/>Bulan ke-6, 12, 18, 24, 30 dan 36 : 75 kg/ha
                      <br/>Bulan ke-42, 48, 54, 60, dst : 600 kg/ha
                      <br/>Borax
                      <br/>Bulan ke-6, 12, 18, 24, 30 dan 36 : 20 kg/ha
                      <br/>Bulan ke-42, 48, 54, 60, dst : 40 kg/ha
                      <br/>Catatan : pemberian pupuk pertama dilakukan pada awal musim hujan (September – Oktober) dan kedua pada akhir musim hujan (Maret – April).
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Pupuk Organik Tambahan</strong>
                <span>
                      <br/>Tanaman Belum Mengahsilkan
                      <br/>SUPERNASA : 3 – 6 kg/ha (25 – 50 gr/tanaman) setiap 3 – 4 bulan sekali, larutkan dengan air secukupnya, disiramkan ke tanaman atau ditaburkan, dapat pula dicampur dengan pupuk makro.
                      <br/>POC NASA : 3 – 4 cc/liter (3 – 4 tutup/tangki ditambah 15 liter air untuk 15 tanaman) atau 500 cc/ha setiap 3 – 4 bulan sekali, semprotkan campur dengan Hormonik ke tanaman atau tanah
                      <br/>HORMONIK : 1 – 2 cc/liter (1 – 2 tutup/tangki ditambah 15 liter air untuk 15 tanaman) atau 500 cc/ha setiap 3 – 4 bulan sekali, siram arau semprotkan campur dengan POC NASA ke tanaman atau tanah.
                      <br/>SUPERNASA Granule : 50 kg/ha untuk TBM atau TM, setiap 3 – 4 bulans ekali, ditabur pada sekitar batang (dalam piringan)

                      <br/><br/>Tanaman Menghasilkan
                      <br/>Power Nutrition : 3 – 6 kg/ha (25 – 50 gr/tanaman), setiap 4 – 6 bulan sekali, larutkan dengan air secukupnya, dapat disiramkan atau ditaburkan, dapat pula dicampur dengan pupuk makro
                      <br/>SUPERNASA : 3 – 6 kg/ha (30 – 50 gr/tanaman), setiap 4 bulan sekali, larutkan dengan air secukupnya, dapat disiramkan atau ditaburkan, dapat pula dicampur dengan pupuk makro
                      <br/>Pemberian pupuk pada kelapa sawit merupakan salah satu kegiatan yang sangat penting untuk tujuan mempertahankan produksi buah sawit. Pohon kelapa sawit biasanya beruah sekitar 2 minggu sekali. Artinya, pemiliki perkebunan kelapa sawit akan panen setiap dua minggu sekali. Akan tetapi setiap periode panen tersebut, buah sawit yang dihasilkan tidak selalu sama banyak. Bisa jadi meningkat pada dua minggu pertama dan mengalami penurunan pada minggu keempatnya. Kondisi ini dapat dikarenakan oleh prosedur pemupukan sawit yang belum optimal.
                      
                      <br/><br/>
                      Itulah beberapa cara menanam kelapa sawit yang benar agar menghasilkan panen yang banyak. Yang perlu diperhatikan bahwa setiap varietas kelapa sawit memiliki kriteria tanam yang berbeda. Namun cara menanam yang dijelaskan di atas adalah cara yang sering digunakan dengan menghasilkan buah yang besar dan panen yang maksimal. 
                </span>
            </li>

            <!-- End of Isi Konten -->
            
          </div>
        </main>
      </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>
    <script src="https://unpkg.com/shards-ui@latest/dist/js/shards.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sharrre/2.0.1/jquery.sharrre.min.js"></script>
    <script src="scripts/extras.1.1.0.min.js"></script>
    <script src="scripts/shards-dashboards.1.1.0.min.js"></script>
    <script src="scripts/app/app-components-overview.1.1.0.js"></script>
  </body>
