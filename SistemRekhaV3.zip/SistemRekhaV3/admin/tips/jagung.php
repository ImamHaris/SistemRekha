<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?");
	}
?>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Sistem Rekomendasi Kesesuaian Lahan</title>
    <meta name="description" content="A high-quality &amp; free Bootstrap admin dashboard template pack that comes with lots of templates and components.">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" id="main-stylesheet" data-version="1.1.0" href="/SistemRekha/admin/styles/shards-dashboards.1.1.0.min.css">
    <link rel="stylesheet" href="styles/extras.1.1.0.min.css">
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </head>
  <body class="h-100">
    <div class="container-fluid">
      <div class="row">
        <!-- Main Sidebar -->
        <aside class="main-sidebar col-12 col-md-3 col-lg-2 px-0">
          <div class="main-navbar">
            <nav class="navbar align-items-stretch navbar-light bg-white flex-md-nowrap border-bottom p-0">
              <a class="navbar-brand w-100 mr-0" href="#" style="line-height: 25px;">
                <div class="d-table m-auto">
                  <img id="main-logo" class="d-inline-block align-top mr-1" style="max-width: 25px;" src="/SistemRekha/admin/images/logo.png" alt="Shards Dashboard">
                  <span class="d-none d-md-inline ml-1">Sistem Rekomendasi</span>
                </div>
              </a>
              <a class="toggle-sidebar d-sm-inline d-md-none d-lg-none">
                <i class="material-icons">&#xE5C4;</i>
              </a>
            </nav>
          </div>
          <form action="#" class="main-sidebar__search w-100 border-right d-sm-flex d-md-none d-lg-none">
            <div class="input-group input-group-seamless ml-3">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fas fa-search"></i>
                </div>
              </div>
              <input class="navbar-search form-control" type="text" placeholder="Search for something..." aria-label="Search"> </div>
          </form>
          <div class="nav-wrapper">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link " href="/SistemRekha/admin/index.php">
                  <i class="material-icons">edit</i>
                  <span>Dashboard</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/SistemRekha/admin/prediksi.php">
                  <i class="material-icons">view_module</i>
                  <span>Prediksi</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="/SistemRekha/admin/tipsbertani.php">
                  <i class="material-icons">view_module</i>
                  <span>Tips Bertani</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="/SistemRekha/admin/user-profile.php">
                  <i class="material-icons">person</i>
                  <span>Profil Pengguna</span>
                </a>
              </li>
            </ul>
          </div>
        </aside>
        <!-- End Main Sidebar -->
        <main class="main-content col-lg-10 col-md-9 col-sm-12 p-0 offset-lg-2 offset-md-3">
          <div class="main-navbar sticky-top bg-white">
            <!-- Main Navbar -->
            <nav class="navbar align-items-stretch navbar-light flex-md-nowrap p-0">
              <form action="#" class="main-navbar__search w-100 d-none d-md-flex d-lg-flex">
                <div class="input-group input-group-seamless ml-3">
                  <div class="input-group-prepend">
                    <div class="input-group-text">
                      <i class="fas fa-search"></i>
                    </div>
                  </div>
                  <input class="navbar-search form-control" type="text" placeholder="Cari..." aria-label="Search"> </div>
              </form>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle text-nowrap px-3" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <img class="user-avatar rounded-circle mr-2" src="/SistemRekha/admin/images/avatars/unnamed.png" alt="User Avatar">
                    <span class="d-none d-md-inline-block"><?php echo $_SESSION['username']; ?></span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-small">
                    <a class="dropdown-item" href="user-profile.php">
                      <i class="material-icons">&#xE7FD;</i> Profile</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item text-danger" href="logout.php">
                      <i class="material-icons text-danger">&#xE879;</i> Logout </a>
                  </div>
                </li>
              </ul>
              <nav class="nav">
                <a href="#" class="nav-link nav-link-icon toggle-sidebar d-md-inline d-lg-none text-center border-left" data-toggle="collapse" data-target=".header-navbar" aria-expanded="false" aria-controls="header-navbar">
                  <i class="material-icons">&#xE5D2;</i>
                </a>
              </nav>
            </nav>
          </div>
          <!-- / .main-navbar -->
          <div class="main-content-container container-fluid px-4">
            <!-- Page Header -->
            <div class="page-header row no-gutters py-4 mb-3 border-bottom">
              <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
                <span class="text-uppercase page-subtitle">Tips</span>
                <h3 class="page-title">Jagung</h3>
              </div>
            </div>
            <!-- End Page Header -->
            
            <!-- Isi Konten -->
            
            <li class="list-group-item p-4">
                <strong class="text-muted d-block mb-2">5 Tips Tanam Jagung Agar Hasil Panen Berkualitas Bagus</strong>
                <span>Jagung merupakan salah satu tanaman pangan yang biasa dibudidayakan di Indonesia. Tanam jagung pun menjadi aktivitas bercocok tanam yang digemari saat ini.

                      Jagung adalah tanaman semusim yang menyelesaikan satu daur hidupnya dalam waktu sekitar 3 sampai 5 bulan. Setengah waktu hidupnya merupakan fase vegetatif dan setengahnya lagi generatif.
                      Tanaman dengan nama ilmiah Zea mays ini biasa diolah menjadi nasi jagung, dibakar, direbus, atau dijadikan olahan kue. Selain itu, jagung merupakan bahan pokok tepung maizena dan minyak jagung, serta bahan kosmetika, industri farmasi, dan kimia.
                      Jika Anda tertarik untuk membudidayakan jagung, terdapat teknik atau tips tanam jagung yang dapat Anda lakukan agar hasil panen jagung berkualitas bagus. Simak di bawah ini.
                </span>
                <br/>
                <br/>

                <strong class="text-muted d-block mb-2">Pemilihan Benih</strong>
                <span>Pemilihan benih yang baik merupakan langkah awal untuk menghasilkan jagung yang berkualitas bagus. Oleh sebab itu, benih jagung yang digunakan haruslah adalah benih yang sehat dan tidak terserang penyakit.
                  <br/>
                      1. Pilihlah jenis jagung yang terpercaya dan direkomendasikan oleh pemerintah.
                      <br/>
                      2. Gunakan benih jagung yang segar dengan tingkat perkecambahan 85%.
                      <br/>
                      3. Pastikan benih yang digunakan tidak terlihat jelek dan terserang penyakit.Tentunya jangan gunakan benih yang dulunya terserang penyakit.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Pengolahan Lahan & Pembuatan Bedengan</strong>
                <span>Setelah mendapatkan bibit, langkah selanjutnya adalah mengolah lahan untuk budidaya jagung.
                      Agar jagung yang ditanam menghasilkan hasil yang bagus, lahan budidaya sebaiknya dilakukan pecangkulan agar tanahnya gembur. Tanah yang gembur bertujuan untuk memperlancar sirkulasi udara di dalam tanah.
                      Kemudian setelah dilakukan penggemburan tanah, lahan sebaiknya dibiarkan selama sekitar 1 minggu agar terpapar sinar matahari dan terkena angin.
                      Jika terdapat gulma, juga sebaiknya dilakukan pembersihan sebelum penanaman agar nantinya tidak mengganggu pertumbuhan tanaman.
                      Lakukan pengapuran jika pH tanah di bawah 5 karena tanaman jagung membutuhkan pH tanah yang cenderung basa. Pengapuran dapat dilakukan dengan menggunakan dolomite. Dosis pengapuran harus disesuaikan dengan tingkat keasaman lahan.
                      Apabila lahan yang akan digunakan sebelumnya adalah lahan sawah, maka lahan dapat langsung digunakan tetapi harus dipastikan bahwa drainase-nya dalam keadaan baik.
                      Selain itu, dapat juga dibuat bedengan. Pembuatan bedengan dapat dilakukan dengan  lebar sekitar 1 m, serta memiliki ketinggian sekitar 20-30 cm, dengan panjang yang disesuaikan dengan ukuran lahan.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Pengolahan Lahan</strong>
                <span>Pengolahan tanah sebaiknya dilakukan bersamaan dengan saat memulai pembibitan. Hal ini bertujuan agar lahan sudah siap ketika bibit cabai siap untuk dipindahkan. Pengolahan lahan bisa dimulai dengan melakukan pembajakan sedalam 40 cm untuk menghilangkan biji-biji gulma gulma yang masih tertanam di dalam tanah.
                      Selanjutnya, dibuat bedengan dengan tinggi 40 cm, lebar 1 m dan panjang menyesuaikan dengan panjang lahan. Sementara itu, jarak antar bedengan dapat dibuat sejauh 60 cm untuk memudahkan pemeliharan. Selain itu perlu juga dibuat drainese yang baik karena tanaman cabai merah tidak menyukai genangan air.
                      Pemberian pupuk organik seperti pupuk kandang atau pupuk kompos dapat dilakukan pada setiap bedengan yang sudah selesai dibuat. Budi daya cabai merah biasanya membutuhkan pupuk organik sebanyak 20 ton/ha, namun diperlukan juga tambahan pupuk KCL sebanyak 200kg/ha dan urea 350kg/ha.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Penanaman</strong>
                <span>Penanaman jagung untuk pertama kalinya sebaiknya dilakukan pada musim penghujan agar benih jagung memiliki pengairan yang cukup.
                      Untuk menanam jagung, cara yang harus dilakukan adalah dengan meletakkan 1-2 butir jagung ke dalam lubang tanam. Kemudian, tutuplah lubang tanam dengan menggunakan kompos dan berikan pengairan yang cukup.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Pengairan</strong>
                <span>Terdapat beberapa metode pengairan yang dapat digunakan dalam budidaya jagung, antara lain :
                      <br/>
                      1. Metode alur
                      <br/>
                      2. Metode genangan
                      <br/>
                      3. Metode sprinkler
                      <br/>
                      4. Metode bagian dari bawah permukaan
                      <br/>
                      5. Metode tetesan air
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Perawatan Dan Pemanenan</strong>
                <span>Agar mendapatkan jagung dengan hasil yang bagus, berikut ini adalah cara perawatan yang harus dilakukan :
                      <br/><br/>
                      1. Penyulaman
                      <br/>Penyulaman merupakan metode untuk melakukan pengecekan pada bibit jagung yang kira-kira berusia 1 minggu untuk memastikan bahwa jagung yang ditanam tumbuh dengan normal. Apabila terdapat jagung yang cacat, maka perlu dilakukan pembibitan ulang.
                      <br/><br/>2. Penyiangan
                      <br/>Penyiangan merupakan proses pembersihan gulma dari lahan tanam. Penyiangan dilakukan saat jagung berusia 2 minggu.
                      <br/><br/>3. Pemupukan
                      <br/>Pemupukan sebaiknya dilakukan dengan menggunakan pupuk kandang jenis Bokashi.
                      <br/><br/>4. Pemanenan
                      <br/>Setelah melakukan proses penanaman dan perawatan dengan baik, jagung dapat dipanen saat berusia 65-75 HST.
                      Jagung yang siap dipanen ditandai dengan warna kelobot yang sudah menguning, terdapat lapisan hitam pada dasar biji jagung, dan warna daun jagung sebagian besar sudah menguning.


                </span>

            </li>

            <!-- End of Isi Konten -->
            
          </div>
        </main>
      </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>
    <script src="https://unpkg.com/shards-ui@latest/dist/js/shards.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sharrre/2.0.1/jquery.sharrre.min.js"></script>
    <script src="scripts/extras.1.1.0.min.js"></script>
    <script src="scripts/shards-dashboards.1.1.0.min.js"></script>
    <script src="scripts/app/app-components-overview.1.1.0.js"></script>
  </body>
