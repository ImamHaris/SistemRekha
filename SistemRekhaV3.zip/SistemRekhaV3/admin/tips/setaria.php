<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?");
	}
?>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Sistem Rekomendasi Kesesuaian Lahan</title>
    <meta name="description" content="A high-quality &amp; free Bootstrap admin dashboard template pack that comes with lots of templates and components.">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" id="main-stylesheet" data-version="1.1.0" href="/SistemRekha/admin/styles/shards-dashboards.1.1.0.min.css">
    <link rel="stylesheet" href="styles/extras.1.1.0.min.css">
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </head>
  <body class="h-100">
    <div class="container-fluid">
      <div class="row">
        <!-- Main Sidebar -->
        <aside class="main-sidebar col-12 col-md-3 col-lg-2 px-0">
          <div class="main-navbar">
            <nav class="navbar align-items-stretch navbar-light bg-white flex-md-nowrap border-bottom p-0">
              <a class="navbar-brand w-100 mr-0" href="#" style="line-height: 25px;">
                <div class="d-table m-auto">
                  <img id="main-logo" class="d-inline-block align-top mr-1" style="max-width: 25px;" src="/SistemRekha/admin/images/logo.png" alt="Shards Dashboard">
                  <span class="d-none d-md-inline ml-1">Sistem Rekomendasi</span>
                </div>
              </a>
              <a class="toggle-sidebar d-sm-inline d-md-none d-lg-none">
                <i class="material-icons">&#xE5C4;</i>
              </a>
            </nav>
          </div>
          <form action="#" class="main-sidebar__search w-100 border-right d-sm-flex d-md-none d-lg-none">
            <div class="input-group input-group-seamless ml-3">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fas fa-search"></i>
                </div>
              </div>
              <input class="navbar-search form-control" type="text" placeholder="Search for something..." aria-label="Search"> </div>
          </form>
          <div class="nav-wrapper">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link " href="/SistemRekha/admin/index.php">
                  <i class="material-icons">edit</i>
                  <span>Dashboard</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/SistemRekha/admin/prediksi.php">
                  <i class="material-icons">view_module</i>
                  <span>Prediksi</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="/SistemRekha/admin/tipsbertani.php">
                  <i class="material-icons">view_module</i>
                  <span>Tips Bertani</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="/SistemRekha/admin/user-profile.php">
                  <i class="material-icons">person</i>
                  <span>Profil Pengguna</span>
                </a>
              </li>
            </ul>
          </div>
        </aside>
        <!-- End Main Sidebar -->
        <main class="main-content col-lg-10 col-md-9 col-sm-12 p-0 offset-lg-2 offset-md-3">
          <div class="main-navbar sticky-top bg-white">
            <!-- Main Navbar -->
            <nav class="navbar align-items-stretch navbar-light flex-md-nowrap p-0">
              <form action="#" class="main-navbar__search w-100 d-none d-md-flex d-lg-flex">
                <div class="input-group input-group-seamless ml-3">
                  <div class="input-group-prepend">
                    <div class="input-group-text">
                      <i class="fas fa-search"></i>
                    </div>
                  </div>
                  <input class="navbar-search form-control" type="text" placeholder="Cari..." aria-label="Search"> </div>
              </form>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle text-nowrap px-3" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <img class="user-avatar rounded-circle mr-2" src="/SistemRekha/admin/images/avatars/unnamed.png" alt="User Avatar">
                    <span class="d-none d-md-inline-block"><?php echo $_SESSION['username']; ?></span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-small">
                    <a class="dropdown-item" href="user-profile.php">
                      <i class="material-icons">&#xE7FD;</i> Profile</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item text-danger" href="logout.php">
                      <i class="material-icons text-danger">&#xE879;</i> Logout </a>
                  </div>
                </li>
              </ul>
              <nav class="nav">
                <a href="#" class="nav-link nav-link-icon toggle-sidebar d-md-inline d-lg-none text-center border-left" data-toggle="collapse" data-target=".header-navbar" aria-expanded="false" aria-controls="header-navbar">
                  <i class="material-icons">&#xE5D2;</i>
                </a>
              </nav>
            </nav>
          </div>
          <!-- / .main-navbar -->
          <div class="main-content-container container-fluid px-4">
            <!-- Page Header -->
            <div class="page-header row no-gutters py-4 mb-3 border-bottom">
              <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
                <span class="text-uppercase page-subtitle">Tips</span>
                <h3 class="page-title">Setaria</h3>
              </div>
            </div>
            <!-- End Page Header -->
            
            <!-- Isi Konten -->
            
            <li class="list-group-item p-4">
                <strong class="text-muted d-block mb-2">Cara Menanam Rumput Setaria yang Baik dan Merawatnya</strong>
                <span>Rumput setaria (Setaria sphacelata) adalah tanaman rumput tahunan yang biasanya digunakan sebagai pakan ternak. Rumput ini dikenal pula dengan sebutan golden timothy. Sejak didatangkan dari Australia pada tahun 1967, tanaman ini kini sudah menyebar luas di seluruh pelosok Indonesia. Tanaman rumput setaria ini mampu tumbuh dengan baik di daerah yang berketinggian 1300 meter dpl. Curah hujan yang cocok untuk mendukung pertumbuhannya berkisar antara 625-1250 mm per tahun. Setaria merupakan tumbuhan yang sangat tahan terhadap kekeringan. Meskipun begitu, rumput ini juga sanggup bertahan hidup di tempat yang agak tergenang air asalkan bukan rawa-rawa.
                Tanaman rumput setaria termasuk salah satu rumput unggul yang bisa hidup sepanjang tahun. Rumput ini mengandung protein kasar dengan kadar 13,09% dan serat kasar sebanyak 30,15%. Tingkat produksi rumput ini dipengaruhi oleh umur pemotongannya. Rata-rata produksi hijauan sekitar 160-170 ton atau kurang lebih 20-45 ton bahan kering setiap hektar per tahun.
                </span>
                <br/>
                <br/>

                <strong class="text-muted d-block mb-2">Tahap Penanaman</strong>
                <span>Terdapat 3 teknik penanaman rumput setaria yang baik antara lain penyebaran benih, penanaman benih dalam garitan, dan penanaman dengan sobekan rumpun. Teknik penanaman dengan penyebaran benih dilaksanakan dengan menyebar benih-benih rumput setaria tersebut langsung di atas permukaan tanah, kemudian tutup kembali dengan lapisan tanah yang tipis. Kebutuhan benih yang diperlukan pada teknik penanaman ini berkisar antara 5-10 kg/hektar. Prosesnya yang mudah dilakukan membuat masyarakat biasanya menanam rumput setaria menggunakan teknik ini.

Pada penanaman benih rumput setaria dalam garitan, Anda perlu membuat garitan dengan kedalaman 2-3 cm terlebih dahulu. Setelah itu, benih-benih tadi disebar di dalam garitan kemudian ditutup kembali memakai tanah. Jarak antara garitan yang ideal adalah 50 cm. sehingga perkiraan kebutuhan benih ialah 2-3 kg/hektar. Sementara itu, penanaman dengan sobekan rumpun dilaksanakan dengan menanamkan bibit-bibit rumput setaria di dalam lubang tanam sedalam 10-15 cm. Jarak penanaman yang disarankan adalah 50 x 50 cm. Jadi sobekan rumpun yang dibutuhkan yakni 40.000/hektar. Berikutnya padatkanlah tanah di sekitar bibit agar tidak mudah goyah.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Tahap Perawatan</strong>
                <span>Agar diperoleh hasil produksi hijauan dengan tingkat produktivitas yang tinggi, tanaman rumput setaria ini perlu diberi pupuk secara berkala. Pupuk utama yang digunakan untuk mendukung pertumbuhannya yaitu pupuk nitrogen yang terdiri dari pupuk urea 1.600 kg/ha/tahun, ZA 400 kg/ha/tahun, serta TSP 400 kg/ha/tahun. Apabila tingkat keasaman media tanam yang digunakan ini bersifat terlalu asam, Anda bisa menaburkan kapur pertanian dalam dosisi yang secukupnya agar pH tanah tersebut bertambah menjadi 6-6,5. Sehingga pH tanah tersebut menjadi tidak asam lagi.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Tahap Pemanenan</strong>
                <span>Pemanenan rumput setaria dilakukan dengan memotong rumput-rumput tersebut. Waktu pemanenan yang paling baik adalah pada saat rumput ini berusia 30 hari dan tingginya telah mencapai 90 cm. Tahap pemanenan ini sebaiknya dikerjakan ketika masa pertumbuhan vegetatif tersebut atau sebelum rumput menghasilkan bunga. Ini disebabkan setelah masa tersebut, rumput setaria tidak bakalan lagi mengalami proses pertumbuhan. Adapun cara memanen rumput setaria ini dikerjakan dengan mencabut bersama akarnya atau memotongnya saja menggunakan gunting pangkas. Anda dapat menyesuaikannya dengan kebutuhan.


                </span>

                

            </li>

            <!-- End of Isi Konten -->
            
          </div>
        </main>
      </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>
    <script src="https://unpkg.com/shards-ui@latest/dist/js/shards.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sharrre/2.0.1/jquery.sharrre.min.js"></script>
    <script src="scripts/extras.1.1.0.min.js"></script>
    <script src="scripts/shards-dashboards.1.1.0.min.js"></script>
    <script src="scripts/app/app-components-overview.1.1.0.js"></script>
  </body>
