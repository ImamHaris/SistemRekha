<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?");
	}
?>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Sistem Rekomendasi Kesesuaian Lahan</title>
    <meta name="description" content="A high-quality &amp; free Bootstrap admin dashboard template pack that comes with lots of templates and components.">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" id="main-stylesheet" data-version="1.1.0" href="/SistemRekha/admin/styles/shards-dashboards.1.1.0.min.css">
    <link rel="stylesheet" href="styles/extras.1.1.0.min.css">
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </head>
  <body class="h-100">
    <div class="container-fluid">
      <div class="row">
        <!-- Main Sidebar -->
        <aside class="main-sidebar col-12 col-md-3 col-lg-2 px-0">
          <div class="main-navbar">
            <nav class="navbar align-items-stretch navbar-light bg-white flex-md-nowrap border-bottom p-0">
              <a class="navbar-brand w-100 mr-0" href="#" style="line-height: 25px;">
                <div class="d-table m-auto">
                  <img id="main-logo" class="d-inline-block align-top mr-1" style="max-width: 25px;" src="/SistemRekha/admin/images/logo.png" alt="Shards Dashboard">
                  <span class="d-none d-md-inline ml-1">Sistem Rekomendasi</span>
                </div>
              </a>
              <a class="toggle-sidebar d-sm-inline d-md-none d-lg-none">
                <i class="material-icons">&#xE5C4;</i>
              </a>
            </nav>
          </div>
          <form action="#" class="main-sidebar__search w-100 border-right d-sm-flex d-md-none d-lg-none">
            <div class="input-group input-group-seamless ml-3">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fas fa-search"></i>
                </div>
              </div>
              <input class="navbar-search form-control" type="text" placeholder="Search for something..." aria-label="Search"> </div>
          </form>
          <div class="nav-wrapper">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link " href="/SistemRekha/admin/index.php">
                  <i class="material-icons">edit</i>
                  <span>Dashboard</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/SistemRekha/admin/prediksi.php">
                  <i class="material-icons">view_module</i>
                  <span>Prediksi</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="/SistemRekha/admin/tipsbertani.php">
                  <i class="material-icons">view_module</i>
                  <span>Tips Bertani</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="/SistemRekha/admin/user-profile.php">
                  <i class="material-icons">person</i>
                  <span>Profil Pengguna</span>
                </a>
              </li>
            </ul>
          </div>
        </aside>
        <!-- End Main Sidebar -->
        <main class="main-content col-lg-10 col-md-9 col-sm-12 p-0 offset-lg-2 offset-md-3">
          <div class="main-navbar sticky-top bg-white">
            <!-- Main Navbar -->
            <nav class="navbar align-items-stretch navbar-light flex-md-nowrap p-0">
              <form action="#" class="main-navbar__search w-100 d-none d-md-flex d-lg-flex">
                <div class="input-group input-group-seamless ml-3">
                  <div class="input-group-prepend">
                    <div class="input-group-text">
                      <i class="fas fa-search"></i>
                    </div>
                  </div>
                  <input class="navbar-search form-control" type="text" placeholder="Cari..." aria-label="Search"> </div>
              </form>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle text-nowrap px-3" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <img class="user-avatar rounded-circle mr-2" src="/SistemRekha/admin/images/avatars/unnamed.png" alt="User Avatar">
                    <span class="d-none d-md-inline-block"><?php echo $_SESSION['username']; ?></span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-small">
                    <a class="dropdown-item" href="user-profile.php">
                      <i class="material-icons">&#xE7FD;</i> Profile</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item text-danger" href="logout.php">
                      <i class="material-icons text-danger">&#xE879;</i> Logout </a>
                  </div>
                </li>
              </ul>
              <nav class="nav">
                <a href="#" class="nav-link nav-link-icon toggle-sidebar d-md-inline d-lg-none text-center border-left" data-toggle="collapse" data-target=".header-navbar" aria-expanded="false" aria-controls="header-navbar">
                  <i class="material-icons">&#xE5D2;</i>
                </a>
              </nav>
            </nav>
          </div>
          <!-- / .main-navbar -->
          <div class="main-content-container container-fluid px-4">
            <!-- Page Header -->
            <div class="page-header row no-gutters py-4 mb-3 border-bottom">
              <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
                <span class="text-uppercase page-subtitle">Tips</span>
                <h3 class="page-title">Padi Gogo</h3>
              </div>
            </div>
            <!-- End Page Header -->
            
            <!-- Isi Konten -->
            
            <li class="list-group-item p-4">
                <strong class="text-muted d-block mb-2">Cara Menanam Padi Gogo</strong>
                <span>Cara menanam padi gogo berbeda dengan menanam padi di lahan sawah. Perbedaan cara menanam padi gogo yaitu lahan yang digunakan adalah lahan kering, tanam benih langsung, hama dan penyakit dominan dan beberapa teknik budidaya padi menyesuaikan agroekosostem gogo. Varietas padi yang ditanam merupakan padi yang tahan kekeringan dan tahan penyakit utama pada padi gogo yaitu penyakit blas.
                </span>
                <br/>
                <br/>

                <strong class="text-muted d-block mb-2">Pengolahan Tanah</strong>
                <span>Pengolahan tanah untuk menanam padi gogo dilakukan sebanyak dua kali. Pengolahan tanah dapat dilakukan menggunakan cangkul atau traktor. Pengolahan tanah pertama dilakukan pada musim kemarau atau setelah terjadi hujan pertama yang dapat melembabkan tanah. Pengolah tanah kedua dilakukan saat menjelang tanam untuk menghaluskan bongkahan tanah dan meratakan tanah.
                      Pada lahan yang datar dengan hamparan yang luas, dibuat bedengan memanjang menyesuaikan luas lahan. Antar bedengan dibuat saluran drainase untuk menghindari adanya genangan saat hujan yang dapat menyebabkan kelembabab tanah tinggi dan merangsang munculnya jamur upas yang dapat menyerang tanaman padi gogo. Pada lahan yang berlereng dan bergelombang, perlu dibuat teras gulud untuk menahan erosi tanah. Pada teras gulud ditanami rumput dan pohon yang secra periodik dapat dipangkas untuk pakan ternak.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Varietas Unggul Padi Gogo</strong>
                <span>Varietas unggul padi gogo selain mempunyai potensi hasil tinggi juga mempunyai ketahanan terhdap kekeringan, keracunan alumunium dan atau tahan penyakit blas. Beberapa varietas unggul padi gogo yaitu Situbagendit, Situ Patenggang, Inpago 4, Inpago 5, Inpago 6, Inpago 7, Inpago 8, Inpago 9, Inpago 10, Inpago Lipigo 4 dan Inpago 11 Agritan. Inpago yang dimaksud adalah Inbrida Padi Gogo
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Cara Menanam Padi Gogo</strong>
                <span>Padi gogo ditanam bila hujan turun secara kontinyu dan mencapai sekitar 60 mm/dekade (10 hari). Cara menanam padi gogo dapat dilakukan dengan tugal dan larikan. Cara menanam padi gogo sistem tugal dilakukan dengan membuat lubang tanam dengan tugal sedalam 5 cm, setiap lubang berisi 4-5 butir kemudian ditutup dengan tanah atau kompos. pada cara menanam padi gogo sistem larikan, tanah dibuat larikan menggunakan caplak menyesuaikan jarak tanamnya, kemudian benih ditabur di dalam larikan dan ditutup dengan tanah atau kompos. Jarak tanam padi gogo bisa dengan sistem tegel atau legowo. Jarak tanam tegel yang direkomendasikan untuk padi gogo yaitu 20 x 20 cm, sedangkan untuk legowo 30 x 20 x 10 cm.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Pemupukan Padi Gogo</strong>
                <span>Pupuk untuk padi gogo terdiri dari pupuk organik 1500-2000 kg/ ha, Urea 150-200 kg/ha, TSP 100 kg/ha dan KCl 50 kg/ha. Pupuk organik diberikan pada saat pengolahan lahan dan saat tanam untuk menutup lubang tanam. TSP dan KCl diberikan pada saat tanam dengan cara disebar atau alur di dekat lubang tanam. Pupuk urea diberikan pada umur 14 hari setetah tanam (hst) sebanyak 1/6 bagian, pada umur 42 hst sebanyak 1/2 bagian dan pada umur 55 1/3 bagian. Dosis pupuk rekomendasi tersebut dapat berlaku fleksibel menyesuaikan kondisi lahan, ketersediaan hara tanah dan kebutuhan tanaman.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Hama dan Penyakit Padi Gogo</strong>
                <span>Budidaya padi gogo seperti halnya budidaya padi sawah terdapat gangguan biotik dan abiotik. Gangguan abiotik dapat berupa kekurangan air dan tingkat ketersediaan hara tanah. Untuk itu penentuan musim tanam yang tepat yaitu bulan basah selama minimal 4 bulan menjadi faktor keberhasilan budidaya padi gogo. Untuk ketersediaan hara tanah dapat diatasi dengan penambahan pupuk organik dan anorganik.
                      Gangguan lain budidaya padi gogo yaitu serangan hama dan penyakit. Serangan hama yang sering muncul pada budidaya padi gogo yaitu lalat bibit, penggerek batang, lundi, wereng coklat, kepik dan walang sangit. Sedangkan penyakit utama padi gogo yaitu penyakit blas. Untuk mengurangi kerugian akibat serangan hama dan penyakit, perlu ada strategi pengendalian yang baik dan ramah lingkungan yaitu dengan penggunaan varietas unggul padi gogo yang tahan hama dan penyakit, penanaman varietas berseling (mozaik varietas) untuk memutus penyebaran jamur blas dan pengendalian dengan pestisida sesuai rekomendasi setempat.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Pengendalian Gulma</strong>
                <span>Gulma merupakan kendala utama dalam budidaya padi gogo, karena pertumbuhan gulma pada kondisi kering akan lebih cepat dan lebih banyak. Jika tidak dikendalikan, cara menanam padi gogo yang sudah dilaksanakan dengan baik akan sia-saia karena tanaman utama padi gogo akan kalah bersaiang dalam mendapatkan cahaya, air dan hara.
                      Pengendalian gulma pada pertanaman padi gogo sebaiknya dilakukan lebig awal. Penyiangan pertama dilakukan 10-15 hari setelah tanam atau menjelang pemupukan pertama. Penyiangan kedua pada umur 30-45 atau menjelang pemupukan susulan. Penyiangan dilakukan menggunakan kored, ada atau tidak ada gulma penyiangan dapat memotong akar dan menstimulasi pertumbuhan kar baru. Selain itu penyiangan juga dapat memotong saluran air kapiler yang dapat menyebabkan terjadinya penguapan air dari dalam tanah. 
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Panen Padi Gogo</strong>
                <span>Akhir dari proses menanam padi gogo adalah panen. Panen dilakukan bila gabah 95% sudah menguning atau umur masak fisologis. Tanaman padi gogo dapat dipanen pada umur 100-125 hst atau tergantung varietas padi gogo yang ditanam. Rata-rata produksi padi gogo sekitar 3-5 ton/ha GKG.
                </span>
            </li>

            <!-- End of Isi Konten -->
            
          </div>
        </main>
      </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>
    <script src="https://unpkg.com/shards-ui@latest/dist/js/shards.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sharrre/2.0.1/jquery.sharrre.min.js"></script>
    <script src="scripts/extras.1.1.0.min.js"></script>
    <script src="scripts/shards-dashboards.1.1.0.min.js"></script>
    <script src="scripts/app/app-components-overview.1.1.0.js"></script>
  </body>
