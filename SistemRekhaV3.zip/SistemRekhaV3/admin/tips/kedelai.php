<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?");
	}
?>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Sistem Rekomendasi Kesesuaian Lahan</title>
    <meta name="description" content="A high-quality &amp; free Bootstrap admin dashboard template pack that comes with lots of templates and components.">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" id="main-stylesheet" data-version="1.1.0" href="/SistemRekha/admin/styles/shards-dashboards.1.1.0.min.css">
    <link rel="stylesheet" href="styles/extras.1.1.0.min.css">
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </head>
  <body class="h-100">
    <div class="container-fluid">
      <div class="row">
        <!-- Main Sidebar -->
        <aside class="main-sidebar col-12 col-md-3 col-lg-2 px-0">
          <div class="main-navbar">
            <nav class="navbar align-items-stretch navbar-light bg-white flex-md-nowrap border-bottom p-0">
              <a class="navbar-brand w-100 mr-0" href="#" style="line-height: 25px;">
                <div class="d-table m-auto">
                  <img id="main-logo" class="d-inline-block align-top mr-1" style="max-width: 25px;" src="/SistemRekha/admin/images/logo.png" alt="Shards Dashboard">
                  <span class="d-none d-md-inline ml-1">Sistem Rekomendasi</span>
                </div>
              </a>
              <a class="toggle-sidebar d-sm-inline d-md-none d-lg-none">
                <i class="material-icons">&#xE5C4;</i>
              </a>
            </nav>
          </div>
          <form action="#" class="main-sidebar__search w-100 border-right d-sm-flex d-md-none d-lg-none">
            <div class="input-group input-group-seamless ml-3">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fas fa-search"></i>
                </div>
              </div>
              <input class="navbar-search form-control" type="text" placeholder="Search for something..." aria-label="Search"> </div>
          </form>
          <div class="nav-wrapper">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link " href="/SistemRekha/admin/index.php">
                  <i class="material-icons">edit</i>
                  <span>Dashboard</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/SistemRekha/admin/prediksi.php">
                  <i class="material-icons">view_module</i>
                  <span>Prediksi</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="/SistemRekha/admin/tipsbertani.php">
                  <i class="material-icons">view_module</i>
                  <span>Tips Bertani</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link " href="/SistemRekha/admin/user-profile.php">
                  <i class="material-icons">person</i>
                  <span>Profil Pengguna</span>
                </a>
              </li>
            </ul>
          </div>
        </aside>
        <!-- End Main Sidebar -->
        <main class="main-content col-lg-10 col-md-9 col-sm-12 p-0 offset-lg-2 offset-md-3">
          <div class="main-navbar sticky-top bg-white">
            <!-- Main Navbar -->
            <nav class="navbar align-items-stretch navbar-light flex-md-nowrap p-0">
              <form action="#" class="main-navbar__search w-100 d-none d-md-flex d-lg-flex">
                <div class="input-group input-group-seamless ml-3">
                  <div class="input-group-prepend">
                    <div class="input-group-text">
                      <i class="fas fa-search"></i>
                    </div>
                  </div>
                  <input class="navbar-search form-control" type="text" placeholder="Cari..." aria-label="Search"> </div>
              </form>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle text-nowrap px-3" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <img class="user-avatar rounded-circle mr-2" src="/SistemRekha/admin/images/avatars/unnamed.png" alt="User Avatar">
                    <span class="d-none d-md-inline-block"><?php echo $_SESSION['username']; ?></span>
                  </a>
                  <div class="dropdown-menu dropdown-menu-small">
                    <a class="dropdown-item" href="user-profile.php">
                      <i class="material-icons">&#xE7FD;</i> Profile</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item text-danger" href="logout.php">
                      <i class="material-icons text-danger">&#xE879;</i> Logout </a>
                  </div>
                </li>
              </ul>
              <nav class="nav">
                <a href="#" class="nav-link nav-link-icon toggle-sidebar d-md-inline d-lg-none text-center border-left" data-toggle="collapse" data-target=".header-navbar" aria-expanded="false" aria-controls="header-navbar">
                  <i class="material-icons">&#xE5D2;</i>
                </a>
              </nav>
            </nav>
          </div>
          <!-- / .main-navbar -->
          <div class="main-content-container container-fluid px-4">
            <!-- Page Header -->
            <div class="page-header row no-gutters py-4 mb-3 border-bottom">
              <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
                <span class="text-uppercase page-subtitle">Tips</span>
                <h3 class="page-title">Kedelai</h3>
              </div>
            </div>
            <!-- End Page Header -->
            
            <!-- Isi Konten -->
            
            <li class="list-group-item p-4">
                <strong class="text-muted d-block mb-2">Tanam Kedelai Lebih Mudah dengan 5 Langkah Ini</strong>
                <span>Kedelai merupakan tanaman yang memiliki beragam manfaat dan baik untuk dikonsumsi. Kandungan yang dimiliki oleh kedelai sangat banyak, misalnya kandungan protein nabati yang bisa dijadikan makanan diet rendah kalori. Banyaknya manfaat yang bisa diambil dari kedelai, membuat banyak orang memilih untuk tanam kedelai.
                      Selain memiliki kandungan yang sehat, kedelai juga bisa diolah menjadi berbagai makanan atau minuman, salah satunya adalah tempe, susu, dan tahu. Kebutuhan konsumen pun kian hari meningkat, sehingga permintaan pasar akan kedelai sangat tinggi. Hal ini tentu saja bisa dijadikan sebagai peluang usaha dengan tanam kedelai.
                </span>
                <br/>
                <br/>

                <strong class="text-muted d-block mb-2">5 Langkah Tanam Kedelai yang Mudah</strong>
                <span>Untuk mendapatkan keuntungan yang maksimal, diperlukan langkah yang tepat untuk membudidayakan kedelai. Berikut ini merupakan langkah menanam kedelai yang baik di antaranya adalah sebagai berikut:
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Memilih Lahan Tanam Kedelai yang Benar</strong>
                <span>Tanaman kedelai bisa hidup di dataran rendah maupun dataran tinggi. Namun untuk memilih lahan tanam kedelai yang baik, kamu harus memenuhi kriteria tanah yang sesuai, yaitu:
                      <br/>- Tanah yang gembur
                      <br/>- Memiliki pH 5,5 sampai 7,5 pada tanah
                      <br/>- Ketinggian tanah 2 hingga 900 m dari atas permukaan laut
                      <br/>- Bisa terkena sinar matahari minimal 8 jam per hari
                      <br/>- Tanah dekat dengan sumber air
                      <br/>- Jauh dari pantai untuk menghindari aerosol air asin
                      <br/>- Setelah menemukan lahan yang sesuai dengan kriteria tanah yang benar, Anda harus mengelola lahan lebih baik. Anda bisa menggemburkan tanah dengan menggunakan cangkul atau mesin traktor pada lahan yang didominasi oleh tanah liat.
                      <br/><br/>Untuk jenis tanah yang kering dan gembur, sebaiknya bedengan yang dibuat tidak terlalu tinggi. Ukuran bedengan yang ideal adalah lebar 1,5 m, tinggi 5 cm.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Pemberian Pupuk Dasar pada Lahan</strong>
                <span>Berikan pupuk dasar berupa pupuk organik, pupuk buatan, insektisida tabur, fungisida, dan kapur dulomit pada tiap bedengan. Di sepanjang jalur lubang bedengan, diberikan pupuk organik. Setelah itu, dilanjutkan dengan taburan kapur dulomit, insektisida tabur serta fungisida.
                      Aduk semua pupuk tersebut hingga tercampur merata, lalu bedengan diberi air agar pupuk cepat terurai. Setelah 2 minggu, maka lahan siap ditanami benih kedelai.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Penanaman Benih Kedelai yang Benar</strong>
                <span>Lubang tanam kedelai harus memiliki jarak tanam sekitar 25 x 40 cm. Cara membuat lubang tanam adalah dengan menusuk bedengan dengan menggunakan kayu sebesar lengan. Berikut ini merupakan cara penanaman kedelai yaitu:
                <br/>
                      <br/>- Memilih benih kedelai yang unggul. Anda bisa membelinya di toko pertanian.
                      <br/>- Masukan biji kedelai ke dalam lubang tanam yang sudah dibuat. Satu lubang bisa memuat 2-3 biji kedelai.
                      <br/>- Tutup kembali lubang tersebut dengan tanah.
                      <br/>- Beri air bedengan agar cepat tumbuh.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Perawatan</strong>
                <span>Untuk menghasilkan kedelai yang bagus dan berkualitas, Anda harus melakukan perawatan tanam kedelai dengan baik dan teratur, seperti berikut:
                <br/>
                      <br/>Pengairan 
                      <br/>perlu diperhatikan, karena tanaman kedelai sangat sensitif pada kadar air tanah, sebab itu usahakan tanah selalu basah. Anda bisa menggunakan mesin pompaair agar memudahkan pengairan bedengan.
                      <br/>Penyiangan 
                      <br/>dilakukan untuk mencegah hilangnya nutrisi pada tanaman yang disebabkan oleh rumput.
                      <br/>Pemupukan 
                      <br/>susulan dilakukan saat tanaman sudah tumbuh satu bulan pertama, dan setelah penyiangan agar nutrisi pupuk tidak dicuri oleh rumput.
                      <br/>Pengusiran hama 
                      <br/>yang mengganggu pada tanaman kedelai penting dilakukan sehingga panen yang dihasilkan maksimal.
                </span>

                <br/><br/>
                <strong class="text-muted d-block mb-2">Panen Kedelai</strong>
                <span>Anda bisa memanen tanaman kedelai dalam kondisi masih muda maupun sudah tua (tanaman berumur 3 bulan).
                      Biasanya, kedelai yang hendak dipanen memiliki biji yang kering dan kulit buahnya menguning kecoklatan. Setelah dipetik, maka segera dijemur. Namun, bila kedelai akan dijual, maka sebaiknya dipanen ketika kedelai masih hijau lalu rebus.
                </span>
            </li>

            <!-- End of Isi Konten -->
            
          </div>
        </main>
      </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>
    <script src="https://unpkg.com/shards-ui@latest/dist/js/shards.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sharrre/2.0.1/jquery.sharrre.min.js"></script>
    <script src="scripts/extras.1.1.0.min.js"></script>
    <script src="scripts/shards-dashboards.1.1.0.min.js"></script>
    <script src="scripts/app/app-components-overview.1.1.0.js"></script>
  </body>
