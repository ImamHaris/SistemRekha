<?php
    $lokasi = $_POST["lokasi"];

    $temperatur = $_POST["temperatur"];
    $curahhujan = $_POST["curahhujan"];
    $ketersediaanair = $_POST["ketersediaanair"];
    $drainase = $_POST["drainase"];
    $tekstur = $_POST["tekstur"];
    $bahankasar = $_POST["bahankasar"];
    $kedalamantanah = $_POST["kedalamantanah"];
    $ketebalangambut = $_POST["ketebalangambut"];
    $kematangan = $_POST["kematangan"];
    $ktktanah = $_POST["ktktanah"];
    $kejenuhanbasa = $_POST["kejenuhanbasa"];
    $phh2o = $_POST["phh2o"];
    $corganik = $_POST["corganik"];
    $ntotal = $_POST["ntotal"];
    $p2o5 = $_POST["p2o5"];
    $k2o = $_POST["k2o"];
    $salinitas = $_POST["salinitas"];
    $alkalinitas = $_POST["alkalinitas"];
    $kedalamansulfidik = $_POST["kedalamansulfidik"];
    $lereng = $_POST["lereng"];
    $bahayaerosi = $_POST["bahayaerosi"];
    $tinggigenangan = $_POST["tinggigenangan"];
    $lamagenangan = $_POST["lamagenangan"];
    $batuan = $_POST["batuan"];
    $singkapan = $_POST["singkapan"];
?>