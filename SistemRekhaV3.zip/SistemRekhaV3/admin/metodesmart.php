<?php

//SMART
$s1n=1;$s2n=0.75;$s3n=0.5;$nn=0.25;

//C1
if(($c1p == $s1n) && ($c1p==$c1j) && ($c1p==$c1k) && ($c1p == $c1psth) && ($c1p==$c1pgogo) && ($c1p==$c1psrps) && ($c1p == $c1psrl) && ($c1p==$c1b) && ($c1p==$c1c) && ($c1p == $c1s) && ($c1p==$c1ka) && ($c1p==$c1t) && ($c1p==$c1r) && ($c1p==$c1set)){
    $c1padi = 100; $c1padisth = 100; $c1padisrl = 100; $c1sawit = 100; $c1rumput = 100;
    $c1jagung = 100; $c1padigogo = 100; $c1bawang = 100; $c1kakao = 100; $c1setaria = 100;
    $c1kedelai = 100; $c1padisrps = 100; $c1cabai = 100; $c1tebu = 100;
}else if(($c1p == $s2n) && ($c1p==$c1j) && ($c1p==$c1k) && ($c1p == $c1psth) && ($c1p==$c1pgogo) && ($c1p==$c1psrps) && ($c1p == $c1psrl) && ($c1p==$c1b) && ($c1p==$c1c) && ($c1p == $c1s) && ($c1p==$c1ka) && ($c1p==$c1t) && ($c1p==$c1r) && ($c1p==$c1set)){
    $c1padi = 66.6; $c1padisth = 66.6; $c1padisrl = 66.6; $c1sawit = 66.6; $c1rumput = 66.6;
    $c1jagung = 66.6; $c1padigogo = 66.6; $c1bawang = 66.6; $c1kakao = 66.6; $c1setaria = 66.6;
    $c1kedelai = 66.6; $c1padisrps = 66.6; $c1cabai = 66.6; $c1tebu = 66.6;
}else if(($c1p == $s3n) && ($c1p==$c1j) && ($c1p==$c1k) && ($c1p == $c1psth) && ($c1p==$c1pgogo) && ($c1p==$c1psrps) && ($c1p == $c1psrl) && ($c1p==$c1b) && ($c1p==$c1c) && ($c1p == $c1s) && ($c1p==$c1ka) && ($c1p==$c1t) && ($c1p==$c1r) && ($c1p==$c1set)){
    $c1padi = 33.3; $c1padisth = 33.3; $c1padisrl = 33.3; $c1sawit = 33.3; $c1rumput = 33.3;
    $c1jagung = 33.3; $c1padigogo = 33.3; $c1bawang = 33.3; $c1kakao = 33.3; $c1setaria = 33.3;
    $c1kedelai = 33.3; $c1padisrps = 33.3; $c1cabai = 33.3; $c1tebu = 33.3;
}else if(($c1p == $nn) && ($c1p==$c1j) && ($c1p==$c1k) && ($c1p == $c1psth) && ($c1p==$c1pgogo) && ($c1p==$c1psrps) && ($c1p == $c1psrl) && ($c1p==$c1b) && ($c1p==$c1c) && ($c1p == $c1s) && ($c1p==$c1ka) && ($c1p==$c1t) && ($c1p==$c1r) && ($c1p==$c1set)){
    $c1padi = 0; $c1padisth = 0; $c1padisrl = 0; $c1sawit = 0; $c1rumput = 0;
    $c1jagung = 0; $c1padigogo = 0; $c1bawang = 0; $c1kakao = 0; $c1setaria = 0;
    $c1kedelai = 0; $c1padisrps = 0; $c1cabai = 0; $c1tebu = 0;
}else {
    $c1padi = ($c1p-$minc1)/($maxc1-$minc1)*100; $c1padisth = ($c1psth-$minc1)/($maxc1-$minc1)*100; $c1padisrl = ($c1psrl-$minc1)/($maxc1-$minc1)*100; $c1sawit = ($c1s-$minc1)/($maxc1-$minc1)*100; $c1rumput = ($c1r-$minc1)/($maxc1-$minc1)*100;
    $c1jagung = ($c1j-$minc1)/($maxc1-$minc1)*100; $c1padigogo = ($c1pgogo-$minc1)/($maxc1-$minc1)*100; $c1bawang = ($c1b-$minc1)/($maxc1-$minc1)*100; $c1kakao = ($c1ka-$minc1)/($maxc1-$minc1)*100; $c1setaria = ($c1set-$minc1)/($maxc1-$minc1)*100;
    $c1kedelai = ($c1k-$minc1)/($maxc1-$minc1)*100; $c1padisrps = ($c1psrps-$minc1)/($maxc1-$minc1)*100; $c1cabai = ($c1c-$minc1)/($maxc1-$minc1)*100; $c1tebu = ($c1t-$minc1)/($maxc1-$minc1)*100;
}

//C2
if(($c2p == $s1n) && ($c2p==$c2j) && ($c2p==$c2k) && ($c2p == $c2psth) && ($c2p==$c2pgogo) && ($c2p==$c2psrps) && ($c2p == $c2psrl) && ($c2p==$c2b) && ($c2p==$c2c) && ($c2p == $c2s) && ($c2p==$c2ka) && ($c2p==$c2t) && ($c2p==$c2r) && ($c2p==$c2set)){
    $c2padi = 100; $c2padisth = 100; $c2padisrl = 100; $c2sawit = 100; $c2rumput = 100;
    $c2jagung = 100; $c2padigogo = 100; $c2bawang = 100; $c2kakao = 100; $c2setaria = 100;
    $c2kedelai = 100; $c2padisrps = 100; $c2cabai = 100; $c2tebu = 100;
}else if(($c2p == $s2n) && ($c2p==$c2j) && ($c2p==$c2k) && ($c2p == $c2psth) && ($c2p==$c2pgogo) && ($c2p==$c2psrps) && ($c2p == $c2psrl) && ($c2p==$c2b) && ($c2p==$c2c) && ($c2p == $c2s) && ($c2p==$c2ka) && ($c2p==$c2t) && ($c2p==$c2r) && ($c2p==$c2set)){
    $c2padi = 66.6; $c2padisth = 66.6; $c2padisrl = 66.6; $c2sawit = 66.6; $c2rumput = 66.6;
    $c2jagung = 66.6; $c2padigogo = 66.6; $c2bawang = 66.6; $c2kakao = 66.6; $c2setaria = 66.6;
    $c2kedelai = 66.6; $c2padisrps = 66.6; $c2cabai = 66.6; $c2tebu = 66.6;
}else if(($c2p == $s3n) && ($c2p==$c2j) && ($c2p==$c2k) && ($c2p == $c2psth) && ($c2p==$c2pgogo) && ($c2p==$c2psrps) && ($c2p == $c2psrl) && ($c2p==$c2b) && ($c2p==$c2c) && ($c2p == $c2s) && ($c2p==$c2ka) && ($c2p==$c2t) && ($c2p==$c2r) && ($c2p==$c2set)){
    $c2padi = 33.3; $c2padisth = 33.3; $c2padisrl = 33.3; $c2sawit = 33.3; $c2rumput = 33.3;
    $c2jagung = 33.3; $c2padigogo = 33.3; $c2bawang = 33.3; $c2kakao = 33.3; $c2setaria = 33.3;
    $c2kedelai = 33.3; $c2padisrps = 33.3; $c2cabai = 33.3; $c2tebu = 33.3;
}else if(($c2p == $nn) && ($c2p==$c2j) && ($c2p==$c2k) && ($c2p == $c2psth) && ($c2p==$c2pgogo) && ($c2p==$c2psrps) && ($c2p == $c2psrl) && ($c2p==$c2b) && ($c2p==$c2c) && ($c2p == $c2s) && ($c2p==$c2ka) && ($c2p==$c2t) && ($c2p==$c2r) && ($c2p==$c2set)){
    $c2padi = 0; $c2padisth = 0; $c2padisrl = 0; $c2sawit = 0; $c2rumput = 0;
    $c2jagung = 0; $c2padigogo = 0; $c2bawang = 0; $c2kakao = 0; $c2setaria = 0;
    $c2kedelai = 0; $c2padisrps = 0; $c2cabai = 0; $c2tebu = 0;
}else {
    $c2padi = ($c2p-$minc2)/($maxc2-$minc2)*100; $c2padisth = ($c2psth-$minc2)/($maxc2-$minc2)*100; $c2padisrl = ($c2psrl-$minc2)/($maxc2-$minc2)*100; $c2sawit = ($c2s-$minc2)/($maxc2-$minc2)*100; $c2rumput = ($c2r-$minc2)/($maxc2-$minc2)*100;
    $c2jagung = ($c2j-$minc2)/($maxc2-$minc2)*100; $c2padigogo = ($c2pgogo-$minc2)/($maxc2-$minc2)*100; $c2bawang = ($c2b-$minc2)/($maxc2-$minc2)*100; $c2kakao = ($c2ka-$minc2)/($maxc2-$minc2)*100; $c2setaria = ($c2set-$minc2)/($maxc2-$minc2)*100;
    $c2kedelai = ($c2k-$minc2)/($maxc2-$minc2)*100; $c2padisrps = ($c2psrps-$minc2)/($maxc2-$minc2)*100; $c2cabai = ($c2c-$minc2)/($maxc2-$minc2)*100; $c2tebu = ($c2t-$minc2)/($maxc2-$minc2)*100;
}

//C3
if(($c3p == $s1n) && ($c3p==$c3j) && ($c3p==$c3k) && ($c3p == $c3psth) && ($c3p==$c3pgogo) && ($c3p==$c3psrps) && ($c3p == $c3psrl) && ($c3p==$c3b) && ($c3p==$c3c) && ($c3p == $c3s) && ($c3p==$c3ka) && ($c3p==$c3t) && ($c3p==$c3r) && ($c3p==$c3set)){
    $c3padi = 100; $c3padisth = 100; $c3padisrl = 100; $c3sawit = 100; $c3rumput = 100;
    $c3jagung = 100; $c3padigogo = 100; $c3bawang = 100; $c3kakao = 100; $c3setaria = 100;
    $c3kedelai = 100; $c3padisrps = 100; $c3cabai = 100; $c3tebu = 100;
}else if(($c3p == $s2n) && ($c3p==$c3j) && ($c3p==$c3k) && ($c3p == $c3psth) && ($c3p==$c3pgogo) && ($c3p==$c3psrps) && ($c3p == $c3psrl) && ($c3p==$c3b) && ($c3p==$c3c) && ($c3p == $c3s) && ($c3p==$c3ka) && ($c3p==$c3t) && ($c3p==$c3r) && ($c3p==$c3set)){
    $c3padi = 66.6; $c3padisth = 66.6; $c3padisrl = 66.6; $c3sawit = 66.6; $c3rumput = 66.6;
    $c3jagung = 66.6; $c3padigogo = 66.6; $c3bawang = 66.6; $c3kakao = 66.6; $c3setaria = 66.6;
    $c3kedelai = 66.6; $c3padisrps = 66.6; $c3cabai = 66.6; $c3tebu = 66.6;
}else if(($c3p == $s3n) && ($c3p==$c3j) && ($c3p==$c3k) && ($c3p == $c3psth) && ($c3p==$c3pgogo) && ($c3p==$c3psrps) && ($c3p == $c3psrl) && ($c3p==$c3b) && ($c3p==$c3c) && ($c3p == $c3s) && ($c3p==$c3ka) && ($c3p==$c3t) && ($c3p==$c3r) && ($c3p==$c3set)){
    $c3padi = 33.3; $c3padisth = 33.3; $c3padisrl = 33.3; $c3sawit = 33.3; $c3rumput = 33.3;
    $c3jagung = 33.3; $c3padigogo = 33.3; $c3bawang = 33.3; $c3kakao = 33.3; $c3setaria = 33.3;
    $c3kedelai = 33.3; $c3padisrps = 33.3; $c3cabai = 33.3; $c3tebu = 33.3;
}else if(($c3p == $nn) && ($c3p==$c3j) && ($c3p==$c3k) && ($c3p == $c3psth) && ($c3p==$c3pgogo) && ($c3p==$c3psrps) && ($c3p == $c3psrl) && ($c3p==$c3b) && ($c3p==$c3c) && ($c3p == $c3s) && ($c3p==$c3ka) && ($c3p==$c3t) && ($c3p==$c3r) && ($c3p==$c3set)){
    $c3padi = 0; $c3padisth = 0; $c3padisrl = 0; $c3sawit = 0; $c3rumput = 0;
    $c3jagung = 0; $c3padigogo = 0; $c3bawang = 0; $c3kakao = 0; $c3setaria = 0;
    $c3kedelai = 0; $c3padisrps = 0; $c3cabai = 0; $c3tebu = 0;
}else {
    $c3padi = ($c3p-$minc3)/($maxc3-$minc3)*100; $c3padisth = ($c3psth-$minc3)/($maxc3-$minc3)*100; $c3padisrl = ($c3psrl-$minc3)/($maxc3-$minc3)*100; $c3sawit = ($c3s-$minc3)/($maxc3-$minc3)*100; $c3rumput = ($c3r-$minc3)/($maxc3-$minc3)*100;
    $c3jagung = ($c3j-$minc3)/($maxc3-$minc3)*100; $c3padigogo = ($c3pgogo-$minc3)/($maxc3-$minc3)*100; $c3bawang = ($c3b-$minc3)/($maxc3-$minc3)*100; $c3kakao = ($c3ka-$minc3)/($maxc3-$minc3)*100; $c3setaria = ($c3set-$minc3)/($maxc3-$minc3)*100;
    $c3kedelai = ($c3k-$minc3)/($maxc3-$minc3)*100; $c3padisrps = ($c3psrps-$minc3)/($maxc3-$minc3)*100; $c3cabai = ($c3c-$minc3)/($maxc3-$minc3)*100; $c3tebu = ($c3t-$minc3)/($maxc3-$minc3)*100;
}

//C4
if(($c4p == $s1n) && ($c4p==$c4j) && ($c4p==$c4k) && ($c4p == $c4psth) && ($c4p==$c4pgogo) && ($c4p==$c4psrps) && ($c4p == $c4psrl) && ($c4p==$c4b) && ($c4p==$c4c) && ($c4p == $c4s) && ($c4p==$c4ka) && ($c4p==$c4t) && ($c4p==$c4r) && ($c4p==$c4set)){
    $c4padi = 100; $c4padisth = 100; $c4padisrl = 100; $c4sawit = 100; $c4rumput = 100;
    $c4jagung = 100; $c4padigogo = 100; $c4bawang = 100; $c4kakao = 100; $c4setaria = 100;
    $c4kedelai = 100; $c4padisrps = 100; $c4cabai = 100; $c4tebu = 100;
}else if(($c4p == $s2n) && ($c4p==$c4j) && ($c4p==$c4k) && ($c4p == $c4psth) && ($c4p==$c4pgogo) && ($c4p==$c4psrps) && ($c4p == $c4psrl) && ($c4p==$c4b) && ($c4p==$c4c) && ($c4p == $c4s) && ($c4p==$c4ka) && ($c4p==$c4t) && ($c4p==$c4r) && ($c4p==$c4set)){
    $c4padi = 66.6; $c4padisth = 66.6; $c4padisrl = 66.6; $c4sawit = 66.6; $c4rumput = 66.6;
    $c4jagung = 66.6; $c4padigogo = 66.6; $c4bawang = 66.6; $c4kakao = 66.6; $c4setaria = 66.6;
    $c4kedelai = 66.6; $c4padisrps = 66.6; $c4cabai = 66.6; $c4tebu = 66.6;
}else if(($c4p == $s3n) && ($c4p==$c4j) && ($c4p==$c4k) && ($c4p == $c4psth) && ($c4p==$c4pgogo) && ($c4p==$c4psrps) && ($c4p == $c4psrl) && ($c4p==$c4b) && ($c4p==$c4c) && ($c4p == $c4s) && ($c4p==$c4ka) && ($c4p==$c4t) && ($c4p==$c4r) && ($c4p==$c4set)){
    $c4padi = 33.3; $c4padisth = 33.3; $c4padisrl = 33.3; $c4sawit = 33.3; $c4rumput = 33.3;
    $c4jagung = 33.3; $c4padigogo = 33.3; $c4bawang = 33.3; $c4kakao = 33.3; $c4setaria = 33.3;
    $c4kedelai = 33.3; $c4padisrps = 33.3; $c4cabai = 33.3; $c4tebu = 33.3;
}else if(($c4p == $nn) && ($c4p==$c4j) && ($c4p==$c4k) && ($c4p == $c4psth) && ($c4p==$c4pgogo) && ($c4p==$c4psrps) && ($c4p == $c4psrl) && ($c4p==$c4b) && ($c4p==$c4c) && ($c4p == $c4s) && ($c4p==$c4ka) && ($c4p==$c4t) && ($c4p==$c4r) && ($c4p==$c4set)){
    $c4padi = 0; $c4padisth = 0; $c4padisrl = 0; $c4sawit = 0; $c4rumput = 0;
    $c4jagung = 0; $c4padigogo = 0; $c4bawang = 0; $c4kakao = 0; $c4setaria = 0;
    $c4kedelai = 0; $c4padisrps = 0; $c4cabai = 0; $c4tebu = 0;
}else {
    $c4padi = ($c4p-$minc4)/($maxc4-$minc4)*100; $c4padisth = ($c4psth-$minc4)/($maxc4-$minc4)*100; $c4padisrl = ($c4psrl-$minc4)/($maxc4-$minc4)*100; $c4sawit = ($c4s-$minc4)/($maxc4-$minc4)*100; $c4rumput = ($c4r-$minc4)/($maxc4-$minc4)*100;
    $c4jagung = ($c4j-$minc4)/($maxc4-$minc4)*100; $c4padigogo = ($c4pgogo-$minc4)/($maxc4-$minc4)*100; $c4bawang = ($c4b-$minc4)/($maxc4-$minc4)*100; $c4kakao = ($c4ka-$minc4)/($maxc4-$minc4)*100; $c4setaria = ($c4set-$minc4)/($maxc4-$minc4)*100;
    $c4kedelai = ($c4k-$minc4)/($maxc4-$minc4)*100; $c4padisrps = ($c4psrps-$minc4)/($maxc4-$minc4)*100; $c4cabai = ($c4c-$minc4)/($maxc4-$minc4)*100; $c4tebu = ($c4t-$minc4)/($maxc4-$minc4)*100;
}

//C5
if(($c5p == $s1n) && ($c5p==$c5j) && ($c5p==$c5k) && ($c5p == $c5psth) && ($c5p==$c5pgogo) && ($c5p==$c5psrps) && ($c5p == $c5psrl) && ($c5p==$c5b) && ($c5p==$c5c) && ($c5p == $c5s) && ($c5p==$c5ka) && ($c5p==$c5t) && ($c5p==$c5r) && ($c5p==$c5set)){
    $c5padi = 100; $c5padisth = 100; $c5padisrl = 100; $c5sawit = 100; $c5rumput = 100;
    $c5jagung = 100; $c5padigogo = 100; $c5bawang = 100; $c5kakao = 100; $c5setaria = 100;
    $c5kedelai = 100; $c5padisrps = 100; $c5cabai = 100; $c5tebu = 100;
}else if(($c5p == $s2n) && ($c5p==$c5j) && ($c5p==$c5k) && ($c5p == $c5psth) && ($c5p==$c5pgogo) && ($c5p==$c5psrps) && ($c5p == $c5psrl) && ($c5p==$c5b) && ($c5p==$c5c) && ($c5p == $c5s) && ($c5p==$c5ka) && ($c5p==$c5t) && ($c5p==$c5r) && ($c5p==$c5set)){
    $c5padi = 66.6; $c5padisth = 66.6; $c5padisrl = 66.6; $c5sawit = 66.6; $c5rumput = 66.6;
    $c5jagung = 66.6; $c5padigogo = 66.6; $c5bawang = 66.6; $c5kakao = 66.6; $c5setaria = 66.6;
    $c5kedelai = 66.6; $c5padisrps = 66.6; $c5cabai = 66.6; $c5tebu = 66.6;
}else if(($c5p == $s3n) && ($c5p==$c5j) && ($c5p==$c5k) && ($c5p == $c5psth) && ($c5p==$c5pgogo) && ($c5p==$c5psrps) && ($c5p == $c5psrl) && ($c5p==$c5b) && ($c5p==$c5c) && ($c5p == $c5s) && ($c5p==$c5ka) && ($c5p==$c5t) && ($c5p==$c5r) && ($c5p==$c5set)){
    $c5padi = 33.3; $c5padisth = 33.3; $c5padisrl = 33.3; $c5sawit = 33.3; $c5rumput = 33.3;
    $c5jagung = 33.3; $c5padigogo = 33.3; $c5bawang = 33.3; $c5kakao = 33.3; $c5setaria = 33.3;
    $c5kedelai = 33.3; $c5padisrps = 33.3; $c5cabai = 33.3; $c5tebu = 33.3;
}else if(($c5p == $nn) && ($c5p==$c5j) && ($c5p==$c5k) && ($c5p == $c5psth) && ($c5p==$c5pgogo) && ($c5p==$c5psrps) && ($c5p == $c5psrl) && ($c5p==$c5b) && ($c5p==$c5c) && ($c5p == $c5s) && ($c5p==$c5ka) && ($c5p==$c5t) && ($c5p==$c5r) && ($c5p==$c5set)){
    $c5padi = 0; $c5padisth = 0; $c5padisrl = 0; $c5sawit = 0; $c5rumput = 0;
    $c5jagung = 0; $c5padigogo = 0; $c5bawang = 0; $c5kakao = 0; $c5setaria = 0;
    $c5kedelai = 0; $c5padisrps = 0; $c5cabai = 0; $c5tebu = 0;
}else {
    $c5padi = ($c5p-$minc5)/($maxc5-$minc5)*100; $c5padisth = ($c5psth-$minc5)/($maxc5-$minc5)*100; $c5padisrl = ($c5psrl-$minc5)/($maxc5-$minc5)*100; $c5sawit = ($c5s-$minc5)/($maxc5-$minc5)*100; $c5rumput = ($c5r-$minc5)/($maxc5-$minc5)*100;
    $c5jagung = ($c5j-$minc5)/($maxc5-$minc5)*100; $c5padigogo = ($c5pgogo-$minc5)/($maxc5-$minc5)*100; $c5bawang = ($c5b-$minc5)/($maxc5-$minc5)*100; $c5kakao = ($c5ka-$minc5)/($maxc5-$minc5)*100; $c5setaria = ($c5set-$minc5)/($maxc5-$minc5)*100;
    $c5kedelai = ($c5k-$minc5)/($maxc5-$minc5)*100; $c5padisrps = ($c5psrps-$minc5)/($maxc5-$minc5)*100; $c5cabai = ($c5c-$minc5)/($maxc5-$minc5)*100; $c5tebu = ($c5t-$minc5)/($maxc5-$minc5)*100;
}

//C6
if(($c6p == $s1n) && ($c6p==$c6j) && ($c6p==$c6k) && ($c6p == $c6psth) && ($c6p==$c6pgogo) && ($c6p==$c6psrps) && ($c6p == $c6psrl) && ($c6p==$c6b) && ($c6p==$c6c) && ($c6p == $c6s) && ($c6p==$c6ka) && ($c6p==$c6t) && ($c6p==$c6r) && ($c6p==$c6set)){
    $c6padi = 100; $c6padisth = 100; $c6padisrl = 100; $c6sawit = 100; $c6rumput = 100;
    $c6jagung = 100; $c6padigogo = 100; $c6bawang = 100; $c6kakao = 100; $c6setaria = 100;
    $c6kedelai = 100; $c6padisrps = 100; $c6cabai = 100; $c6tebu = 100;
}else if(($c6p == $s2n) && ($c6p==$c6j) && ($c6p==$c6k) && ($c6p == $c6psth) && ($c6p==$c6pgogo) && ($c6p==$c6psrps) && ($c6p == $c6psrl) && ($c6p==$c6b) && ($c6p==$c6c) && ($c6p == $c6s) && ($c6p==$c6ka) && ($c6p==$c6t) && ($c6p==$c6r) && ($c6p==$c6set)){
    $c6padi = 66.6; $c6padisth = 66.6; $c6padisrl = 66.6; $c6sawit = 66.6; $c6rumput = 66.6;
    $c6jagung = 66.6; $c6padigogo = 66.6; $c6bawang = 66.6; $c6kakao = 66.6; $c6setaria = 66.6;
    $c6kedelai = 66.6; $c6padisrps = 66.6; $c6cabai = 66.6; $c6tebu = 66.6;
}else if(($c6p == $s3n) && ($c6p==$c6j) && ($c6p==$c6k) && ($c6p == $c6psth) && ($c6p==$c6pgogo) && ($c6p==$c6psrps) && ($c6p == $c6psrl) && ($c6p==$c6b) && ($c6p==$c6c) && ($c6p == $c6s) && ($c6p==$c6ka) && ($c6p==$c6t) && ($c6p==$c6r) && ($c6p==$c6set)){
    $c6padi = 33.3; $c6padisth = 33.3; $c6padisrl = 33.3; $c6sawit = 33.3; $c6rumput = 33.3;
    $c6jagung = 33.3; $c6padigogo = 33.3; $c6bawang = 33.3; $c6kakao = 33.3; $c6setaria = 33.3;
    $c6kedelai = 33.3; $c6padisrps = 33.3; $c6cabai = 33.3; $c6tebu = 33.3;
}else if(($c6p == $nn) && ($c6p==$c6j) && ($c6p==$c6k) && ($c6p == $c6psth) && ($c6p==$c6pgogo) && ($c6p==$c6psrps) && ($c6p == $c6psrl) && ($c6p==$c6b) && ($c6p==$c6c) && ($c6p == $c6s) && ($c6p==$c6ka) && ($c6p==$c6t) && ($c6p==$c6r) && ($c6p==$c6set)){
    $c6padi = 0; $c6padisth = 0; $c6padisrl = 0; $c6sawit = 0; $c6rumput = 0;
    $c6jagung = 0; $c6padigogo = 0; $c6bawang = 0; $c6kakao = 0; $c6setaria = 0;
    $c6kedelai = 0; $c6padisrps = 0; $c6cabai = 0; $c6tebu = 0;
}else {
    $c6padi = ($c6p-$minc6)/($maxc6-$minc6)*100; $c6padisth = ($c6psth-$minc6)/($maxc6-$minc6)*100; $c6padisrl = ($c6psrl-$minc6)/($maxc6-$minc6)*100; $c6sawit = ($c6s-$minc6)/($maxc6-$minc6)*100; $c6rumput = ($c6r-$minc6)/($maxc6-$minc6)*100;
    $c6jagung = ($c6j-$minc6)/($maxc6-$minc6)*100; $c6padigogo = ($c6pgogo-$minc6)/($maxc6-$minc6)*100; $c6bawang = ($c6b-$minc6)/($maxc6-$minc6)*100; $c6kakao = ($c6ka-$minc6)/($maxc6-$minc6)*100; $c6setaria = ($c6set-$minc6)/($maxc6-$minc6)*100;
    $c6kedelai = ($c6k-$minc6)/($maxc6-$minc6)*100; $c6padisrps = ($c6psrps-$minc6)/($maxc6-$minc6)*100; $c6cabai = ($c6c-$minc6)/($maxc6-$minc6)*100; $c6tebu = ($c6t-$minc6)/($maxc6-$minc6)*100;
}

//C7
if(($c7p == $s1n) && ($c7p==$c7j) && ($c7p==$c7k) && ($c7p == $c7psth) && ($c7p==$c7pgogo) && ($c7p==$c7psrps) && ($c7p == $c7psrl) && ($c7p==$c7b) && ($c7p==$c7c) && ($c7p == $c7s) && ($c7p==$c7ka) && ($c7p==$c7t) && ($c7p==$c7r) && ($c7p==$c7set)){
    $c7padi = 100; $c7padisth = 100; $c7padisrl = 100; $c7sawit = 100; $c7rumput = 100;
    $c7jagung = 100; $c7padigogo = 100; $c7bawang = 100; $c7kakao = 100; $c7setaria = 100;
    $c7kedelai = 100; $c7padisrps = 100; $c7cabai = 100; $c7tebu = 100;
}else if(($c7p == $s2n) && ($c7p==$c7j) && ($c7p==$c7k) && ($c7p == $c7psth) && ($c7p==$c7pgogo) && ($c7p==$c7psrps) && ($c7p == $c7psrl) && ($c7p==$c7b) && ($c7p==$c7c) && ($c7p == $c7s) && ($c7p==$c7ka) && ($c7p==$c7t) && ($c7p==$c7r) && ($c7p==$c7set)){
    $c7padi = 66.6; $c7padisth = 66.6; $c7padisrl = 66.6; $c7sawit = 66.6; $c7rumput = 66.6;
    $c7jagung = 66.6; $c7padigogo = 66.6; $c7bawang = 66.6; $c7kakao = 66.6; $c7setaria = 66.6;
    $c7kedelai = 66.6; $c7padisrps = 66.6; $c7cabai = 66.6; $c7tebu = 66.6;
}else if(($c7p == $s3n) && ($c7p==$c7j) && ($c7p==$c7k) && ($c7p == $c7psth) && ($c7p==$c7pgogo) && ($c7p==$c7psrps) && ($c7p == $c7psrl) && ($c7p==$c7b) && ($c7p==$c7c) && ($c7p == $c7s) && ($c7p==$c7ka) && ($c7p==$c7t) && ($c7p==$c7r) && ($c7p==$c7set)){
    $c7padi = 33.3; $c7padisth = 33.3; $c7padisrl = 33.3; $c7sawit = 33.3; $c7rumput = 33.3;
    $c7jagung = 33.3; $c7padigogo = 33.3; $c7bawang = 33.3; $c7kakao = 33.3; $c7setaria = 33.3;
    $c7kedelai = 33.3; $c7padisrps = 33.3; $c7cabai = 33.3; $c7tebu = 33.3;
}else if(($c7p == $nn) && ($c7p==$c7j) && ($c7p==$c7k) && ($c7p == $c7psth) && ($c7p==$c7pgogo) && ($c7p==$c7psrps) && ($c7p == $c7psrl) && ($c7p==$c7b) && ($c7p==$c7c) && ($c7p == $c7s) && ($c7p==$c7ka) && ($c7p==$c7t) && ($c7p==$c7r) && ($c7p==$c7set)){
    $c7padi = 0; $c7padisth = 0; $c7padisrl = 0; $c7sawit = 0; $c7rumput = 0;
    $c7jagung = 0; $c7padigogo = 0; $c7bawang = 0; $c7kakao = 0; $c7setaria = 0;
    $c7kedelai = 0; $c7padisrps = 0; $c7cabai = 0; $c7tebu = 0;
}else {
    $c7padi = ($c7p-$minc7)/($maxc7-$minc7)*100; $c7padisth = ($c7psth-$minc7)/($maxc7-$minc7)*100; $c7padisrl = ($c7psrl-$minc7)/($maxc7-$minc7)*100; $c7sawit = ($c7s-$minc7)/($maxc7-$minc7)*100; $c7rumput = ($c7r-$minc7)/($maxc7-$minc7)*100;
    $c7jagung = ($c7j-$minc7)/($maxc7-$minc7)*100; $c7padigogo = ($c7pgogo-$minc7)/($maxc7-$minc7)*100; $c7bawang = ($c7b-$minc7)/($maxc7-$minc7)*100; $c7kakao = ($c7ka-$minc7)/($maxc7-$minc7)*100; $c7setaria = ($c7set-$minc7)/($maxc7-$minc7)*100;
    $c7kedelai = ($c7k-$minc7)/($maxc7-$minc7)*100; $c7padisrps = ($c7psrps-$minc7)/($maxc7-$minc7)*100; $c7cabai = ($c7c-$minc7)/($maxc7-$minc7)*100; $c7tebu = ($c7t-$minc7)/($maxc7-$minc7)*100;
}

//C8
if(($c8p == $s1n) && ($c8p==$c8j) && ($c8p==$c8k) && ($c8p == $c8psth) && ($c8p==$c8pgogo) && ($c8p==$c8psrps) && ($c8p == $c8psrl) && ($c8p==$c8b) && ($c8p==$c8c) && ($c8p == $c8s) && ($c8p==$c8ka) && ($c8p==$c8t) && ($c8p==$c8r) && ($c8p==$c8set)){
    $c8padi = 100; $c8padisth = 100; $c8padisrl = 100; $c8sawit = 100; $c8rumput = 100;
    $c8jagung = 100; $c8padigogo = 100; $c8bawang = 100; $c8kakao = 100; $c8setaria = 100;
    $c8kedelai = 100; $c8padisrps = 100; $c8cabai = 100; $c8tebu = 100;
}else if(($c8p == $s2n) && ($c8p==$c8j) && ($c8p==$c8k) && ($c8p == $c8psth) && ($c8p==$c8pgogo) && ($c8p==$c8psrps) && ($c8p == $c8psrl) && ($c8p==$c8b) && ($c8p==$c8c) && ($c8p == $c8s) && ($c8p==$c8ka) && ($c8p==$c8t) && ($c8p==$c8r) && ($c8p==$c8set)){
    $c8padi = 66.6; $c8padisth = 66.6; $c8padisrl = 66.6; $c8sawit = 66.6; $c8rumput = 66.6;
    $c8jagung = 66.6; $c8padigogo = 66.6; $c8bawang = 66.6; $c8kakao = 66.6; $c8setaria = 66.6;
    $c8kedelai = 66.6; $c8padisrps = 66.6; $c8cabai = 66.6; $c8tebu = 66.6;
}else if(($c8p == $s3n) && ($c8p==$c8j) && ($c8p==$c8k) && ($c8p == $c8psth) && ($c8p==$c8pgogo) && ($c8p==$c8psrps) && ($c8p == $c8psrl) && ($c8p==$c8b) && ($c8p==$c8c) && ($c8p == $c8s) && ($c8p==$c8ka) && ($c8p==$c8t) && ($c8p==$c8r) && ($c8p==$c8set)){
    $c8padi = 33.3; $c8padisth = 33.3; $c8padisrl = 33.3; $c8sawit = 33.3; $c8rumput = 33.3;
    $c8jagung = 33.3; $c8padigogo = 33.3; $c8bawang = 33.3; $c8kakao = 33.3; $c8setaria = 33.3;
    $c8kedelai = 33.3; $c8padisrps = 33.3; $c8cabai = 33.3; $c8tebu = 33.3;
}else if(($c8p == $nn) && ($c8p==$c8j) && ($c8p==$c8k) && ($c8p == $c8psth) && ($c8p==$c8pgogo) && ($c8p==$c8psrps) && ($c8p == $c8psrl) && ($c8p==$c8b) && ($c8p==$c8c) && ($c8p == $c8s) && ($c8p==$c8ka) && ($c8p==$c8t) && ($c8p==$c8r) && ($c8p==$c8set)){
    $c8padi = 0; $c8padisth = 0; $c8padisrl = 0; $c8sawit = 0; $c8rumput = 0;
    $c8jagung = 0; $c8padigogo = 0; $c8bawang = 0; $c8kakao = 0; $c8setaria = 0;
    $c8kedelai = 0; $c8padisrps = 0; $c8cabai = 0; $c8tebu = 0;
}else {
    $c8padi = ($c8p-$minc8)/($maxc8-$minc8)*100; $c8padisth = ($c8psth-$minc8)/($maxc8-$minc8)*100; $c8padisrl = ($c8psrl-$minc8)/($maxc8-$minc8)*100; $c8sawit = ($c8s-$minc8)/($maxc8-$minc8)*100; $c8rumput = ($c8r-$minc8)/($maxc8-$minc8)*100;
    $c8jagung = ($c8j-$minc8)/($maxc8-$minc8)*100; $c8padigogo = ($c8pgogo-$minc8)/($maxc8-$minc8)*100; $c8bawang = ($c8b-$minc8)/($maxc8-$minc8)*100; $c8kakao = ($c8ka-$minc8)/($maxc8-$minc8)*100; $c8setaria = ($c8set-$minc8)/($maxc8-$minc8)*100;
    $c8kedelai = ($c8k-$minc8)/($maxc8-$minc8)*100; $c8padisrps = ($c8psrps-$minc8)/($maxc8-$minc8)*100; $c8cabai = ($c8c-$minc8)/($maxc8-$minc8)*100; $c8tebu = ($c8t-$minc8)/($maxc8-$minc8)*100;
}

//C9
if(($c9p == $s1n) && ($c9p==$c9j) && ($c9p==$c9k) && ($c9p == $c9psth) && ($c9p==$c9pgogo) && ($c9p==$c9psrps) && ($c9p == $c9psrl) && ($c9p==$c9b) && ($c9p==$c9c) && ($c9p == $c9s) && ($c9p==$c9ka) && ($c9p==$c9t) && ($c9p==$c9r) && ($c9p==$c9set)){
    $c9padi = 100; $c9padisth = 100; $c9padisrl = 100; $c9sawit = 100; $c9rumput = 100;
    $c9jagung = 100; $c9padigogo = 100; $c9bawang = 100; $c9kakao = 100; $c9setaria = 100;
    $c9kedelai = 100; $c9padisrps = 100; $c9cabai = 100; $c9tebu = 100;
}else if(($c9p == $s2n) && ($c9p==$c9j) && ($c9p==$c9k) && ($c9p == $c9psth) && ($c9p==$c9pgogo) && ($c9p==$c9psrps) && ($c9p == $c9psrl) && ($c9p==$c9b) && ($c9p==$c9c) && ($c9p == $c9s) && ($c9p==$c9ka) && ($c9p==$c9t) && ($c9p==$c9r) && ($c9p==$c9set)){
    $c9padi = 66.6; $c9padisth = 66.6; $c9padisrl = 66.6; $c9sawit = 66.6; $c9rumput = 66.6;
    $c9jagung = 66.6; $c9padigogo = 66.6; $c9bawang = 66.6; $c9kakao = 66.6; $c9setaria = 66.6;
    $c9kedelai = 66.6; $c9padisrps = 66.6; $c9cabai = 66.6; $c9tebu = 66.6;
}else if(($c9p == $s3n) && ($c9p==$c9j) && ($c9p==$c9k) && ($c9p == $c9psth) && ($c9p==$c9pgogo) && ($c9p==$c9psrps) && ($c9p == $c9psrl) && ($c9p==$c9b) && ($c9p==$c9c) && ($c9p == $c9s) && ($c9p==$c9ka) && ($c9p==$c9t) && ($c9p==$c9r) && ($c9p==$c9set)){
    $c9padi = 33.3; $c9padisth = 33.3; $c9padisrl = 33.3; $c9sawit = 33.3; $c9rumput = 33.3;
    $c9jagung = 33.3; $c9padigogo = 33.3; $c9bawang = 33.3; $c9kakao = 33.3; $c9setaria = 33.3;
    $c9kedelai = 33.3; $c9padisrps = 33.3; $c9cabai = 33.3; $c9tebu = 33.3;
}else if(($c9p == $nn) && ($c9p==$c9j) && ($c9p==$c9k) && ($c9p == $c9psth) && ($c9p==$c9pgogo) && ($c9p==$c9psrps) && ($c9p == $c9psrl) && ($c9p==$c9b) && ($c9p==$c9c) && ($c9p == $c9s) && ($c9p==$c9ka) && ($c9p==$c9t) && ($c9p==$c9r) && ($c9p==$c9set)){
    $c9padi = 0; $c9padisth = 0; $c9padisrl = 0; $c9sawit = 0; $c9rumput = 0;
    $c9jagung = 0; $c9padigogo = 0; $c9bawang = 0; $c9kakao = 0; $c9setaria = 0;
    $c9kedelai = 0; $c9padisrps = 0; $c9cabai = 0; $c9tebu = 0;
}else {
    $c9padi = ($c9p-$minc9)/($maxc9-$minc9)*100; $c9padisth = ($c9psth-$minc9)/($maxc9-$minc9)*100; $c9padisrl = ($c9psrl-$minc9)/($maxc9-$minc9)*100; $c9sawit = ($c9s-$minc9)/($maxc9-$minc9)*100; $c9rumput = ($c9r-$minc9)/($maxc9-$minc9)*100;
    $c9jagung = ($c9j-$minc9)/($maxc9-$minc9)*100; $c9padigogo = ($c9pgogo-$minc9)/($maxc9-$minc9)*100; $c9bawang = ($c9b-$minc9)/($maxc9-$minc9)*100; $c9kakao = ($c9ka-$minc9)/($maxc9-$minc9)*100; $c9setaria = ($c9set-$minc9)/($maxc9-$minc9)*100;
    $c9kedelai = ($c9k-$minc9)/($maxc9-$minc9)*100; $c9padisrps = ($c9psrps-$minc9)/($maxc9-$minc9)*100; $c9cabai = ($c9c-$minc9)/($maxc9-$minc9)*100; $c9tebu = ($c9t-$minc9)/($maxc9-$minc9)*100;
}

//C10
if(($c10p == $s1n) && ($c10p==$c10j) && ($c10p==$c10k) && ($c10p == $c10psth) && ($c10p==$c10pgogo) && ($c10p==$c10psrps) && ($c10p == $c10psrl) && ($c10p==$c10b) && ($c10p==$c10c) && ($c10p == $c10s) && ($c10p==$c10ka) && ($c10p==$c10t) && ($c10p==$c10r) && ($c10p==$c10set)){
    $c10padi = 100; $c10padisth = 100; $c10padisrl = 100; $c10sawit = 100; $c10rumput = 100;
    $c10jagung = 100; $c10padigogo = 100; $c10bawang = 100; $c10kakao = 100; $c10setaria = 100;
    $c10kedelai = 100; $c10padisrps = 100; $c10cabai = 100; $c10tebu = 100;
}else if(($c10p == $s2n) && ($c10p==$c10j) && ($c10p==$c10k) && ($c10p == $c10psth) && ($c10p==$c10pgogo) && ($c10p==$c10psrps) && ($c10p == $c10psrl) && ($c10p==$c10b) && ($c10p==$c10c) && ($c10p == $c10s) && ($c10p==$c10ka) && ($c10p==$c10t) && ($c10p==$c10r) && ($c10p==$c10set)){
    $c10padi = 66.6; $c10padisth = 66.6; $c10padisrl = 66.6; $c10sawit = 66.6; $c10rumput = 66.6;
    $c10jagung = 66.6; $c10padigogo = 66.6; $c10bawang = 66.6; $c10kakao = 66.6; $c10setaria = 66.6;
    $c10kedelai = 66.6; $c10padisrps = 66.6; $c10cabai = 66.6; $c10tebu = 66.6;
}else if(($c10p == $s3n) && ($c10p==$c10j) && ($c10p==$c10k) && ($c10p == $c10psth) && ($c10p==$c10pgogo) && ($c10p==$c10psrps) && ($c10p == $c10psrl) && ($c10p==$c10b) && ($c10p==$c10c) && ($c10p == $c10s) && ($c10p==$c10ka) && ($c10p==$c10t) && ($c10p==$c10r) && ($c10p==$c10set)){
    $c10padi = 33.3; $c10padisth = 33.3; $c10padisrl = 33.3; $c10sawit = 33.3; $c10rumput = 33.3;
    $c10jagung = 33.3; $c10padigogo = 33.3; $c10bawang = 33.3; $c10kakao = 33.3; $c10setaria = 33.3;
    $c10kedelai = 33.3; $c10padisrps = 33.3; $c10cabai = 33.3; $c10tebu = 33.3;
}else if(($c10p == $nn) && ($c10p==$c10j) && ($c10p==$c10k) && ($c10p == $c10psth) && ($c10p==$c10pgogo) && ($c10p==$c10psrps) && ($c10p == $c10psrl) && ($c10p==$c10b) && ($c10p==$c10c) && ($c10p == $c10s) && ($c10p==$c10ka) && ($c10p==$c10t) && ($c10p==$c10r) && ($c10p==$c10set)){
    $c10padi = 0; $c10padisth = 0; $c10padisrl = 0; $c10sawit = 0; $c10rumput = 0;
    $c10jagung = 0; $c10padigogo = 0; $c10bawang = 0; $c10kakao = 0; $c10setaria = 0;
    $c10kedelai = 0; $c10padisrps = 0; $c10cabai = 0; $c10tebu = 0;
}else {
    $c10padi = ($c10p-$minc10)/($maxc10-$minc10)*100; $c10padisth = ($c10psth-$minc10)/($maxc10-$minc10)*100; $c10padisrl = ($c10psrl-$minc10)/($maxc10-$minc10)*100; $c10sawit = ($c10s-$minc10)/($maxc10-$minc10)*100; $c10rumput = ($c10r-$minc10)/($maxc10-$minc10)*100;
    $c10jagung = ($c10j-$minc10)/($maxc10-$minc10)*100; $c10padigogo = ($c10pgogo-$minc10)/($maxc10-$minc10)*100; $c10bawang = ($c10b-$minc10)/($maxc10-$minc10)*100; $c10kakao = ($c10ka-$minc10)/($maxc10-$minc10)*100; $c10setaria = ($c10set-$minc10)/($maxc10-$minc10)*100;
    $c10kedelai = ($c10k-$minc10)/($maxc10-$minc10)*100; $c10padisrps = ($c10psrps-$minc10)/($maxc10-$minc10)*100; $c10cabai = ($c10c-$minc10)/($maxc10-$minc10)*100; $c10tebu = ($c10t-$minc10)/($maxc10-$minc10)*100;
}

//C11
if(($c11p == $s1n) && ($c11p==$c11j) && ($c11p==$c11k) && ($c11p == $c11psth) && ($c11p==$c11pgogo) && ($c11p==$c11psrps) && ($c11p == $c11psrl) && ($c11p==$c11b) && ($c11p==$c11c) && ($c11p == $c11s) && ($c11p==$c11ka) && ($c11p==$c11t) && ($c11p==$c11r) && ($c11p==$c11set)){
    $c11padi = 100; $c11padisth = 100; $c11padisrl = 100; $c11sawit = 100; $c11rumput = 100;
    $c11jagung = 100; $c11padigogo = 100; $c11bawang = 100; $c11kakao = 100; $c11setaria = 100;
    $c11kedelai = 100; $c11padisrps = 100; $c11cabai = 100; $c11tebu = 100;
}else if(($c11p == $s2n) && ($c11p==$c11j) && ($c11p==$c11k) && ($c11p == $c11psth) && ($c11p==$c11pgogo) && ($c11p==$c11psrps) && ($c11p == $c11psrl) && ($c11p==$c11b) && ($c11p==$c11c) && ($c11p == $c11s) && ($c11p==$c11ka) && ($c11p==$c11t) && ($c11p==$c11r) && ($c11p==$c11set)){
    $c11padi = 66.6; $c11padisth = 66.6; $c11padisrl = 66.6; $c11sawit = 66.6; $c11rumput = 66.6;
    $c11jagung = 66.6; $c11padigogo = 66.6; $c11bawang = 66.6; $c11kakao = 66.6; $c11setaria = 66.6;
    $c11kedelai = 66.6; $c11padisrps = 66.6; $c11cabai = 66.6; $c11tebu = 66.6;
}else if(($c11p == $s3n) && ($c11p==$c11j) && ($c11p==$c11k) && ($c11p == $c11psth) && ($c11p==$c11pgogo) && ($c11p==$c11psrps) && ($c11p == $c11psrl) && ($c11p==$c11b) && ($c11p==$c11c) && ($c11p == $c11s) && ($c11p==$c11ka) && ($c11p==$c11t) && ($c11p==$c11r) && ($c11p==$c11set)){
    $c11padi = 33.3; $c11padisth = 33.3; $c11padisrl = 33.3; $c11sawit = 33.3; $c11rumput = 33.3;
    $c11jagung = 33.3; $c11padigogo = 33.3; $c11bawang = 33.3; $c11kakao = 33.3; $c11setaria = 33.3;
    $c11kedelai = 33.3; $c11padisrps = 33.3; $c11cabai = 33.3; $c11tebu = 33.3;
}else if(($c11p == $nn) && ($c11p==$c11j) && ($c11p==$c11k) && ($c11p == $c11psth) && ($c11p==$c11pgogo) && ($c11p==$c11psrps) && ($c11p == $c11psrl) && ($c11p==$c11b) && ($c11p==$c11c) && ($c11p == $c11s) && ($c11p==$c11ka) && ($c11p==$c11t) && ($c11p==$c11r) && ($c11p==$c11set)){
    $c11padi = 0; $c11padisth = 0; $c11padisrl = 0; $c11sawit = 0; $c11rumput = 0;
    $c11jagung = 0; $c11padigogo = 0; $c11bawang = 0; $c11kakao = 0; $c11setaria = 0;
    $c11kedelai = 0; $c11padisrps = 0; $c11cabai = 0; $c11tebu = 0;
}else {
    $c11padi = ($c11p-$minc11)/($maxc11-$minc11)*100; $c11padisth = ($c11psth-$minc11)/($maxc11-$minc11)*100; $c11padisrl = ($c11psrl-$minc11)/($maxc11-$minc11)*100; $c11sawit = ($c11s-$minc11)/($maxc11-$minc11)*100; $c11rumput = ($c11r-$minc11)/($maxc11-$minc11)*100;
    $c11jagung = ($c11j-$minc11)/($maxc11-$minc11)*100; $c11padigogo = ($c11pgogo-$minc11)/($maxc11-$minc11)*100; $c11bawang = ($c11b-$minc11)/($maxc11-$minc11)*100; $c11kakao = ($c11ka-$minc11)/($maxc11-$minc11)*100; $c11setaria = ($c11set-$minc11)/($maxc11-$minc11)*100;
    $c11kedelai = ($c11k-$minc11)/($maxc11-$minc11)*100; $c11padisrps = ($c11psrps-$minc11)/($maxc11-$minc11)*100; $c11cabai = ($c11c-$minc11)/($maxc11-$minc11)*100; $c11tebu = ($c11t-$minc11)/($maxc11-$minc11)*100;
}

//C12
if(($c12p == $s1n) && ($c12p==$c12j) && ($c12p==$c12k) && ($c12p == $c12psth) && ($c12p==$c12pgogo) && ($c12p==$c12psrps) && ($c12p == $c12psrl) && ($c12p==$c12b) && ($c12p==$c12c) && ($c12p == $c12s) && ($c12p==$c12ka) && ($c12p==$c12t) && ($c12p==$c12r) && ($c12p==$c12set)){
    $c12padi = 100; $c12padisth = 100; $c12padisrl = 100; $c12sawit = 100; $c12rumput = 100;
    $c12jagung = 100; $c12padigogo = 100; $c12bawang = 100; $c12kakao = 100; $c12setaria = 100;
    $c12kedelai = 100; $c12padisrps = 100; $c12cabai = 100; $c12tebu = 100;
}else if(($c12p == $s2n) && ($c12p==$c12j) && ($c12p==$c12k) && ($c12p == $c12psth) && ($c12p==$c12pgogo) && ($c12p==$c12psrps) && ($c12p == $c12psrl) && ($c12p==$c12b) && ($c12p==$c12c) && ($c12p == $c12s) && ($c12p==$c12ka) && ($c12p==$c12t) && ($c12p==$c12r) && ($c12p==$c12set)){
    $c12padi = 66.6; $c12padisth = 66.6; $c12padisrl = 66.6; $c12sawit = 66.6; $c12rumput = 66.6;
    $c12jagung = 66.6; $c12padigogo = 66.6; $c12bawang = 66.6; $c12kakao = 66.6; $c12setaria = 66.6;
    $c12kedelai = 66.6; $c12padisrps = 66.6; $c12cabai = 66.6; $c12tebu = 66.6;
}else if(($c12p == $s3n) && ($c12p==$c12j) && ($c12p==$c12k) && ($c12p == $c12psth) && ($c12p==$c12pgogo) && ($c12p==$c12psrps) && ($c12p == $c12psrl) && ($c12p==$c12b) && ($c12p==$c12c) && ($c12p == $c12s) && ($c12p==$c12ka) && ($c12p==$c12t) && ($c12p==$c12r) && ($c12p==$c12set)){
    $c12padi = 33.3; $c12padisth = 33.3; $c12padisrl = 33.3; $c12sawit = 33.3; $c12rumput = 33.3;
    $c12jagung = 33.3; $c12padigogo = 33.3; $c12bawang = 33.3; $c12kakao = 33.3; $c12setaria = 33.3;
    $c12kedelai = 33.3; $c12padisrps = 33.3; $c12cabai = 33.3; $c12tebu = 33.3;
}else if(($c12p == $nn) && ($c12p==$c12j) && ($c12p==$c12k) && ($c12p == $c12psth) && ($c12p==$c12pgogo) && ($c12p==$c12psrps) && ($c12p == $c12psrl) && ($c12p==$c12b) && ($c12p==$c12c) && ($c12p == $c12s) && ($c12p==$c12ka) && ($c12p==$c12t) && ($c12p==$c12r) && ($c12p==$c12set)){
    $c12padi = 0; $c12padisth = 0; $c12padisrl = 0; $c12sawit = 0; $c12rumput = 0;
    $c12jagung = 0; $c12padigogo = 0; $c12bawang = 0; $c12kakao = 0; $c12setaria = 0;
    $c12kedelai = 0; $c12padisrps = 0; $c12cabai = 0; $c12tebu = 0;
}else {
    $c12padi = ($c12p-$minc12)/($maxc12-$minc12)*100; $c12padisth = ($c12psth-$minc12)/($maxc12-$minc12)*100; $c12padisrl = ($c12psrl-$minc12)/($maxc12-$minc12)*100; $c12sawit = ($c12s-$minc12)/($maxc12-$minc12)*100; $c12rumput = ($c12r-$minc12)/($maxc12-$minc12)*100;
    $c12jagung = ($c12j-$minc12)/($maxc12-$minc12)*100; $c12padigogo = ($c12pgogo-$minc12)/($maxc12-$minc12)*100; $c12bawang = ($c12b-$minc12)/($maxc12-$minc12)*100; $c12kakao = ($c12ka-$minc12)/($maxc12-$minc12)*100; $c12setaria = ($c12set-$minc12)/($maxc12-$minc12)*100;
    $c12kedelai = ($c12k-$minc12)/($maxc12-$minc12)*100; $c12padisrps = ($c12psrps-$minc12)/($maxc12-$minc12)*100; $c12cabai = ($c12c-$minc12)/($maxc12-$minc12)*100; $c12tebu = ($c12t-$minc12)/($maxc12-$minc12)*100;
}

//C13
if(($c13p == $s1n) && ($c13p==$c13j) && ($c13p==$c13k) && ($c13p == $c13psth) && ($c13p==$c13pgogo) && ($c13p==$c13psrps) && ($c13p == $c13psrl) && ($c13p==$c13b) && ($c13p==$c13c) && ($c13p == $c13s) && ($c13p==$c13ka) && ($c13p==$c13t) && ($c13p==$c13r) && ($c13p==$c13set)){
    $c13padi = 100; $c13padisth = 100; $c13padisrl = 100; $c13sawit = 100; $c13rumput = 100;
    $c13jagung = 100; $c13padigogo = 100; $c13bawang = 100; $c13kakao = 100; $c13setaria = 100;
    $c13kedelai = 100; $c13padisrps = 100; $c13cabai = 100; $c13tebu = 100;
}else if(($c13p == $s2n) && ($c13p==$c13j) && ($c13p==$c13k) && ($c13p == $c13psth) && ($c13p==$c13pgogo) && ($c13p==$c13psrps) && ($c13p == $c13psrl) && ($c13p==$c13b) && ($c13p==$c13c) && ($c13p == $c13s) && ($c13p==$c13ka) && ($c13p==$c13t) && ($c13p==$c13r) && ($c13p==$c13set)){
    $c13padi = 66.6; $c13padisth = 66.6; $c13padisrl = 66.6; $c13sawit = 66.6; $c13rumput = 66.6;
    $c13jagung = 66.6; $c13padigogo = 66.6; $c13bawang = 66.6; $c13kakao = 66.6; $c13setaria = 66.6;
    $c13kedelai = 66.6; $c13padisrps = 66.6; $c13cabai = 66.6; $c13tebu = 66.6;
}else if(($c13p == $s3n) && ($c13p==$c13j) && ($c13p==$c13k) && ($c13p == $c13psth) && ($c13p==$c13pgogo) && ($c13p==$c13psrps) && ($c13p == $c13psrl) && ($c13p==$c13b) && ($c13p==$c13c) && ($c13p == $c13s) && ($c13p==$c13ka) && ($c13p==$c13t) && ($c13p==$c13r) && ($c13p==$c13set)){
    $c13padi = 33.3; $c13padisth = 33.3; $c13padisrl = 33.3; $c13sawit = 33.3; $c13rumput = 33.3;
    $c13jagung = 33.3; $c13padigogo = 33.3; $c13bawang = 33.3; $c13kakao = 33.3; $c13setaria = 33.3;
    $c13kedelai = 33.3; $c13padisrps = 33.3; $c13cabai = 33.3; $c13tebu = 33.3;
}else if(($c13p == $nn) && ($c13p==$c13j) && ($c13p==$c13k) && ($c13p == $c13psth) && ($c13p==$c13pgogo) && ($c13p==$c13psrps) && ($c13p == $c13psrl) && ($c13p==$c13b) && ($c13p==$c13c) && ($c13p == $c13s) && ($c13p==$c13ka) && ($c13p==$c13t) && ($c13p==$c13r) && ($c13p==$c13set)){
    $c13padi = 0; $c13padisth = 0; $c13padisrl = 0; $c13sawit = 0; $c13rumput = 0;
    $c13jagung = 0; $c13padigogo = 0; $c13bawang = 0; $c13kakao = 0; $c13setaria = 0;
    $c13kedelai = 0; $c13padisrps = 0; $c13cabai = 0; $c13tebu = 0;
}else {
    $c13padi = ($c13p-$minc13)/($maxc13-$minc13)*100; $c13padisth = ($c13psth-$minc13)/($maxc13-$minc13)*100; $c13padisrl = ($c13psrl-$minc13)/($maxc13-$minc13)*100; $c13sawit = ($c13s-$minc13)/($maxc13-$minc13)*100; $c13rumput = ($c13r-$minc13)/($maxc13-$minc13)*100;
    $c13jagung = ($c13j-$minc13)/($maxc13-$minc13)*100; $c13padigogo = ($c13pgogo-$minc13)/($maxc13-$minc13)*100; $c13bawang = ($c13b-$minc13)/($maxc13-$minc13)*100; $c13kakao = ($c13ka-$minc13)/($maxc13-$minc13)*100; $c13setaria = ($c13set-$minc13)/($maxc13-$minc13)*100;
    $c13kedelai = ($c13k-$minc13)/($maxc13-$minc13)*100; $c13padisrps = ($c13psrps-$minc13)/($maxc13-$minc13)*100; $c13cabai = ($c13c-$minc13)/($maxc13-$minc13)*100; $c13tebu = ($c13t-$minc13)/($maxc13-$minc13)*100;
}

//C14
if(($c14p == $s1n) && ($c14p==$c14j) && ($c14p==$c14k) && ($c14p == $c14psth) && ($c14p==$c14pgogo) && ($c14p==$c14psrps) && ($c14p == $c14psrl) && ($c14p==$c14b) && ($c14p==$c14c) && ($c14p == $c14s) && ($c14p==$c14ka) && ($c14p==$c14t) && ($c14p==$c14r) && ($c14p==$c14set)){
    $c14padi = 100; $c14padisth = 100; $c14padisrl = 100; $c14sawit = 100; $c14rumput = 100;
    $c14jagung = 100; $c14padigogo = 100; $c14bawang = 100; $c14kakao = 100; $c14setaria = 100;
    $c14kedelai = 100; $c14padisrps = 100; $c14cabai = 100; $c14tebu = 100;
}else if(($c14p == $s2n) && ($c14p==$c14j) && ($c14p==$c14k) && ($c14p == $c14psth) && ($c14p==$c14pgogo) && ($c14p==$c14psrps) && ($c14p == $c14psrl) && ($c14p==$c14b) && ($c14p==$c14c) && ($c14p == $c14s) && ($c14p==$c14ka) && ($c14p==$c14t) && ($c14p==$c14r) && ($c14p==$c14set)){
    $c14padi = 66.6; $c14padisth = 66.6; $c14padisrl = 66.6; $c14sawit = 66.6; $c14rumput = 66.6;
    $c14jagung = 66.6; $c14padigogo = 66.6; $c14bawang = 66.6; $c14kakao = 66.6; $c14setaria = 66.6;
    $c14kedelai = 66.6; $c14padisrps = 66.6; $c14cabai = 66.6; $c14tebu = 66.6;
}else if(($c14p == $s3n) && ($c14p==$c14j) && ($c14p==$c14k) && ($c14p == $c14psth) && ($c14p==$c14pgogo) && ($c14p==$c14psrps) && ($c14p == $c14psrl) && ($c14p==$c14b) && ($c14p==$c14c) && ($c14p == $c14s) && ($c14p==$c14ka) && ($c14p==$c14t) && ($c14p==$c14r) && ($c14p==$c14set)){
    $c14padi = 33.3; $c14padisth = 33.3; $c14padisrl = 33.3; $c14sawit = 33.3; $c14rumput = 33.3;
    $c14jagung = 33.3; $c14padigogo = 33.3; $c14bawang = 33.3; $c14kakao = 33.3; $c14setaria = 33.3;
    $c14kedelai = 33.3; $c14padisrps = 33.3; $c14cabai = 33.3; $c14tebu = 33.3;
}else if(($c14p == $nn) && ($c14p==$c14j) && ($c14p==$c14k) && ($c14p == $c14psth) && ($c14p==$c14pgogo) && ($c14p==$c14psrps) && ($c14p == $c14psrl) && ($c14p==$c14b) && ($c14p==$c14c) && ($c14p == $c14s) && ($c14p==$c14ka) && ($c14p==$c14t) && ($c14p==$c14r) && ($c14p==$c14set)){
    $c14padi = 0; $c14padisth = 0; $c14padisrl = 0; $c14sawit = 0; $c14rumput = 0;
    $c14jagung = 0; $c14padigogo = 0; $c14bawang = 0; $c14kakao = 0; $c14setaria = 0;
    $c14kedelai = 0; $c14padisrps = 0; $c14cabai = 0; $c14tebu = 0;
}else {
    $c14padi = ($c14p-$minc14)/($maxc14-$minc14)*100; $c14padisth = ($c14psth-$minc14)/($maxc14-$minc14)*100; $c14padisrl = ($c14psrl-$minc14)/($maxc14-$minc14)*100; $c14sawit = ($c14s-$minc14)/($maxc14-$minc14)*100; $c14rumput = ($c14r-$minc14)/($maxc14-$minc14)*100;
    $c14jagung = ($c14j-$minc14)/($maxc14-$minc14)*100; $c14padigogo = ($c14pgogo-$minc14)/($maxc14-$minc14)*100; $c14bawang = ($c14b-$minc14)/($maxc14-$minc14)*100; $c14kakao = ($c14ka-$minc14)/($maxc14-$minc14)*100; $c14setaria = ($c14set-$minc14)/($maxc14-$minc14)*100;
    $c14kedelai = ($c14k-$minc14)/($maxc14-$minc14)*100; $c14padisrps = ($c14psrps-$minc14)/($maxc14-$minc14)*100; $c14cabai = ($c14c-$minc14)/($maxc14-$minc14)*100; $c14tebu = ($c14t-$minc14)/($maxc14-$minc14)*100;
}

//C15
if(($c15p == $s1n) && ($c15p==$c15j) && ($c15p==$c15k) && ($c15p == $c15psth) && ($c15p==$c15pgogo) && ($c15p==$c15psrps) && ($c15p == $c15psrl) && ($c15p==$c15b) && ($c15p==$c15c) && ($c15p == $c15s) && ($c15p==$c15ka) && ($c15p==$c15t) && ($c15p==$c15r) && ($c15p==$c15set)){
    $c15padi = 100; $c15padisth = 100; $c15padisrl = 100; $c15sawit = 100; $c15rumput = 100;
    $c15jagung = 100; $c15padigogo = 100; $c15bawang = 100; $c15kakao = 100; $c15setaria = 100;
    $c15kedelai = 100; $c15padisrps = 100; $c15cabai = 100; $c15tebu = 100;
}else if(($c15p == $s2n) && ($c15p==$c15j) && ($c15p==$c15k) && ($c15p == $c15psth) && ($c15p==$c15pgogo) && ($c15p==$c15psrps) && ($c15p == $c15psrl) && ($c15p==$c15b) && ($c15p==$c15c) && ($c15p == $c15s) && ($c15p==$c15ka) && ($c15p==$c15t) && ($c15p==$c15r) && ($c15p==$c15set)){
    $c15padi = 66.6; $c15padisth = 66.6; $c15padisrl = 66.6; $c15sawit = 66.6; $c15rumput = 66.6;
    $c15jagung = 66.6; $c15padigogo = 66.6; $c15bawang = 66.6; $c15kakao = 66.6; $c15setaria = 66.6;
    $c15kedelai = 66.6; $c15padisrps = 66.6; $c15cabai = 66.6; $c15tebu = 66.6;
}else if(($c15p == $s3n) && ($c15p==$c15j) && ($c15p==$c15k) && ($c15p == $c15psth) && ($c15p==$c15pgogo) && ($c15p==$c15psrps) && ($c15p == $c15psrl) && ($c15p==$c15b) && ($c15p==$c15c) && ($c15p == $c15s) && ($c15p==$c15ka) && ($c15p==$c15t) && ($c15p==$c15r) && ($c15p==$c15set)){
    $c15padi = 33.3; $c15padisth = 33.3; $c15padisrl = 33.3; $c15sawit = 33.3; $c15rumput = 33.3;
    $c15jagung = 33.3; $c15padigogo = 33.3; $c15bawang = 33.3; $c15kakao = 33.3; $c15setaria = 33.3;
    $c15kedelai = 33.3; $c15padisrps = 33.3; $c15cabai = 33.3; $c15tebu = 33.3;
}else if(($c15p == $nn) && ($c15p==$c15j) && ($c15p==$c15k) && ($c15p == $c15psth) && ($c15p==$c15pgogo) && ($c15p==$c15psrps) && ($c15p == $c15psrl) && ($c15p==$c15b) && ($c15p==$c15c) && ($c15p == $c15s) && ($c15p==$c15ka) && ($c15p==$c15t) && ($c15p==$c15r) && ($c15p==$c15set)){
    $c15padi = 0; $c15padisth = 0; $c15padisrl = 0; $c15sawit = 0; $c15rumput = 0;
    $c15jagung = 0; $c15padigogo = 0; $c15bawang = 0; $c15kakao = 0; $c15setaria = 0;
    $c15kedelai = 0; $c15padisrps = 0; $c15cabai = 0; $c15tebu = 0;
}else {
    $c15padi = ($c15p-$minc15)/($maxc15-$minc15)*100; $c15padisth = ($c15psth-$minc15)/($maxc15-$minc15)*100; $c15padisrl = ($c15psrl-$minc15)/($maxc15-$minc15)*100; $c15sawit = ($c15s-$minc15)/($maxc15-$minc15)*100; $c15rumput = ($c15r-$minc15)/($maxc15-$minc15)*100;
    $c15jagung = ($c15j-$minc15)/($maxc15-$minc15)*100; $c15padigogo = ($c15pgogo-$minc15)/($maxc15-$minc15)*100; $c15bawang = ($c15b-$minc15)/($maxc15-$minc15)*100; $c15kakao = ($c15ka-$minc15)/($maxc15-$minc15)*100; $c15setaria = ($c15set-$minc15)/($maxc15-$minc15)*100;
    $c15kedelai = ($c15k-$minc15)/($maxc15-$minc15)*100; $c15padisrps = ($c15psrps-$minc15)/($maxc15-$minc15)*100; $c15cabai = ($c15c-$minc15)/($maxc15-$minc15)*100; $c15tebu = ($c15t-$minc15)/($maxc15-$minc15)*100;
}

//C16
if(($c16p == $s1n) && ($c16p==$c16j) && ($c16p==$c16k) && ($c16p == $c16psth) && ($c16p==$c16pgogo) && ($c16p==$c16psrps) && ($c16p == $c16psrl) && ($c16p==$c16b) && ($c16p==$c16c) && ($c16p == $c16s) && ($c16p==$c16ka) && ($c16p==$c16t) && ($c16p==$c16r) && ($c16p==$c16set)){
    $c16padi = 100; $c16padisth = 100; $c16padisrl = 100; $c16sawit = 100; $c16rumput = 100;
    $c16jagung = 100; $c16padigogo = 100; $c16bawang = 100; $c16kakao = 100; $c16setaria = 100;
    $c16kedelai = 100; $c16padisrps = 100; $c16cabai = 100; $c16tebu = 100;
}else if(($c16p == $s2n) && ($c16p==$c16j) && ($c16p==$c16k) && ($c16p == $c16psth) && ($c16p==$c16pgogo) && ($c16p==$c16psrps) && ($c16p == $c16psrl) && ($c16p==$c16b) && ($c16p==$c16c) && ($c16p == $c16s) && ($c16p==$c16ka) && ($c16p==$c16t) && ($c16p==$c16r) && ($c16p==$c16set)){
    $c16padi = 66.6; $c16padisth = 66.6; $c16padisrl = 66.6; $c16sawit = 66.6; $c16rumput = 66.6;
    $c16jagung = 66.6; $c16padigogo = 66.6; $c16bawang = 66.6; $c16kakao = 66.6; $c16setaria = 66.6;
    $c16kedelai = 66.6; $c16padisrps = 66.6; $c16cabai = 66.6; $c16tebu = 66.6;
}else if(($c16p == $s3n) && ($c16p==$c16j) && ($c16p==$c16k) && ($c16p == $c16psth) && ($c16p==$c16pgogo) && ($c16p==$c16psrps) && ($c16p == $c16psrl) && ($c16p==$c16b) && ($c16p==$c16c) && ($c16p == $c16s) && ($c16p==$c16ka) && ($c16p==$c16t) && ($c16p==$c16r) && ($c16p==$c16set)){
    $c16padi = 33.3; $c16padisth = 33.3; $c16padisrl = 33.3; $c16sawit = 33.3; $c16rumput = 33.3;
    $c16jagung = 33.3; $c16padigogo = 33.3; $c16bawang = 33.3; $c16kakao = 33.3; $c16setaria = 33.3;
    $c16kedelai = 33.3; $c16padisrps = 33.3; $c16cabai = 33.3; $c16tebu = 33.3;
}else if(($c16p == $nn) && ($c16p==$c16j) && ($c16p==$c16k) && ($c16p == $c16psth) && ($c16p==$c16pgogo) && ($c16p==$c16psrps) && ($c16p == $c16psrl) && ($c16p==$c16b) && ($c16p==$c16c) && ($c16p == $c16s) && ($c16p==$c16ka) && ($c16p==$c16t) && ($c16p==$c16r) && ($c16p==$c16set)){
    $c16padi = 0; $c16padisth = 0; $c16padisrl = 0; $c16sawit = 0; $c16rumput = 0;
    $c16jagung = 0; $c16padigogo = 0; $c16bawang = 0; $c16kakao = 0; $c16setaria = 0;
    $c16kedelai = 0; $c16padisrps = 0; $c16cabai = 0; $c16tebu = 0;
}else {
    $c16padi = ($c16p-$minc16)/($maxc16-$minc16)*100; $c16padisth = ($c16psth-$minc16)/($maxc16-$minc16)*100; $c16padisrl = ($c16psrl-$minc16)/($maxc16-$minc16)*100; $c16sawit = ($c16s-$minc16)/($maxc16-$minc16)*100; $c16rumput = ($c16r-$minc16)/($maxc16-$minc16)*100;
    $c16jagung = ($c16j-$minc16)/($maxc16-$minc16)*100; $c16padigogo = ($c16pgogo-$minc16)/($maxc16-$minc16)*100; $c16bawang = ($c16b-$minc16)/($maxc16-$minc16)*100; $c16kakao = ($c16ka-$minc16)/($maxc16-$minc16)*100; $c16setaria = ($c16set-$minc16)/($maxc16-$minc16)*100;
    $c16kedelai = ($c16k-$minc16)/($maxc16-$minc16)*100; $c16padisrps = ($c16psrps-$minc16)/($maxc16-$minc16)*100; $c16cabai = ($c16c-$minc16)/($maxc16-$minc16)*100; $c16tebu = ($c16t-$minc16)/($maxc16-$minc16)*100;
}

//C17
if(($c17p == $s1n) && ($c17p==$c17j) && ($c17p==$c17k) && ($c17p == $c17psth) && ($c17p==$c17pgogo) && ($c17p==$c17psrps) && ($c17p == $c17psrl) && ($c17p==$c17b) && ($c17p==$c17c) && ($c17p == $c17s) && ($c17p==$c17ka) && ($c17p==$c17t) && ($c17p==$c17r) && ($c17p==$c17set)){
    $c17padi = 100; $c17padisth = 100; $c17padisrl = 100; $c17sawit = 100; $c17rumput = 100;
    $c17jagung = 100; $c17padigogo = 100; $c17bawang = 100; $c17kakao = 100; $c17setaria = 100;
    $c17kedelai = 100; $c17padisrps = 100; $c17cabai = 100; $c17tebu = 100;
}else if(($c17p == $s2n) && ($c17p==$c17j) && ($c17p==$c17k) && ($c17p == $c17psth) && ($c17p==$c17pgogo) && ($c17p==$c17psrps) && ($c17p == $c17psrl) && ($c17p==$c17b) && ($c17p==$c17c) && ($c17p == $c17s) && ($c17p==$c17ka) && ($c17p==$c17t) && ($c17p==$c17r) && ($c17p==$c17set)){
    $c17padi = 66.6; $c17padisth = 66.6; $c17padisrl = 66.6; $c17sawit = 66.6; $c17rumput = 66.6;
    $c17jagung = 66.6; $c17padigogo = 66.6; $c17bawang = 66.6; $c17kakao = 66.6; $c17setaria = 66.6;
    $c17kedelai = 66.6; $c17padisrps = 66.6; $c17cabai = 66.6; $c17tebu = 66.6;
}else if(($c17p == $s3n) && ($c17p==$c17j) && ($c17p==$c17k) && ($c17p == $c17psth) && ($c17p==$c17pgogo) && ($c17p==$c17psrps) && ($c17p == $c17psrl) && ($c17p==$c17b) && ($c17p==$c17c) && ($c17p == $c17s) && ($c17p==$c17ka) && ($c17p==$c17t) && ($c17p==$c17r) && ($c17p==$c17set)){
    $c17padi = 33.3; $c17padisth = 33.3; $c17padisrl = 33.3; $c17sawit = 33.3; $c17rumput = 33.3;
    $c17jagung = 33.3; $c17padigogo = 33.3; $c17bawang = 33.3; $c17kakao = 33.3; $c17setaria = 33.3;
    $c17kedelai = 33.3; $c17padisrps = 33.3; $c17cabai = 33.3; $c17tebu = 33.3;
}else if(($c17p == $nn) && ($c17p==$c17j) && ($c17p==$c17k) && ($c17p == $c17psth) && ($c17p==$c17pgogo) && ($c17p==$c17psrps) && ($c17p == $c17psrl) && ($c17p==$c17b) && ($c17p==$c17c) && ($c17p == $c17s) && ($c17p==$c17ka) && ($c17p==$c17t) && ($c17p==$c17r) && ($c17p==$c17set)){
    $c17padi = 0; $c17padisth = 0; $c17padisrl = 0; $c17sawit = 0; $c17rumput = 0;
    $c17jagung = 0; $c17padigogo = 0; $c17bawang = 0; $c17kakao = 0; $c17setaria = 0;
    $c17kedelai = 0; $c17padisrps = 0; $c17cabai = 0; $c17tebu = 0;
}else {
    $c17padi = ($c17p-$minc17)/($maxc17-$minc17)*100; $c17padisth = ($c17psth-$minc17)/($maxc17-$minc17)*100; $c17padisrl = ($c17psrl-$minc17)/($maxc17-$minc17)*100; $c17sawit = ($c17s-$minc17)/($maxc17-$minc17)*100; $c17rumput = ($c17r-$minc17)/($maxc17-$minc17)*100;
    $c17jagung = ($c17j-$minc17)/($maxc17-$minc17)*100; $c17padigogo = ($c17pgogo-$minc17)/($maxc17-$minc17)*100; $c17bawang = ($c17b-$minc17)/($maxc17-$minc17)*100; $c17kakao = ($c17ka-$minc17)/($maxc17-$minc17)*100; $c17setaria = ($c17set-$minc17)/($maxc17-$minc17)*100;
    $c17kedelai = ($c17k-$minc17)/($maxc17-$minc17)*100; $c17padisrps = ($c17psrps-$minc17)/($maxc17-$minc17)*100; $c17cabai = ($c17c-$minc17)/($maxc17-$minc17)*100; $c17tebu = ($c17t-$minc17)/($maxc17-$minc17)*100;
}

//C18
if(($c18p == $s1n) && ($c18p==$c18j) && ($c18p==$c18k) && ($c18p == $c18psth) && ($c18p==$c18pgogo) && ($c18p==$c18psrps) && ($c18p == $c18psrl) && ($c18p==$c18b) && ($c18p==$c18c) && ($c18p == $c18s) && ($c18p==$c18ka) && ($c18p==$c18t) && ($c18p==$c18r) && ($c18p==$c18set)){
    $c18padi = 100; $c18padisth = 100; $c18padisrl = 100; $c18sawit = 100; $c18rumput = 100;
    $c18jagung = 100; $c18padigogo = 100; $c18bawang = 100; $c18kakao = 100; $c18setaria = 100;
    $c18kedelai = 100; $c18padisrps = 100; $c18cabai = 100; $c18tebu = 100;
}else if(($c18p == $s2n) && ($c18p==$c18j) && ($c18p==$c18k) && ($c18p == $c18psth) && ($c18p==$c18pgogo) && ($c18p==$c18psrps) && ($c18p == $c18psrl) && ($c18p==$c18b) && ($c18p==$c18c) && ($c18p == $c18s) && ($c18p==$c18ka) && ($c18p==$c18t) && ($c18p==$c18r) && ($c18p==$c18set)){
    $c18padi = 66.6; $c18padisth = 66.6; $c18padisrl = 66.6; $c18sawit = 66.6; $c18rumput = 66.6;
    $c18jagung = 66.6; $c18padigogo = 66.6; $c18bawang = 66.6; $c18kakao = 66.6; $c18setaria = 66.6;
    $c18kedelai = 66.6; $c18padisrps = 66.6; $c18cabai = 66.6; $c18tebu = 66.6;
}else if(($c18p == $s3n) && ($c18p==$c18j) && ($c18p==$c18k) && ($c18p == $c18psth) && ($c18p==$c18pgogo) && ($c18p==$c18psrps) && ($c18p == $c18psrl) && ($c18p==$c18b) && ($c18p==$c18c) && ($c18p == $c18s) && ($c18p==$c18ka) && ($c18p==$c18t) && ($c18p==$c18r) && ($c18p==$c18set)){
    $c18padi = 33.3; $c18padisth = 33.3; $c18padisrl = 33.3; $c18sawit = 33.3; $c18rumput = 33.3;
    $c18jagung = 33.3; $c18padigogo = 33.3; $c18bawang = 33.3; $c18kakao = 33.3; $c18setaria = 33.3;
    $c18kedelai = 33.3; $c18padisrps = 33.3; $c18cabai = 33.3; $c18tebu = 33.3;
}else if(($c18p == $nn) && ($c18p==$c18j) && ($c18p==$c18k) && ($c18p == $c18psth) && ($c18p==$c18pgogo) && ($c18p==$c18psrps) && ($c18p == $c18psrl) && ($c18p==$c18b) && ($c18p==$c18c) && ($c18p == $c18s) && ($c18p==$c18ka) && ($c18p==$c18t) && ($c18p==$c18r) && ($c18p==$c18set)){
    $c18padi = 0; $c18padisth = 0; $c18padisrl = 0; $c18sawit = 0; $c18rumput = 0;
    $c18jagung = 0; $c18padigogo = 0; $c18bawang = 0; $c18kakao = 0; $c18setaria = 0;
    $c18kedelai = 0; $c18padisrps = 0; $c18cabai = 0; $c18tebu = 0;
}else {
    $c18padi = ($c18p-$minc18)/($maxc18-$minc18)*100; $c18padisth = ($c18psth-$minc18)/($maxc18-$minc18)*100; $c18padisrl = ($c18psrl-$minc18)/($maxc18-$minc18)*100; $c18sawit = ($c18s-$minc18)/($maxc18-$minc18)*100; $c18rumput = ($c18r-$minc18)/($maxc18-$minc18)*100;
    $c18jagung = ($c18j-$minc18)/($maxc18-$minc18)*100; $c18padigogo = ($c18pgogo-$minc18)/($maxc18-$minc18)*100; $c18bawang = ($c18b-$minc18)/($maxc18-$minc18)*100; $c18kakao = ($c18ka-$minc18)/($maxc18-$minc18)*100; $c18setaria = ($c18set-$minc18)/($maxc18-$minc18)*100;
    $c18kedelai = ($c18k-$minc18)/($maxc18-$minc18)*100; $c18padisrps = ($c18psrps-$minc18)/($maxc18-$minc18)*100; $c18cabai = ($c18c-$minc18)/($maxc18-$minc18)*100; $c18tebu = ($c18t-$minc18)/($maxc18-$minc18)*100;
}

//C19
if(($c19p == $s1n) && ($c19p==$c19j) && ($c19p==$c19k) && ($c19p == $c19psth) && ($c19p==$c19pgogo) && ($c19p==$c19psrps) && ($c19p == $c19psrl) && ($c19p==$c19b) && ($c19p==$c19c) && ($c19p == $c19s) && ($c19p==$c19ka) && ($c19p==$c19t) && ($c19p==$c19r) && ($c19p==$c19set)){
    $c19padi = 100; $c19padisth = 100; $c19padisrl = 100; $c19sawit = 100; $c19rumput = 100;
    $c19jagung = 100; $c19padigogo = 100; $c19bawang = 100; $c19kakao = 100; $c19setaria = 100;
    $c19kedelai = 100; $c19padisrps = 100; $c19cabai = 100; $c19tebu = 100;
}else if(($c19p == $s2n) && ($c19p==$c19j) && ($c19p==$c19k) && ($c19p == $c19psth) && ($c19p==$c19pgogo) && ($c19p==$c19psrps) && ($c19p == $c19psrl) && ($c19p==$c19b) && ($c19p==$c19c) && ($c19p == $c19s) && ($c19p==$c19ka) && ($c19p==$c19t) && ($c19p==$c19r) && ($c19p==$c19set)){
    $c19padi = 66.6; $c19padisth = 66.6; $c19padisrl = 66.6; $c19sawit = 66.6; $c19rumput = 66.6;
    $c19jagung = 66.6; $c19padigogo = 66.6; $c19bawang = 66.6; $c19kakao = 66.6; $c19setaria = 66.6;
    $c19kedelai = 66.6; $c19padisrps = 66.6; $c19cabai = 66.6; $c19tebu = 66.6;
}else if(($c19p == $s3n) && ($c19p==$c19j) && ($c19p==$c19k) && ($c19p == $c19psth) && ($c19p==$c19pgogo) && ($c19p==$c19psrps) && ($c19p == $c19psrl) && ($c19p==$c19b) && ($c19p==$c19c) && ($c19p == $c19s) && ($c19p==$c19ka) && ($c19p==$c19t) && ($c19p==$c19r) && ($c19p==$c19set)){
    $c19padi = 33.3; $c19padisth = 33.3; $c19padisrl = 33.3; $c19sawit = 33.3; $c19rumput = 33.3;
    $c19jagung = 33.3; $c19padigogo = 33.3; $c19bawang = 33.3; $c19kakao = 33.3; $c19setaria = 33.3;
    $c19kedelai = 33.3; $c19padisrps = 33.3; $c19cabai = 33.3; $c19tebu = 33.3;
}else if(($c19p == $nn) && ($c19p==$c19j) && ($c19p==$c19k) && ($c19p == $c19psth) && ($c19p==$c19pgogo) && ($c19p==$c19psrps) && ($c19p == $c19psrl) && ($c19p==$c19b) && ($c19p==$c19c) && ($c19p == $c19s) && ($c19p==$c19ka) && ($c19p==$c19t) && ($c19p==$c19r) && ($c19p==$c19set)){
    $c19padi = 0; $c19padisth = 0; $c19padisrl = 0; $c19sawit = 0; $c19rumput = 0;
    $c19jagung = 0; $c19padigogo = 0; $c19bawang = 0; $c19kakao = 0; $c19setaria = 0;
    $c19kedelai = 0; $c19padisrps = 0; $c19cabai = 0; $c19tebu = 0;
}else {
    $c19padi = ($c19p-$minc19)/($maxc19-$minc19)*100; $c19padisth = ($c19psth-$minc19)/($maxc19-$minc19)*100; $c19padisrl = ($c19psrl-$minc19)/($maxc19-$minc19)*100; $c19sawit = ($c19s-$minc19)/($maxc19-$minc19)*100; $c19rumput = ($c19r-$minc19)/($maxc19-$minc19)*100;
    $c19jagung = ($c19j-$minc19)/($maxc19-$minc19)*100; $c19padigogo = ($c19pgogo-$minc19)/($maxc19-$minc19)*100; $c19bawang = ($c19b-$minc19)/($maxc19-$minc19)*100; $c19kakao = ($c19ka-$minc19)/($maxc19-$minc19)*100; $c19setaria = ($c19set-$minc19)/($maxc19-$minc19)*100;
    $c19kedelai = ($c19k-$minc19)/($maxc19-$minc19)*100; $c19padisrps = ($c19psrps-$minc19)/($maxc19-$minc19)*100; $c19cabai = ($c19c-$minc19)/($maxc19-$minc19)*100; $c19tebu = ($c19t-$minc19)/($maxc19-$minc19)*100;
}

//C20
if(($c20p == $s1n) && ($c20p==$c20j) && ($c20p==$c20k) && ($c20p == $c20psth) && ($c20p==$c20pgogo) && ($c20p==$c20psrps) && ($c20p == $c20psrl) && ($c20p==$c20b) && ($c20p==$c20c) && ($c20p == $c20s) && ($c20p==$c20ka) && ($c20p==$c20t) && ($c20p==$c20r) && ($c20p==$c20set)){
    $c20padi = 100; $c20padisth = 100; $c20padisrl = 100; $c20sawit = 100; $c20rumput = 100;
    $c20jagung = 100; $c20padigogo = 100; $c20bawang = 100; $c20kakao = 100; $c20setaria = 100;
    $c20kedelai = 100; $c20padisrps = 100; $c20cabai = 100; $c20tebu = 100;
}else if(($c20p == $s2n) && ($c20p==$c20j) && ($c20p==$c20k) && ($c20p == $c20psth) && ($c20p==$c20pgogo) && ($c20p==$c20psrps) && ($c20p == $c20psrl) && ($c20p==$c20b) && ($c20p==$c20c) && ($c20p == $c20s) && ($c20p==$c20ka) && ($c20p==$c20t) && ($c20p==$c20r) && ($c20p==$c20set)){
    $c20padi = 66.6; $c20padisth = 66.6; $c20padisrl = 66.6; $c20sawit = 66.6; $c20rumput = 66.6;
    $c20jagung = 66.6; $c20padigogo = 66.6; $c20bawang = 66.6; $c20kakao = 66.6; $c20setaria = 66.6;
    $c20kedelai = 66.6; $c20padisrps = 66.6; $c20cabai = 66.6; $c20tebu = 66.6;
}else if(($c20p == $s3n) && ($c20p==$c20j) && ($c20p==$c20k) && ($c20p == $c20psth) && ($c20p==$c20pgogo) && ($c20p==$c20psrps) && ($c20p == $c20psrl) && ($c20p==$c20b) && ($c20p==$c20c) && ($c20p == $c20s) && ($c20p==$c20ka) && ($c20p==$c20t) && ($c20p==$c20r) && ($c20p==$c20set)){
    $c20padi = 33.3; $c20padisth = 33.3; $c20padisrl = 33.3; $c20sawit = 33.3; $c20rumput = 33.3;
    $c20jagung = 33.3; $c20padigogo = 33.3; $c20bawang = 33.3; $c20kakao = 33.3; $c20setaria = 33.3;
    $c20kedelai = 33.3; $c20padisrps = 33.3; $c20cabai = 33.3; $c20tebu = 33.3;
}else if(($c20p == $nn) && ($c20p==$c20j) && ($c20p==$c20k) && ($c20p == $c20psth) && ($c20p==$c20pgogo) && ($c20p==$c20psrps) && ($c20p == $c20psrl) && ($c20p==$c20b) && ($c20p==$c20c) && ($c20p == $c20s) && ($c20p==$c20ka) && ($c20p==$c20t) && ($c20p==$c20r) && ($c20p==$c20set)){
    $c20padi = 0; $c20padisth = 0; $c20padisrl = 0; $c20sawit = 0; $c20rumput = 0;
    $c20jagung = 0; $c20padigogo = 0; $c20bawang = 0; $c20kakao = 0; $c20setaria = 0;
    $c20kedelai = 0; $c20padisrps = 0; $c20cabai = 0; $c20tebu = 0;
}else {
    $c20padi = ($c20p-$minc20)/($maxc20-$minc20)*100; $c20padisth = ($c20psth-$minc20)/($maxc20-$minc20)*100; $c20padisrl = ($c20psrl-$minc20)/($maxc20-$minc20)*100; $c20sawit = ($c20s-$minc20)/($maxc20-$minc20)*100; $c20rumput = ($c20r-$minc20)/($maxc20-$minc20)*100;
    $c20jagung = ($c20j-$minc20)/($maxc20-$minc20)*100; $c20padigogo = ($c20pgogo-$minc20)/($maxc20-$minc20)*100; $c20bawang = ($c20b-$minc20)/($maxc20-$minc20)*100; $c20kakao = ($c20ka-$minc20)/($maxc20-$minc20)*100; $c20setaria = ($c20set-$minc20)/($maxc20-$minc20)*100;
    $c20kedelai = ($c20k-$minc20)/($maxc20-$minc20)*100; $c20padisrps = ($c20psrps-$minc20)/($maxc20-$minc20)*100; $c20cabai = ($c20c-$minc20)/($maxc20-$minc20)*100; $c20tebu = ($c20t-$minc20)/($maxc20-$minc20)*100;
}

//C21
if(($c21p == $s1n) && ($c21p==$c21j) && ($c21p==$c21k) && ($c21p == $c21psth) && ($c21p==$c21pgogo) && ($c21p==$c21psrps) && ($c21p == $c21psrl) && ($c21p==$c21b) && ($c21p==$c21c) && ($c21p == $c21s) && ($c21p==$c21ka) && ($c21p==$c21t) && ($c21p==$c21r) && ($c21p==$c21set)){
    $c21padi = 100; $c21padisth = 100; $c21padisrl = 100; $c21sawit = 100; $c21rumput = 100;
    $c21jagung = 100; $c21padigogo = 100; $c21bawang = 100; $c21kakao = 100; $c21setaria = 100;
    $c21kedelai = 100; $c21padisrps = 100; $c21cabai = 100; $c21tebu = 100;
}else if(($c21p == $s2n) && ($c21p==$c21j) && ($c21p==$c21k) && ($c21p == $c21psth) && ($c21p==$c21pgogo) && ($c21p==$c21psrps) && ($c21p == $c21psrl) && ($c21p==$c21b) && ($c21p==$c21c) && ($c21p == $c21s) && ($c21p==$c21ka) && ($c21p==$c21t) && ($c21p==$c21r) && ($c21p==$c21set)){
    $c21padi = 66.6; $c21padisth = 66.6; $c21padisrl = 66.6; $c21sawit = 66.6; $c21rumput = 66.6;
    $c21jagung = 66.6; $c21padigogo = 66.6; $c21bawang = 66.6; $c21kakao = 66.6; $c21setaria = 66.6;
    $c21kedelai = 66.6; $c21padisrps = 66.6; $c21cabai = 66.6; $c21tebu = 66.6;
}else if(($c21p == $s3n) && ($c21p==$c21j) && ($c21p==$c21k) && ($c21p == $c21psth) && ($c21p==$c21pgogo) && ($c21p==$c21psrps) && ($c21p == $c21psrl) && ($c21p==$c21b) && ($c21p==$c21c) && ($c21p == $c21s) && ($c21p==$c21ka) && ($c21p==$c21t) && ($c21p==$c21r) && ($c21p==$c21set)){
    $c21padi = 33.3; $c21padisth = 33.3; $c21padisrl = 33.3; $c21sawit = 33.3; $c21rumput = 33.3;
    $c21jagung = 33.3; $c21padigogo = 33.3; $c21bawang = 33.3; $c21kakao = 33.3; $c21setaria = 33.3;
    $c21kedelai = 33.3; $c21padisrps = 33.3; $c21cabai = 33.3; $c21tebu = 33.3;
}else if(($c21p == $nn) && ($c21p==$c21j) && ($c21p==$c21k) && ($c21p == $c21psth) && ($c21p==$c21pgogo) && ($c21p==$c21psrps) && ($c21p == $c21psrl) && ($c21p==$c21b) && ($c21p==$c21c) && ($c21p == $c21s) && ($c21p==$c21ka) && ($c21p==$c21t) && ($c21p==$c21r) && ($c21p==$c21set)){
    $c21padi = 0; $c21padisth = 0; $c21padisrl = 0; $c21sawit = 0; $c21rumput = 0;
    $c21jagung = 0; $c21padigogo = 0; $c21bawang = 0; $c21kakao = 0; $c21setaria = 0;
    $c21kedelai = 0; $c21padisrps = 0; $c21cabai = 0; $c21tebu = 0;
}else {
    $c21padi = ($c21p-$minc21)/($maxc21-$minc21)*100; $c21padisth = ($c21psth-$minc21)/($maxc21-$minc21)*100; $c21padisrl = ($c21psrl-$minc21)/($maxc21-$minc21)*100; $c21sawit = ($c21s-$minc21)/($maxc21-$minc21)*100; $c21rumput = ($c21r-$minc21)/($maxc21-$minc21)*100;
    $c21jagung = ($c21j-$minc21)/($maxc21-$minc21)*100; $c21padigogo = ($c21pgogo-$minc21)/($maxc21-$minc21)*100; $c21bawang = ($c21b-$minc21)/($maxc21-$minc21)*100; $c21kakao = ($c21ka-$minc21)/($maxc21-$minc21)*100; $c21setaria = ($c21set-$minc21)/($maxc21-$minc21)*100;
    $c21kedelai = ($c21k-$minc21)/($maxc21-$minc21)*100; $c21padisrps = ($c21psrps-$minc21)/($maxc21-$minc21)*100; $c21cabai = ($c21c-$minc21)/($maxc21-$minc21)*100; $c21tebu = ($c21t-$minc21)/($maxc21-$minc21)*100;
}

//C22
if(($c22p == $s1n) && ($c22p==$c22j) && ($c22p==$c22k) && ($c22p == $c22psth) && ($c22p==$c22pgogo) && ($c22p==$c22psrps) && ($c22p == $c22psrl) && ($c22p==$c22b) && ($c22p==$c22c) && ($c22p == $c22s) && ($c22p==$c22ka) && ($c22p==$c22t) && ($c22p==$c22r) && ($c22p==$c22set)){
    $c22padi = 100; $c22padisth = 100; $c22padisrl = 100; $c22sawit = 100; $c22rumput = 100;
    $c22jagung = 100; $c22padigogo = 100; $c22bawang = 100; $c22kakao = 100; $c22setaria = 100;
    $c22kedelai = 100; $c22padisrps = 100; $c22cabai = 100; $c22tebu = 100;
}else if(($c22p == $s2n) && ($c22p==$c22j) && ($c22p==$c22k) && ($c22p == $c22psth) && ($c22p==$c22pgogo) && ($c22p==$c22psrps) && ($c22p == $c22psrl) && ($c22p==$c22b) && ($c22p==$c22c) && ($c22p == $c22s) && ($c22p==$c22ka) && ($c22p==$c22t) && ($c22p==$c22r) && ($c22p==$c22set)){
    $c22padi = 66.6; $c22padisth = 66.6; $c22padisrl = 66.6; $c22sawit = 66.6; $c22rumput = 66.6;
    $c22jagung = 66.6; $c22padigogo = 66.6; $c22bawang = 66.6; $c22kakao = 66.6; $c22setaria = 66.6;
    $c22kedelai = 66.6; $c22padisrps = 66.6; $c22cabai = 66.6; $c22tebu = 66.6;
}else if(($c22p == $s3n) && ($c22p==$c22j) && ($c22p==$c22k) && ($c22p == $c22psth) && ($c22p==$c22pgogo) && ($c22p==$c22psrps) && ($c22p == $c22psrl) && ($c22p==$c22b) && ($c22p==$c22c) && ($c22p == $c22s) && ($c22p==$c22ka) && ($c22p==$c22t) && ($c22p==$c22r) && ($c22p==$c22set)){
    $c22padi = 33.3; $c22padisth = 33.3; $c22padisrl = 33.3; $c22sawit = 33.3; $c22rumput = 33.3;
    $c22jagung = 33.3; $c22padigogo = 33.3; $c22bawang = 33.3; $c22kakao = 33.3; $c22setaria = 33.3;
    $c22kedelai = 33.3; $c22padisrps = 33.3; $c22cabai = 33.3; $c22tebu = 33.3;
}else if(($c22p == $nn) && ($c22p==$c22j) && ($c22p==$c22k) && ($c22p == $c22psth) && ($c22p==$c22pgogo) && ($c22p==$c22psrps) && ($c22p == $c22psrl) && ($c22p==$c22b) && ($c22p==$c22c) && ($c22p == $c22s) && ($c22p==$c22ka) && ($c22p==$c22t) && ($c22p==$c22r) && ($c22p==$c22set)){
    $c22padi = 0; $c22padisth = 0; $c22padisrl = 0; $c22sawit = 0; $c22rumput = 0;
    $c22jagung = 0; $c22padigogo = 0; $c22bawang = 0; $c22kakao = 0; $c22setaria = 0;
    $c22kedelai = 0; $c22padisrps = 0; $c22cabai = 0; $c22tebu = 0;
}else {
    $c22padi = ($c22p-$minc22)/($maxc22-$minc22)*100; $c22padisth = ($c22psth-$minc22)/($maxc22-$minc22)*100; $c22padisrl = ($c22psrl-$minc22)/($maxc22-$minc22)*100; $c22sawit = ($c22s-$minc22)/($maxc22-$minc22)*100; $c22rumput = ($c22r-$minc22)/($maxc22-$minc22)*100;
    $c22jagung = ($c22j-$minc22)/($maxc22-$minc22)*100; $c22padigogo = ($c22pgogo-$minc22)/($maxc22-$minc22)*100; $c22bawang = ($c22b-$minc22)/($maxc22-$minc22)*100; $c22kakao = ($c22ka-$minc22)/($maxc22-$minc22)*100; $c22setaria = ($c22set-$minc22)/($maxc22-$minc22)*100;
    $c22kedelai = ($c22k-$minc22)/($maxc22-$minc22)*100; $c22padisrps = ($c22psrps-$minc22)/($maxc22-$minc22)*100; $c22cabai = ($c22c-$minc22)/($maxc22-$minc22)*100; $c22tebu = ($c22t-$minc22)/($maxc22-$minc22)*100;
}

//C23
if(($c23p == $s1n) && ($c23p==$c23j) && ($c23p==$c23k) && ($c23p == $c23psth) && ($c23p==$c23pgogo) && ($c23p==$c23psrps) && ($c23p == $c23psrl) && ($c23p==$c23b) && ($c23p==$c23c) && ($c23p == $c23s) && ($c23p==$c23ka) && ($c23p==$c23t) && ($c23p==$c23r) && ($c23p==$c23set)){
    $c23padi = 100; $c23padisth = 100; $c23padisrl = 100; $c23sawit = 100; $c23rumput = 100;
    $c23jagung = 100; $c23padigogo = 100; $c23bawang = 100; $c23kakao = 100; $c23setaria = 100;
    $c23kedelai = 100; $c23padisrps = 100; $c23cabai = 100; $c23tebu = 100;
}else if(($c23p == $s2n) && ($c23p==$c23j) && ($c23p==$c23k) && ($c23p == $c23psth) && ($c23p==$c23pgogo) && ($c23p==$c23psrps) && ($c23p == $c23psrl) && ($c23p==$c23b) && ($c23p==$c23c) && ($c23p == $c23s) && ($c23p==$c23ka) && ($c23p==$c23t) && ($c23p==$c23r) && ($c23p==$c23set)){
    $c23padi = 66.6; $c23padisth = 66.6; $c23padisrl = 66.6; $c23sawit = 66.6; $c23rumput = 66.6;
    $c23jagung = 66.6; $c23padigogo = 66.6; $c23bawang = 66.6; $c23kakao = 66.6; $c23setaria = 66.6;
    $c23kedelai = 66.6; $c23padisrps = 66.6; $c23cabai = 66.6; $c23tebu = 66.6;
}else if(($c23p == $s3n) && ($c23p==$c23j) && ($c23p==$c23k) && ($c23p == $c23psth) && ($c23p==$c23pgogo) && ($c23p==$c23psrps) && ($c23p == $c23psrl) && ($c23p==$c23b) && ($c23p==$c23c) && ($c23p == $c23s) && ($c23p==$c23ka) && ($c23p==$c23t) && ($c23p==$c23r) && ($c23p==$c23set)){
    $c23padi = 33.3; $c23padisth = 33.3; $c23padisrl = 33.3; $c23sawit = 33.3; $c23rumput = 33.3;
    $c23jagung = 33.3; $c23padigogo = 33.3; $c23bawang = 33.3; $c23kakao = 33.3; $c23setaria = 33.3;
    $c23kedelai = 33.3; $c23padisrps = 33.3; $c23cabai = 33.3; $c23tebu = 33.3;
}else if(($c23p == $nn) && ($c23p==$c23j) && ($c23p==$c23k) && ($c23p == $c23psth) && ($c23p==$c23pgogo) && ($c23p==$c23psrps) && ($c23p == $c23psrl) && ($c23p==$c23b) && ($c23p==$c23c) && ($c23p == $c23s) && ($c23p==$c23ka) && ($c23p==$c23t) && ($c23p==$c23r) && ($c23p==$c23set)){
    $c23padi = 0; $c23padisth = 0; $c23padisrl = 0; $c23sawit = 0; $c23rumput = 0;
    $c23jagung = 0; $c23padigogo = 0; $c23bawang = 0; $c23kakao = 0; $c23setaria = 0;
    $c23kedelai = 0; $c23padisrps = 0; $c23cabai = 0; $c23tebu = 0;
}else {
    $c23padi = ($c23p-$minc23)/($maxc23-$minc23)*100; $c23padisth = ($c23psth-$minc23)/($maxc23-$minc23)*100; $c23padisrl = ($c23psrl-$minc23)/($maxc23-$minc23)*100; $c23sawit = ($c23s-$minc23)/($maxc23-$minc23)*100; $c23rumput = ($c23r-$minc23)/($maxc23-$minc23)*100;
    $c23jagung = ($c23j-$minc23)/($maxc23-$minc23)*100; $c23padigogo = ($c23pgogo-$minc23)/($maxc23-$minc23)*100; $c23bawang = ($c23b-$minc23)/($maxc23-$minc23)*100; $c23kakao = ($c23ka-$minc23)/($maxc23-$minc23)*100; $c23setaria = ($c23set-$minc23)/($maxc23-$minc23)*100;
    $c23kedelai = ($c23k-$minc23)/($maxc23-$minc23)*100; $c23padisrps = ($c23psrps-$minc23)/($maxc23-$minc23)*100; $c23cabai = ($c23c-$minc23)/($maxc23-$minc23)*100; $c23tebu = ($c23t-$minc23)/($maxc23-$minc23)*100;
}

//C24
if(($c24p == $s1n) && ($c24p==$c24j) && ($c24p==$c24k) && ($c24p == $c24psth) && ($c24p==$c24pgogo) && ($c24p==$c24psrps) && ($c24p == $c24psrl) && ($c24p==$c24b) && ($c24p==$c24c) && ($c24p == $c24s) && ($c24p==$c24ka) && ($c24p==$c24t) && ($c24p==$c24r) && ($c24p==$c24set)){
    $c24padi = 100; $c24padisth = 100; $c24padisrl = 100; $c24sawit = 100; $c24rumput = 100;
    $c24jagung = 100; $c24padigogo = 100; $c24bawang = 100; $c24kakao = 100; $c24setaria = 100;
    $c24kedelai = 100; $c24padisrps = 100; $c24cabai = 100; $c24tebu = 100;
}else if(($c24p == $s2n) && ($c24p==$c24j) && ($c24p==$c24k) && ($c24p == $c24psth) && ($c24p==$c24pgogo) && ($c24p==$c24psrps) && ($c24p == $c24psrl) && ($c24p==$c24b) && ($c24p==$c24c) && ($c24p == $c24s) && ($c24p==$c24ka) && ($c24p==$c24t) && ($c24p==$c24r) && ($c24p==$c24set)){
    $c24padi = 66.6; $c24padisth = 66.6; $c24padisrl = 66.6; $c24sawit = 66.6; $c24rumput = 66.6;
    $c24jagung = 66.6; $c24padigogo = 66.6; $c24bawang = 66.6; $c24kakao = 66.6; $c24setaria = 66.6;
    $c24kedelai = 66.6; $c24padisrps = 66.6; $c24cabai = 66.6; $c24tebu = 66.6;
}else if(($c24p == $s3n) && ($c24p==$c24j) && ($c24p==$c24k) && ($c24p == $c24psth) && ($c24p==$c24pgogo) && ($c24p==$c24psrps) && ($c24p == $c24psrl) && ($c24p==$c24b) && ($c24p==$c24c) && ($c24p == $c24s) && ($c24p==$c24ka) && ($c24p==$c24t) && ($c24p==$c24r) && ($c24p==$c24set)){
    $c24padi = 33.3; $c24padisth = 33.3; $c24padisrl = 33.3; $c24sawit = 33.3; $c24rumput = 33.3;
    $c24jagung = 33.3; $c24padigogo = 33.3; $c24bawang = 33.3; $c24kakao = 33.3; $c24setaria = 33.3;
    $c24kedelai = 33.3; $c24padisrps = 33.3; $c24cabai = 33.3; $c24tebu = 33.3;
}else if(($c24p == $nn) && ($c24p==$c24j) && ($c24p==$c24k) && ($c24p == $c24psth) && ($c24p==$c24pgogo) && ($c24p==$c24psrps) && ($c24p == $c24psrl) && ($c24p==$c24b) && ($c24p==$c24c) && ($c24p == $c24s) && ($c24p==$c24ka) && ($c24p==$c24t) && ($c24p==$c24r) && ($c24p==$c24set)){
    $c24padi = 0; $c24padisth = 0; $c24padisrl = 0; $c24sawit = 0; $c24rumput = 0;
    $c24jagung = 0; $c24padigogo = 0; $c24bawang = 0; $c24kakao = 0; $c24setaria = 0;
    $c24kedelai = 0; $c24padisrps = 0; $c24cabai = 0; $c24tebu = 0;
}else {
    $c24padi = ($c24p-$minc24)/($maxc24-$minc24)*100; $c24padisth = ($c24psth-$minc24)/($maxc24-$minc24)*100; $c24padisrl = ($c24psrl-$minc24)/($maxc24-$minc24)*100; $c24sawit = ($c24s-$minc24)/($maxc24-$minc24)*100; $c24rumput = ($c24r-$minc24)/($maxc24-$minc24)*100;
    $c24jagung = ($c24j-$minc24)/($maxc24-$minc24)*100; $c24padigogo = ($c24pgogo-$minc24)/($maxc24-$minc24)*100; $c24bawang = ($c24b-$minc24)/($maxc24-$minc24)*100; $c24kakao = ($c24ka-$minc24)/($maxc24-$minc24)*100; $c24setaria = ($c24set-$minc24)/($maxc24-$minc24)*100;
    $c24kedelai = ($c24k-$minc24)/($maxc24-$minc24)*100; $c24padisrps = ($c24psrps-$minc24)/($maxc24-$minc24)*100; $c24cabai = ($c24c-$minc24)/($maxc24-$minc24)*100; $c24tebu = ($c24t-$minc24)/($maxc24-$minc24)*100;
}

//C25
if(($c25p == $s1n) && ($c25p==$c25j) && ($c25p==$c25k) && ($c25p == $c25psth) && ($c25p==$c25pgogo) && ($c25p==$c25psrps) && ($c25p == $c25psrl) && ($c25p==$c25b) && ($c25p==$c25c) && ($c25p == $c25s) && ($c25p==$c25ka) && ($c25p==$c25t) && ($c25p==$c25r) && ($c25p==$c25set)){
    $c25padi = 100; $c25padisth = 100; $c25padisrl = 100; $c25sawit = 100; $c25rumput = 100;
    $c25jagung = 100; $c25padigogo = 100; $c25bawang = 100; $c25kakao = 100; $c25setaria = 100;
    $c25kedelai = 100; $c25padisrps = 100; $c25cabai = 100; $c25tebu = 100;
}else if(($c25p == $s2n) && ($c25p==$c25j) && ($c25p==$c25k) && ($c25p == $c25psth) && ($c25p==$c25pgogo) && ($c25p==$c25psrps) && ($c25p == $c25psrl) && ($c25p==$c25b) && ($c25p==$c25c) && ($c25p == $c25s) && ($c25p==$c25ka) && ($c25p==$c25t) && ($c25p==$c25r) && ($c25p==$c25set)){
    $c25padi = 66.6; $c25padisth = 66.6; $c25padisrl = 66.6; $c25sawit = 66.6; $c25rumput = 66.6;
    $c25jagung = 66.6; $c25padigogo = 66.6; $c25bawang = 66.6; $c25kakao = 66.6; $c25setaria = 66.6;
    $c25kedelai = 66.6; $c25padisrps = 66.6; $c25cabai = 66.6; $c25tebu = 66.6;
}else if(($c25p == $s3n) && ($c25p==$c25j) && ($c25p==$c25k) && ($c25p == $c25psth) && ($c25p==$c25pgogo) && ($c25p==$c25psrps) && ($c25p == $c25psrl) && ($c25p==$c25b) && ($c25p==$c25c) && ($c25p == $c25s) && ($c25p==$c25ka) && ($c25p==$c25t) && ($c25p==$c25r) && ($c25p==$c25set)){
    $c25padi = 33.3; $c25padisth = 33.3; $c25padisrl = 33.3; $c25sawit = 33.3; $c25rumput = 33.3;
    $c25jagung = 33.3; $c25padigogo = 33.3; $c25bawang = 33.3; $c25kakao = 33.3; $c25setaria = 33.3;
    $c25kedelai = 33.3; $c25padisrps = 33.3; $c25cabai = 33.3; $c25tebu = 33.3;
}else if(($c25p == $nn) && ($c25p==$c25j) && ($c25p==$c25k) && ($c25p == $c25psth) && ($c25p==$c25pgogo) && ($c25p==$c25psrps) && ($c25p == $c25psrl) && ($c25p==$c25b) && ($c25p==$c25c) && ($c25p == $c25s) && ($c25p==$c25ka) && ($c25p==$c25t) && ($c25p==$c25r) && ($c25p==$c25set)){
    $c25padi = 0; $c25padisth = 0; $c25padisrl = 0; $c25sawit = 0; $c25rumput = 0;
    $c25jagung = 0; $c25padigogo = 0; $c25bawang = 0; $c25kakao = 0; $c25setaria = 0;
    $c25kedelai = 0; $c25padisrps = 0; $c25cabai = 0; $c25tebu = 0;
}else {
    $c25padi = ($c25p-$minc25)/($maxc25-$minc25)*100; $c25padisth = ($c25psth-$minc25)/($maxc25-$minc25)*100; $c25padisrl = ($c25psrl-$minc25)/($maxc25-$minc25)*100; $c25sawit = ($c25s-$minc25)/($maxc25-$minc25)*100; $c25rumput = ($c25r-$minc25)/($maxc25-$minc25)*100;
    $c25jagung = ($c25j-$minc25)/($maxc25-$minc25)*100; $c25padigogo = ($c25pgogo-$minc25)/($maxc25-$minc25)*100; $c25bawang = ($c25b-$minc25)/($maxc25-$minc25)*100; $c25kakao = ($c25ka-$minc25)/($maxc25-$minc25)*100; $c25setaria = ($c25set-$minc25)/($maxc25-$minc25)*100;
    $c25kedelai = ($c25k-$minc25)/($maxc25-$minc25)*100; $c25padisrps = ($c25psrps-$minc25)/($maxc25-$minc25)*100; $c25cabai = ($c25c-$minc25)/($maxc25-$minc25)*100; $c25tebu = ($c25t-$minc25)/($maxc25-$minc25)*100;
}


//Hasil

$hpadi = ($c1padi*0.04) + ($c2padi*0.04) + ($c3padi*0.04) + ($c4padi*0.04) + ($c5padi*0.04) + ($c6padi*0.04) + ($c7padi*0.04) + ($c8padi*0.04) + ($c9padi*0.04) + ($c10padi*0.04) +($c11padi*0.04) + ($c12padi*0.04) + ($c13padi*0.04) + ($c14padi*0.04) + ($c15padi*0.04) + ($c16padi*0.04) + ($c17padi*0.04) + ($c18padi*0.04) + ($c19padi*0.04) + ($c20padi*0.04) + ($c21padi*0.04) + ($c22padi*0.04) + ($c23padi*0.04) + ($c24padi*0.04) + ($c25padi*0.04);
$hjagung = ($c1jagung*0.04) + ($c2jagung*0.04) + ($c3jagung*0.04) + ($c4jagung*0.04) + ($c5jagung*0.04) + ($c6jagung*0.04) + ($c7jagung*0.04) + ($c8jagung*0.04) + ($c9jagung*0.04) + ($c10jagung*0.04) +($c11jagung*0.04) + ($c12jagung*0.04) + ($c13jagung*0.04) + ($c14jagung*0.04) + ($c15jagung*0.04) + ($c16jagung*0.04) + ($c17jagung*0.04) + ($c18jagung*0.04) + ($c19jagung*0.04) + ($c20jagung*0.04) + ($c21jagung*0.04) + ($c22jagung*0.04) + ($c23jagung*0.04) + ($c24jagung*0.04) + ($c25jagung*0.04);
$hkedelai = ($c1kedelai*0.04) + ($c2kedelai*0.04) + ($c3kedelai*0.04) + ($c4kedelai*0.04) + ($c5kedelai*0.04) + ($c6kedelai*0.04) + ($c7kedelai*0.04) + ($c8kedelai*0.04) + ($c9kedelai*0.04) + ($c10kedelai*0.04) +($c11kedelai*0.04) + ($c12kedelai*0.04) + ($c13kedelai*0.04) + ($c14kedelai*0.04) + ($c15kedelai*0.04) + ($c16kedelai*0.04) + ($c17kedelai*0.04) + ($c18kedelai*0.04) + ($c19kedelai*0.04) + ($c20kedelai*0.04) + ($c21kedelai*0.04) + ($c22kedelai*0.04) + ($c23kedelai*0.04) + ($c24kedelai*0.04) + ($c25jagung*0.04);
$hpadisth = ($c1padisth*0.04) + ($c2padisth*0.04) + ($c3padisth*0.04) + ($c4padisth*0.04) + ($c5padisth*0.04) + ($c6padisth*0.04) + ($c7padisth*0.04) + ($c8padisth*0.04) + ($c9padisth*0.04) + ($c10padisth*0.04) +($c11padisth*0.04) + ($c12padisth*0.04) + ($c13padisth*0.04) + ($c14padisth*0.04) + ($c15padisth*0.04) + ($c16padisth*0.04) + ($c17padisth*0.04) + ($c18padisth*0.04) + ($c19padisth*0.04) + ($c20padisth*0.04) + ($c21padisth*0.04) + ($c22padisth*0.04) + ($c23padisth*0.04) + ($c24padisth*0.04) + ($c25padisth*0.04);
$hpadigogo = ($c1padigogo*0.04) + ($c2padigogo*0.04) + ($c3padigogo*0.04) + ($c4padigogo*0.04) + ($c5padigogo*0.04) + ($c6padigogo*0.04) + ($c7padigogo*0.04) + ($c8padigogo*0.04) + ($c9padigogo*0.04) + ($c10padigogo*0.04) +($c11padigogo*0.04) + ($c12padigogo*0.04) + ($c13padigogo*0.04) + ($c14padigogo*0.04) + ($c15padigogo*0.04) + ($c16padigogo*0.04) + ($c17padigogo*0.04) + ($c18padigogo*0.04) + ($c19padigogo*0.04) + ($c20padigogo*0.04) + ($c21padigogo*0.04) + ($c22padigogo*0.04) + ($c23padigogo*0.04) + ($c24padigogo*0.04) + ($c25padigogo*0.04);
$hpadisrps = ($c1padisrps*0.04) + ($c2padisrps*0.04) + ($c3padisrps*0.04) + ($c4padisrps*0.04) + ($c5padisrps*0.04) + ($c6padisrps*0.04) + ($c7padisrps*0.04) + ($c8padisrps*0.04) + ($c9padisrps*0.04) + ($c10padisrps*0.04) +($c11padisrps*0.04) + ($c12padisrps*0.04) + ($c13padisrps*0.04) + ($c14padisrps*0.04) + ($c15padisrps*0.04) + ($c16padisrps*0.04) + ($c17padisrps*0.04) + ($c18padisrps*0.04) + ($c19padisrps*0.04) + ($c20padisrps*0.04) + ($c21padisrps*0.04) + ($c22padisrps*0.04) + ($c23padisrps*0.04) + ($c24padisrps*0.04) + ($c25padisrps*0.04);
$hpadisrl = ($c1padisrl*0.04) + ($c2padisrl*0.04) + ($c3padisrl*0.04) + ($c4padisrl*0.04) + ($c5padisrl*0.04) + ($c6padisrl*0.04) + ($c7padisrl*0.04) + ($c8padisrl*0.04) + ($c9padisrl*0.04) + ($c10padisrl*0.04) +($c11padisrl*0.04) + ($c12padisrl*0.04) + ($c13padisrl*0.04) + ($c14padisrl*0.04) + ($c15padisrl*0.04) + ($c16padisrl*0.04) + ($c17padisrl*0.04) + ($c18padisrl*0.04) + ($c19padisrl*0.04) + ($c20padisrl*0.04) + ($c21padisrl*0.04) + ($c22padisrl*0.04) + ($c23padisrl*0.04) + ($c24padisrl*0.04) + ($c25padisrl*0.04);
$hbawang = ($c1bawang*0.04) + ($c2bawang*0.04) + ($c3bawang*0.04) + ($c4bawang*0.04) + ($c5bawang*0.04) + ($c6bawang*0.04) + ($c7bawang*0.04) + ($c8bawang*0.04) + ($c9bawang*0.04) + ($c10bawang*0.04) +($c11bawang*0.04) + ($c12bawang*0.04) + ($c13bawang*0.04) + ($c14bawang*0.04) + ($c15bawang*0.04) + ($c16bawang*0.04) + ($c17bawang*0.04) + ($c18bawang*0.04) + ($c19bawang*0.04) + ($c20bawang*0.04) + ($c21bawang*0.04) + ($c22bawang*0.04) + ($c23bawang*0.04) + ($c24bawang*0.04) + ($c25bawang*0.04);
$hcabai = ($c1cabai*0.04) + ($c2cabai*0.04) + ($c3cabai*0.04) + ($c4cabai*0.04) + ($c5cabai*0.04) + ($c6cabai*0.04) + ($c7cabai*0.04) + ($c8cabai*0.04) + ($c9cabai*0.04) + ($c10cabai*0.04) +($c11cabai*0.04) + ($c12cabai*0.04) + ($c13cabai*0.04) + ($c14cabai*0.04) + ($c15cabai*0.04) + ($c16cabai*0.04) + ($c17cabai*0.04) + ($c18cabai*0.04) + ($c19cabai*0.04) + ($c20cabai*0.04) + ($c21cabai*0.04) + ($c22cabai*0.04) + ($c23cabai*0.04) + ($c24cabai*0.04) + ($c25cabai*0.04);
$hsawit = ($c1sawit*0.04) + ($c2sawit*0.04) + ($c3sawit*0.04) + ($c4sawit*0.04) + ($c5sawit*0.04) + ($c6sawit*0.04) + ($c7sawit*0.04) + ($c8sawit*0.04) + ($c9sawit*0.04) + ($c10sawit*0.04) +($c11sawit*0.04) + ($c12sawit*0.04) + ($c13sawit*0.04) + ($c14sawit*0.04) + ($c15sawit*0.04) + ($c16sawit*0.04) + ($c17sawit*0.04) + ($c18sawit*0.04) + ($c19sawit*0.04) + ($c20sawit*0.04) + ($c21sawit*0.04) + ($c22sawit*0.04) + ($c23sawit*0.04) + ($c24sawit*0.04) + ($c25sawit*0.04);
$hkakao = ($c1kakao*0.04) + ($c2kakao*0.04) + ($c3kakao*0.04) + ($c4kakao*0.04) + ($c5kakao*0.04) + ($c6kakao*0.04) + ($c7kakao*0.04) + ($c8kakao*0.04) + ($c9kakao*0.04) + ($c10kakao*0.04) +($c11kakao*0.04) + ($c12kakao*0.04) + ($c13kakao*0.04) + ($c14kakao*0.04) + ($c15kakao*0.04) + ($c16kakao*0.04) + ($c17kakao*0.04) + ($c18kakao*0.04) + ($c19kakao*0.04) + ($c20kakao*0.04) + ($c21kakao*0.04) + ($c22kakao*0.04) + ($c23kakao*0.04) + ($c24kakao*0.04) + ($c25kakao*0.04);
$htebu = ($c1tebu*0.04) + ($c2tebu*0.04) + ($c3tebu*0.04) + ($c4tebu*0.04) + ($c5tebu*0.04) + ($c6tebu*0.04) + ($c7tebu*0.04) + ($c8tebu*0.04) + ($c9tebu*0.04) + ($c10tebu*0.04) +($c11tebu*0.04) + ($c12tebu*0.04) + ($c13tebu*0.04) + ($c14tebu*0.04) + ($c15tebu*0.04) + ($c16tebu*0.04) + ($c17tebu*0.04) + ($c18tebu*0.04) + ($c19tebu*0.04) + ($c20tebu*0.04) + ($c21tebu*0.04) + ($c22tebu*0.04) + ($c23tebu*0.04) + ($c24tebu*0.04) + ($c25tebu*0.04);
$hrumput = ($c1rumput*0.04) + ($c2rumput*0.04) + ($c3rumput*0.04) + ($c4rumput*0.04) + ($c5rumput*0.04) + ($c6rumput*0.04) + ($c7rumput*0.04) + ($c8rumput*0.04) + ($c9rumput*0.04) + ($c10rumput*0.04) +($c11rumput*0.04) + ($c12rumput*0.04) + ($c13rumput*0.04) + ($c14rumput*0.04) + ($c15rumput*0.04) + ($c16rumput*0.04) + ($c17rumput*0.04) + ($c18rumput*0.04) + ($c19rumput*0.04) + ($c20rumput*0.04) + ($c21rumput*0.04) + ($c22rumput*0.04) + ($c23rumput*0.04) + ($c24rumput*0.04) + ($c25rumput*0.04);
$hsetaria = ($c1setaria*0.04) + ($c2setaria*0.04) + ($c3setaria*0.04) + ($c4setaria*0.04) + ($c5setaria*0.04) + ($c6setaria*0.04) + ($c7setaria*0.04) + ($c8setaria*0.04) + ($c9setaria*0.04) + ($c10setaria*0.04) +($c11setaria*0.04) + ($c12setaria*0.04) + ($c13setaria*0.04) + ($c14setaria*0.04) + ($c15setaria*0.04) + ($c16setaria*0.04) + ($c17setaria*0.04) + ($c18setaria*0.04) + ($c19setaria*0.04) + ($c20setaria*0.04) + ($c21setaria*0.04) + ($c22setaria*0.04) + ($c23setaria*0.04) + ($c24setaria*0.04) + ($c25setaria*0.04);



$sql1="insert into ds_smart (nama_tanaman, nilai) values ('Setaria','$hsetaria')";
$hasil1=mysqli_query($kon,$sql1);
$sql2="insert into ds_smart (nama_tanaman, nilai) values ('Rumput Gajah','$hrumput')";
$hasil2=mysqli_query($kon,$sql2);
$sql3="insert into ds_smart (nama_tanaman, nilai) values ('Tebu','$htebu')";
$hasil3=mysqli_query($kon,$sql3);
$sql4="insert into ds_smart (nama_tanaman, nilai) values ('Kakao','$hkakao')";
$hasil4=mysqli_query($kon,$sql4);
$sql5="insert into ds_smart (nama_tanaman, nilai) values ('Kelapa Sawit','$hsawit')"; 
$hasi5=mysqli_query($kon,$sql5);
$sql6="insert into ds_smart (nama_tanaman, nilai) values ('Cabai Merah','$hcabai')";
$hasil6=mysqli_query($kon,$sql6);
$sql7="insert into ds_smart (nama_tanaman, nilai) values ('Bawang Merah','$hbawang')";
$hasil7=mysqli_query($kon,$sql7);
$sql8="insert into ds_smart (nama_tanaman, nilai) values ('Kedelai','$hkedelai')";
$hasil8=mysqli_query($kon,$sql8);
$sql9="insert into ds_smart (nama_tanaman, nilai) values ('Jagung','$hjagung')";
$hasil9=mysqli_query($kon,$sql9);
$sql10="insert into ds_smart (nama_tanaman, nilai) values ('Padi Sawah Rawa Lebak','$hpadisrl')"; 
$hasil10=mysqli_query($kon,$sql10);
$sql11="insert into ds_smart (nama_tanaman, nilai) values ('Padi Sawah Rawa Pasang Surut','$hpadisrps')";
$hasil1=mysqli_query($kon,$sql11);
$sql12="insert into ds_smart (nama_tanaman, nilai) values ('Padi Gogo','$hpadigogo')";
$hasil2=mysqli_query($kon,$sql12);
$sql13="insert into ds_smart (nama_tanaman, nilai) values ('Padi Sawah Tadah Hujan','$hpadisth')"; 
$hasil3=mysqli_query($kon,$sql13);
$sql14="insert into ds_smart (nama_tanaman, nilai) values ('Padi Sawah Irigasi','$hpadi')"; 
$hasil14=mysqli_query($kon,$sql14);



?>