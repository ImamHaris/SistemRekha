<?php

//Padi
$hppadi = ($c1p+$c2p+$c3p+$c4p+$c5p+$c6p+$c7p+$c8p+$c9p+$c10p+$c11p+$c12p+$c13p+$c14p+$c15p+$c16p+$c17p+$c18p+$c19p+$c20p+$c21p+$c22p+$c23p+$c24p+$c25p);

//Jagung
$hpjagung = ($c1j+$c2j+$c3j+$c4j+$c5j+$c6j+$c7j+$c8j+$c9j+$c10j+$c11j+$c12j+$c13j+$c14j+$c15j+$c16j+$c17j+$c18j+$c19j+$c20j+$c21j+$c22j+$c23j+$c24j+$c25j);

//Kedelai
$hpkedelai = ($c1k+$c2k+$c3k+$c4k+$c5k+$c6k+$c7k+$c8k+$c9k+$c10k+$c11k+$c12k+$c13k+$c14k+$c15k+$c16k+$c17k+$c18k+$c19k+$c20k+$c21k+$c22k+$c23k+$c24k+$c25k);

//Padisth
$hppadisth = ($c1psth+$c2psth+$c3psth+$c4psth+$c5psth+$c6psth+$c7psth+$c8psth+$c9psth+$c10psth+$c11psth+$c12psth+$c13psth+$c14psth+$c15psth+$c16psth+$c17psth+$c18psth+$c19psth+$c20psth+$c21psth+$c22psth+$c23psth+$c24psth+$c25psth);

//Padigogo
$hppadigogo = ($c1pgogo+$c2pgogo+$c3pgogo+$c4pgogo+$c5pgogo+$c6pgogo+$c7pgogo+$c8pgogo+$c9pgogo+$c10pgogo+$c11pgogo+$c12pgogo+$c13pgogo+$c14pgogo+$c15pgogo+$c16pgogo+$c17pgogo+$c18pgogo+$c19pgogo+$c20pgogo+$c21pgogo+$c22pgogo+$c23pgogo+$c24pgogo+$c25pgogo);

//Padisrps
$hppadisrps = ($c1psrps+$c2psrps+$c3psrps+$c4psrps+$c5psrps+$c6psrps+$c7psrps+$c8psrps+$c9psrps+$c10psrps+$c11psrps+$c12psrps+$c13psrps+$c14psrps+$c15psrps+$c16psrps+$c17psrps+$c18psrps+$c19psrps+$c20psrps+$c21psrps+$c22psrps+$c23psrps+$c24psrps+$c25psrps);

//Padisrl
$hppadisrl = ($c1psrl+$c2psrl+$c3psrl+$c4psrl+$c5psrl+$c6psrl+$c7psrl+$c8psrl+$c9psrl+$c10psrl+$c11psrl+$c12psrl+$c13psrl+$c14psrl+$c15psrl+$c16psrl+$c17psrl+$c18psrl+$c19psrl+$c20psrl+$c21psrl+$c22psrl+$c23psrl+$c24psrl+$c25psrl);

//Bawang
$hpbawang = ($c1b+$c2b+$c3b+$c4b+$c5b+$c6b+$c7b+$c8b+$c9b+$c10b+$c11b+$c12b+$c13b+$c14b+$c15b+$c16b+$c17b+$c18b+$c19b+$c20b+$c21b+$c22b+$c23b+$c24b+$c25b);

//Cabai
$hpcabai = ($c1c+$c2c+$c3c+$c4c+$c5c+$c6c+$c7c+$c8c+$c9c+$c10c+$c11c+$c12c+$c13c+$c14c+$c15c+$c16c+$c17c+$c18c+$c19c+$c20c+$c21c+$c22c+$c23c+$c24c+$c25c);

//Sawit
$hpsawit = ($c1s+$c2s+$c3s+$c4s+$c5s+$c6s+$c7s+$c8s+$c9s+$c10s+$c11s+$c12s+$c13s+$c14s+$c15s+$c16s+$c17s+$c18s+$c19s+$c20s+$c21s+$c22s+$c23s+$c24s+$c25s);

//Kakao
$hpkakao = ($c1ka+$c2ka+$c3ka+$c4ka+$c5ka+$c6ka+$c7ka+$c8ka+$c9ka+$c10ka+$c11ka+$c12ka+$c13ka+$c14ka+$c15ka+$c16ka+$c17ka+$c18ka+$c19ka+$c20ka+$c21ka+$c22ka+$c23ka+$c24ka+$c25ka);

//Tebu
$hptebu = ($c1t+$c2t+$c3t+$c4t+$c5t+$c6t+$c7t+$c8t+$c9t+$c10t+$c11t+$c12t+$c13t+$c14t+$c15t+$c16t+$c17t+$c18t+$c19t+$c20t+$c21t+$c22t+$c23t+$c24t+$c25t);

//Rumput
$hprumput = ($c1r+$c2r+$c3r+$c4r+$c5r+$c6r+$c7r+$c8r+$c9r+$c10r+$c11r+$c12r+$c13r+$c14r+$c15r+$c16r+$c17r+$c18r+$c19r+$c20r+$c21r+$c22r+$c23r+$c24r+$c25r);

//Setaria
$hpsetaria = ($c1set+$c2set+$c3set+$c4set+$c5set+$c6set+$c7set+$c8set+$c9set+$c10set+$c11set+$c12set+$c13set+$c14set+$c15set+$c16set+$c17set+$c18set+$c19set+$c20set+$c21set+$c22set+$c23set+$c24set+$c25set);

if($hppadi==0){
    $kelaspadi = 'Tidak Diisi';
}else if($hppadi>=1 && $hppadi<=25){
    $kelaspadi = 'S1 (Sangat Sesuai)';
}else if ($hppadi>=25 && $hppadi <=50){
    $kelaspadi = 'S2 (Cukup Sesuai)';
}else if ($hppadi>=50 && $hppadi <=675){
    $kelaspadi = 'S3 (Sesuai Marginal)';
}else if ($hppadi>=675){
    $kelaspadi = 'N (Tidak Sesuai)';
}

if($hppadisth==0){
    $kelaspadisth = 'Tidak Diisi';
}else if($hppadisth>=1 && $hppadisth<=25){
    $kelaspadisth = 'S1 (Sangat Sesuai)';
}else if ($hppadisth>=25 && $hppadisth <=50){
    $kelaspadisth = 'S2 (Cukup Sesuai)';
}else if ($hppadisth>=50 && $hppadisth <=675){
    $kelaspadisth = 'S3 (Sesuai Marginal)';
}else if ($hppadisth>=675){
    $kelaspadisth = 'N (Tidak Sesuai)';
}

if($hppadigogo==0){
    $kelaspadigogo = 'Tidak Diisi';
}else if($hppadigogo>=1 && $hppadigogo<=25){
    $kelaspadigogo = 'S1 (Sangat Sesuai)';
}else if ($hppadigogo>=25 && $hppadigogo <=50){
    $kelaspadigogo = 'S2 (Cukup Sesuai)';
}else if ($hppadigogo>=50 && $hppadigogo <=675){
    $kelaspadigogo = 'S3 (Sesuai Marginal)';
}else if ($hppadigogo>=675){
    $kelaspadigogo = 'N (Tidak Sesuai)';
}

if($hppadisrps==0){
    $kelaspadisrps = 'Tidak Diisi';
}else if($hppadisrps>=1 && $hppadisrps<=25){
    $kelaspadisrps = 'S1 (Sangat Sesuai)';
}else if ($hppadisrps>=25 && $hppadisrps <=50){
    $kelaspadisrps = 'S2 (Cukup Sesuai)';
}else if ($hppadisrps>=50 && $hppadisrps <=675){
    $kelaspadisrps = 'S3 (Sesuai Marginal)';
}else if ($hppadisrps>=675){
    $kelaspadisrps = 'N (Tidak Sesuai)';
}

if($hppadisrl==0){
    $kelaspadisrl = 'Tidak Diisi';
}else if($hppadisrl>=1 && $hppadisrl<=25){
    $kelaspadisrl = 'S1 (Sangat Sesuai)';
}else if ($hppadisrl>=25 && $hppadisrl <=50){
    $kelaspadisrl = 'S2 (Cukup Sesuai)';
}else if ($hppadisrl>=50 && $hppadisrl <=675){
    $kelaspadisrl = 'S3 (Sesuai Marginal)';
}else if ($hppadisrl>=675){
    $kelaspadisrl = 'N (Tidak Sesuai)';
}

if($hpjagung==0){
    $kelasjagung = 'Tidak Diisi';
}else if($hpjagung>=1 && $hpjagung<=25){
    $kelasjagung = 'S1 (Sangat Sesuai)';
}else if ($hpjagung>=25 && $hpjagung <=50){
    $kelasjagung = 'S2 (Cukup Sesuai)';
}else if ($hpjagung>=50 && $hpjagung <=675){
    $kelasjagung = 'S3 (Sesuai Marginal)';
}else if ($hpjagung>=675){
    $kelasjagung = 'N (Tidak Sesuai)';
}

if($hpkedelai==0){
    $kelaskedelai = 'Tidak Diisi';
}else if($hpkedelai>=1 && $hpkedelai<=25){
    $kelaskedelai = 'S1 (Sangat Sesuai)';
}else if ($hpkedelai>=25 && $hpkedelai <=50){
    $kelaskedelai = 'S2 (Cukup Sesuai)';
}else if ($hpkedelai>=50 && $hpkedelai <=675){
    $kelaskedelai = 'S3 (Sesuai Marginal)';
}else if ($hpkedelai>=675){
    $kelaskedelai = 'N (Tidak Sesuai)';
}

if($hpbawang==0){
    $kelasbawang = 'Tidak Diisi';
}else if($hpbawang>=1 && $hpbawang<=25){
    $kelasbawang = 'S1 (Sangat Sesuai)';
}else if ($hpbawang>=25 && $hpbawang <=50){
    $kelasbawang = 'S2 (Cukup Sesuai)';
}else if ($hpbawang>=50 && $hpbawang <=675){
    $kelasbawang = 'S3 (Sesuai Marginal)';
}else if ($hpbawang>=675){
    $kelasbawang = 'N (Tidak Sesuai)';
}

if($hpcabai==0){
    $kelascabai = 'Tidak Diisi';
}else if($hpcabai>=1 && $hpcabai<=25){
    $kelascabai = 'S1 (Sangat Sesuai)';
}else if ($hpcabai>=25 && $hpcabai <=50){
    $kelascabai = 'S2 (Cukup Sesuai)';
}else if ($hpcabai>=50 && $hpcabai <=675){
    $kelascabai = 'S3 (Sesuai Marginal)';
}else if ($hpcabai>=675){
    $kelascabai = 'N (Tidak Sesuai)';
}

if($hpsawit==0){
    $kelassawit = 'Tidak Diisi';
}else if($hpsawit>=1 && $hpsawit<=25){
    $kelassawit = 'S1 (Sangat Sesuai)';
}else if ($hpsawit>=25 && $hpsawit <=50){
    $kelassawit = 'S2 (Cukup Sesuai)';
}else if ($hpsawit>=50 && $hpsawit <=675){
    $kelassawit = 'S3 (Sesuai Marginal)';
}else if ($hpsawit>=675){
    $kelassawit = 'N (Tidak Sesuai)';
}

if($hpkakao==0){
    $kelaskakao = 'Tidak Diisi';
}else if($hpkakao>=1 && $hpkakao<=25){
    $kelaskakao = 'S1 (Sangat Sesuai)';
}else if ($hpkakao>=25 && $hpkakao <=50){
    $kelaskakao = 'S2 (Cukup Sesuai)';
}else if ($hpkakao>=50 && $hpkakao <=675){
    $kelaskakao = 'S3 (Sesuai Marginal)';
}else if ($hpkakao>=675){
    $kelaskakao = 'N (Tidak Sesuai)';
}

if($hptebu==0){
    $kelastebu = 'Tidak Diisi';
}else if($hptebu>=1 && $hptebu<=25){
    $kelastebu = 'S1 (Sangat Sesuai)';
}else if ($hptebu>=25 && $hptebu <=50){
    $kelastebu = 'S2 (Cukup Sesuai)';
}else if ($hptebu>=50 && $hptebu <=675){
    $kelastebu = 'S3 (Sesuai Marginal)';
}else if ($hptebu>=675){
    $kelastebu = 'N (Tidak Sesuai)';
}

if($hprumput==0){
    $kelasrumput = 'Tidak Diisi';
}else if($hprumput>=1 && $hprumput<=25){
    $kelasrumput = 'S1 (Sangat Sesuai)';
}else if ($hprumput>=25 && $hprumput <=50){
    $kelasrumput = 'S2 (Cukup Sesuai)';
}else if ($hprumput>=50 && $hprumput <=675){
    $kelasrumput = 'S3 (Sesuai Marginal)';
}else if ($hprumput>=675){
    $kelasrumput = 'N (Tidak Sesuai)';
}

if($hpsetaria==0){
    $kelassetaria = 'Tidak Diisi';
}else if($hpsetaria>=1 && $hpsetaria<=25){
    $kelassetaria = 'S1 (Sangat Sesuai)';
}else if ($hpsetaria>=25 && $hpsetaria <=50){
    $kelassetaria = 'S2 (Cukup Sesuai)';
}else if ($hpsetaria>=50 && $hpsetaria <=675){
    $kelassetaria = 'S3 (Sesuai Marginal)';
}else if ($hpsetaria>=675){
    $kelassetaria = 'N (Tidak Sesuai)';
}




$sqlsp1="insert into ds_pakar (nama_tanaman, nilai , kelas) values ('Padi Sawah Irigasi','$hppadi','$kelaspadi')"; 
$hasilsp1=mysqli_query($kon,$sqlsp1);
$sqlsp4="insert into ds_pakar (nama_tanaman, nilai , kelas) values ('Padi Sawah Tadah Hujan','$hppadisth','$kelaspadisth')"; 
$hasilsp4=mysqli_query($kon,$sqlsp4);
$sqlsp5="insert into ds_pakar (nama_tanaman, nilai , kelas) values ('Padi Gogo','$hppadigogo','$kelaspadigogo')";
$hasilsp5=mysqli_query($kon,$sqlsp5);
$sqlsp6="insert into ds_pakar (nama_tanaman, nilai , kelas) values ('Padi Sawah Rawa Pasang Surut','$hppadisrps','$kelaspadisrps')";
$hasilsp6=mysqli_query($kon,$sqlsp6);
$sqlsp7="insert into ds_pakar (nama_tanaman, nilai , kelas) values ('Padi Sawah Rawa Lebak','$hppadisrl','$kelaspadisrl')"; 
$hasilsp7=mysqli_query($kon,$sqlsp7);
$sqlsp2="insert into ds_pakar (nama_tanaman, nilai , kelas) values ('Jagung','$hpjagung','$kelasjagung')";
$hasilsp2=mysqli_query($kon,$sqlsp2);
$sqlsp3="insert into ds_pakar (nama_tanaman, nilai , kelas) values ('Kedelai','$hpkedelai','$kelaskedelai')";
$hasilsp3=mysqli_query($kon,$sqlsp3);
$sqlsp8="insert into ds_pakar (nama_tanaman, nilai , kelas) values ('Bawang Merah','$hpbawang','$kelasbawang')";
$hasilsp8=mysqli_query($kon,$sqlsp8);
$sqlsp9="insert into ds_pakar (nama_tanaman, nilai , kelas) values ('Cabai Merah','$hpcabai','$kelascabai')";
$hasilsp9=mysqli_query($kon,$sqlsp9);
$sqlsp10="insert into ds_pakar (nama_tanaman, nilai , kelas) values ('Kelapa Sawit','$hpsawit','$kelassawit')"; 
$hasilsp10=mysqli_query($kon,$sqlsp10);
$sqlsp11="insert into ds_pakar (nama_tanaman, nilai , kelas) values ('Kakao','$hpkakao','$kelaskakao')";
$hasilsp11=mysqli_query($kon,$sqlsp11);
$sqlsp12="insert into ds_pakar (nama_tanaman, nilai , kelas) values ('Tebu','$hptebu','$kelastebu')";
$hasilsp12=mysqli_query($kon,$sqlsp12);
$sqlsp13="insert into ds_pakar (nama_tanaman, nilai , kelas) values ('Rumput Gajah','$hprumput','$kelasrumput')";
$hasilsp13=mysqli_query($kon,$sqlsp13);
$sqlsp14="insert into ds_pakar (nama_tanaman, nilai , kelas) values ('Setaria','$hpsetaria','$kelassetaria')";
$hasilsp14=mysqli_query($kon,$sqlsp14);


?>