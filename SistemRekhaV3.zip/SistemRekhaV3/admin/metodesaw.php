<?php

//C1
$c1spadi = $c1p/$maxc1; $c1spadisth = $c1psth/$maxc1; $c1spadisrl = $c1psrl/$maxc1; $c1ssawit = $c1s/$maxc1; $c1srumput = $c1r/$maxc1;
$c1sjagung = $c1j/$maxc1; $c1spadigogo = $c1pgogo/$maxc1; $c1sbawang = $c1b/$maxc1; $c1skakao = $c1ka/$maxc1; $c1ssetaria = $c1set/$maxc1;
$c1skedelai = $c1k/$maxc1; $c1spadisrps = $c1psrps/$maxc1; $c1scabai = $c1c/$maxc1; $c1stebu = $c1t/$maxc1;

//C2
$c2spadi = $c2p/$maxc2; $c2spadisth = $c2psth/$maxc2; $c2spadisrl = $c2psrl/$maxc2; $c2ssawit = $c2s/$maxc2; $c2srumput = $c2r/$maxc2;
$c2sjagung = $c2j/$maxc2; $c2spadigogo = $c2pgogo/$maxc2; $c2sbawang = $c2b/$maxc2; $c2skakao = $c2ka/$maxc2; $c2ssetaria = $c2set/$maxc2;
$c2skedelai = $c2k/$maxc2; $c2spadisrps = $c2psrps/$maxc2; $c2scabai = $c2c/$maxc2; $c2stebu = $c2t/$maxc2;

//C3
$c3spadi = $c3p/$maxc3; $c3spadisth = $c3psth/$maxc3; $c3spadisrl = $c3psrl/$maxc3; $c3ssawit = $c3s/$maxc3; $c3srumput = $c3r/$maxc3;
$c3sjagung = $c3j/$maxc3; $c3spadigogo = $c3pgogo/$maxc3; $c3sbawang = $c3b/$maxc3; $c3skakao = $c3ka/$maxc3; $c3ssetaria = $c3set/$maxc3;
$c3skedelai = $c3k/$maxc3; $c3spadisrps = $c3psrps/$maxc3; $c3scabai = $c3c/$maxc3; $c3stebu = $c3t/$maxc3;

//C4
$c4spadi = $c4p/$maxc4; $c4spadisth = $c4psth/$maxc4; $c4spadisrl = $c4psrl/$maxc4; $c4ssawit = $c4s/$maxc4; $c4srumput = $c4r/$maxc4;
$c4sjagung = $c4j/$maxc4; $c4spadigogo = $c4pgogo/$maxc4; $c4sbawang = $c4b/$maxc4; $c4skakao = $c4ka/$maxc4; $c4ssetaria = $c4set/$maxc4;
$c4skedelai = $c4k/$maxc4; $c4spadisrps = $c4psrps/$maxc4; $c4scabai = $c4c/$maxc4; $c4stebu = $c4t/$maxc4;

//C5
$c5spadi = $c5p/$maxc5; $c5spadisth = $c5psth/$maxc5; $c5spadisrl = $c5psrl/$maxc5; $c5ssawit = $c5s/$maxc5; $c5srumput = $c5r/$maxc5;
$c5sjagung = $c5j/$maxc5; $c5spadigogo = $c5pgogo/$maxc5; $c5sbawang = $c5b/$maxc5; $c5skakao = $c5ka/$maxc5; $c5ssetaria = $c5set/$maxc5;
$c5skedelai = $c5k/$maxc5; $c5spadisrps = $c5psrps/$maxc5; $c5scabai = $c5c/$maxc5; $c5stebu = $c5t/$maxc5;

//C6
$c6spadi = $c6p/$maxc6; $c6spadisth = $c6psth/$maxc6; $c6spadisrl = $c6psrl/$maxc6; $c6ssawit = $c6s/$maxc6; $c6srumput = $c6r/$maxc6;
$c6sjagung = $c6j/$maxc6; $c6spadigogo = $c6pgogo/$maxc6; $c6sbawang = $c6b/$maxc6; $c6skakao = $c6ka/$maxc6; $c6ssetaria = $c6set/$maxc6;
$c6skedelai = $c6k/$maxc6; $c6spadisrps = $c6psrps/$maxc6; $c6scabai = $c6c/$maxc6; $c6stebu = $c6t/$maxc6;

//C7
$c7spadi = $c7p/$maxc7; $c7spadisth = $c7psth/$maxc7; $c7spadisrl = $c7psrl/$maxc7; $c7ssawit = $c7s/$maxc7; $c7srumput = $c7r/$maxc7;
$c7sjagung = $c7j/$maxc7; $c7spadigogo = $c7pgogo/$maxc7; $c7sbawang = $c7b/$maxc7; $c7skakao = $c7ka/$maxc7; $c7ssetaria = $c7set/$maxc7;
$c7skedelai = $c7k/$maxc7; $c7spadisrps = $c7psrps/$maxc7; $c7scabai = $c7c/$maxc7; $c7stebu = $c7t/$maxc7;

//C8
$c8spadi = $c8p/$maxc8; $c8spadisth = $c8psth/$maxc8; $c8spadisrl = $c8psrl/$maxc8; $c8ssawit = $c8s/$maxc8; $c8srumput = $c8r/$maxc8;
$c8sjagung = $c8j/$maxc8; $c8spadigogo = $c8pgogo/$maxc8; $c8sbawang = $c8b/$maxc8; $c8skakao = $c8ka/$maxc8; $c8ssetaria = $c8set/$maxc8;
$c8skedelai = $c8k/$maxc8; $c8spadisrps = $c8psrps/$maxc8; $c8scabai = $c8c/$maxc8; $c8stebu = $c8t/$maxc8;

//C9
$c9spadi = $c9p/$maxc9; $c9spadisth = $c9psth/$maxc9; $c9spadisrl = $c9psrl/$maxc9; $c9ssawit = $c9s/$maxc9; $c9srumput = $c9r/$maxc9;
$c9sjagung = $c9j/$maxc9; $c9spadigogo = $c9pgogo/$maxc9; $c9sbawang = $c9b/$maxc9; $c9skakao = $c9ka/$maxc9; $c9ssetaria = $c9set/$maxc9;
$c9skedelai = $c9k/$maxc9; $c9spadisrps = $c9psrps/$maxc9; $c9scabai = $c9c/$maxc9; $c9stebu = $c9t/$maxc9;

//C10
$c10spadi = $c10p/$maxc10; $c10spadisth = $c10psth/$maxc10; $c10spadisrl = $c10psrl/$maxc10; $c10ssawit = $c10s/$maxc10; $c10srumput = $c10r/$maxc10;
$c10sjagung = $c10j/$maxc10; $c10spadigogo = $c10pgogo/$maxc10; $c10sbawang = $c10b/$maxc10; $c10skakao = $c10ka/$maxc10; $c10ssetaria = $c10set/$maxc10;
$c10skedelai = $c10k/$maxc10; $c10spadisrps = $c10psrps/$maxc10; $c10scabai = $c10c/$maxc10; $c10stebu = $c10t/$maxc10;

//C11
$c11spadi = $c11p/$maxc11; $c11spadisth = $c11psth/$maxc11; $c11spadisrl = $c11psrl/$maxc11; $c11ssawit = $c11s/$maxc11; $c11srumput = $c11r/$maxc11;
$c11sjagung = $c11j/$maxc11; $c11spadigogo = $c11pgogo/$maxc11; $c11sbawang = $c11b/$maxc11; $c11skakao = $c11ka/$maxc11; $c11ssetaria = $c11set/$maxc11;
$c11skedelai = $c11k/$maxc11; $c11spadisrps = $c11psrps/$maxc11; $c11scabai = $c11c/$maxc11; $c11stebu = $c11t/$maxc11;

//C12
$c12spadi = $c12p/$maxc12; $c12spadisth = $c12psth/$maxc12; $c12spadisrl = $c12psrl/$maxc12; $c12ssawit = $c12s/$maxc12; $c12srumput = $c12r/$maxc12;
$c12sjagung = $c12j/$maxc12; $c12spadigogo = $c12pgogo/$maxc12; $c12sbawang = $c12b/$maxc12; $c12skakao = $c12ka/$maxc12; $c12ssetaria = $c12set/$maxc12;
$c12skedelai = $c12k/$maxc12; $c12spadisrps = $c12psrps/$maxc12; $c12scabai = $c12c/$maxc12; $c12stebu = $c12t/$maxc12;

//C13
$c13spadi = $c13p/$maxc13; $c13spadisth = $c13psth/$maxc13; $c13spadisrl = $c13psrl/$maxc13; $c13ssawit = $c13s/$maxc13; $c13srumput = $c13r/$maxc13;
$c13sjagung = $c13j/$maxc13; $c13spadigogo = $c13pgogo/$maxc13; $c13sbawang = $c13b/$maxc13; $c13skakao = $c13ka/$maxc13; $c13ssetaria = $c13set/$maxc13;
$c13skedelai = $c13k/$maxc13; $c13spadisrps = $c13psrps/$maxc13; $c13scabai = $c13c/$maxc13; $c13stebu = $c13t/$maxc13;

//C14
$c14spadi = $c14p/$maxc14; $c14spadisth = $c14psth/$maxc14; $c14spadisrl = $c14psrl/$maxc14; $c14ssawit = $c14s/$maxc14; $c14srumput = $c14r/$maxc14;
$c14sjagung = $c14j/$maxc14; $c14spadigogo = $c14pgogo/$maxc14; $c14sbawang = $c14b/$maxc14; $c14skakao = $c14ka/$maxc14; $c14ssetaria = $c14set/$maxc14;
$c14skedelai = $c14k/$maxc14; $c14spadisrps = $c14psrps/$maxc14; $c14scabai = $c14c/$maxc14; $c14stebu = $c14t/$maxc14;

//C15
$c15spadi = $c15p/$maxc15; $c15spadisth = $c15psth/$maxc15; $c15spadisrl = $c15psrl/$maxc15; $c15ssawit = $c15s/$maxc15; $c15srumput = $c15r/$maxc15;
$c15sjagung = $c15j/$maxc15; $c15spadigogo = $c15pgogo/$maxc15; $c15sbawang = $c15b/$maxc15; $c15skakao = $c15ka/$maxc15; $c15ssetaria = $c15set/$maxc15;
$c15skedelai = $c15k/$maxc15; $c15spadisrps = $c15psrps/$maxc15; $c15scabai = $c15c/$maxc15; $c15stebu = $c15t/$maxc15;

//C16
$c16spadi = $c16p/$maxc16; $c16spadisth = $c16psth/$maxc16; $c16spadisrl = $c16psrl/$maxc16; $c16ssawit = $c16s/$maxc16; $c16srumput = $c16r/$maxc16;
$c16sjagung = $c16j/$maxc16; $c16spadigogo = $c16pgogo/$maxc16; $c16sbawang = $c16b/$maxc16; $c16skakao = $c16ka/$maxc16; $c16ssetaria = $c16set/$maxc16;
$c16skedelai = $c16k/$maxc16; $c16spadisrps = $c16psrps/$maxc16; $c16scabai = $c16c/$maxc16; $c16stebu = $c16t/$maxc16;

//C17
$c17spadi = $c17p/$maxc17; $c17spadisth = $c17psth/$maxc17; $c17spadisrl = $c17psrl/$maxc17; $c17ssawit = $c17s/$maxc17; $c17srumput = $c17r/$maxc17;
$c17sjagung = $c17j/$maxc17; $c17spadigogo = $c17pgogo/$maxc17; $c17sbawang = $c17b/$maxc17; $c17skakao = $c17ka/$maxc17; $c17ssetaria = $c17set/$maxc17;
$c17skedelai = $c17k/$maxc17; $c17spadisrps = $c17psrps/$maxc17; $c17scabai = $c17c/$maxc17; $c17stebu = $c17t/$maxc17;

//C18
$c18spadi = $c18p/$maxc18; $c18spadisth = $c18psth/$maxc18; $c18spadisrl = $c18psrl/$maxc18; $c18ssawit = $c18s/$maxc18; $c18srumput = $c18r/$maxc18;
$c18sjagung = $c18j/$maxc18; $c18spadigogo = $c18pgogo/$maxc18; $c18sbawang = $c18b/$maxc18; $c18skakao = $c18ka/$maxc18; $c18ssetaria = $c18set/$maxc18;
$c18skedelai = $c18k/$maxc18; $c18spadisrps = $c18psrps/$maxc18; $c18scabai = $c18c/$maxc18; $c18stebu = $c18t/$maxc18;

//C19
$c19spadi = $c19p/$maxc19; $c19spadisth = $c19psth/$maxc19; $c19spadisrl = $c19psrl/$maxc19; $c19ssawit = $c19s/$maxc19; $c19srumput = $c19r/$maxc19;
$c19sjagung = $c19j/$maxc19; $c19spadigogo = $c19pgogo/$maxc19; $c19sbawang = $c19b/$maxc19; $c19skakao = $c19ka/$maxc19; $c19ssetaria = $c19set/$maxc19;
$c19skedelai = $c19k/$maxc19; $c19spadisrps = $c19psrps/$maxc19; $c19scabai = $c19c/$maxc19; $c19stebu = $c19t/$maxc19;

//C20
$c20spadi = $c20p/$maxc20; $c20spadisth = $c20psth/$maxc20; $c20spadisrl = $c20psrl/$maxc20; $c20ssawit = $c20s/$maxc20; $c20srumput = $c20r/$maxc20;
$c20sjagung = $c20j/$maxc20; $c20spadigogo = $c20pgogo/$maxc20; $c20sbawang = $c20b/$maxc20; $c20skakao = $c20ka/$maxc20; $c20ssetaria = $c20set/$maxc20;
$c20skedelai = $c20k/$maxc20; $c20spadisrps = $c20psrps/$maxc20; $c20scabai = $c20c/$maxc20; $c20stebu = $c20t/$maxc20;

//C21
$c21spadi = $c21p/$maxc21; $c21spadisth = $c21psth/$maxc21; $c21spadisrl = $c21psrl/$maxc21; $c21ssawit = $c21s/$maxc21; $c21srumput = $c21r/$maxc21;
$c21sjagung = $c21j/$maxc21; $c21spadigogo = $c21pgogo/$maxc21; $c21sbawang = $c21b/$maxc21; $c21skakao = $c21ka/$maxc21; $c21ssetaria = $c21set/$maxc21;
$c21skedelai = $c21k/$maxc21; $c21spadisrps = $c21psrps/$maxc21; $c21scabai = $c21c/$maxc21; $c21stebu = $c21t/$maxc21;

//C22
$c22spadi = $c22p/$maxc22; $c22spadisth = $c22psth/$maxc22; $c22spadisrl = $c22psrl/$maxc22; $c22ssawit = $c22s/$maxc22; $c22srumput = $c22r/$maxc22;
$c22sjagung = $c22j/$maxc22; $c22spadigogo = $c22pgogo/$maxc22; $c22sbawang = $c22b/$maxc22; $c22skakao = $c22ka/$maxc22; $c22ssetaria = $c22set/$maxc22;
$c22skedelai = $c22k/$maxc22; $c22spadisrps = $c22psrps/$maxc22; $c22scabai = $c22c/$maxc22; $c22stebu = $c22t/$maxc22;

//C23
$c23spadi = $c23p/$maxc23; $c23spadisth = $c23psth/$maxc23; $c23spadisrl = $c23psrl/$maxc23; $c23ssawit = $c23s/$maxc23; $c23srumput = $c23r/$maxc23;
$c23sjagung = $c23j/$maxc23; $c23spadigogo = $c23pgogo/$maxc23; $c23sbawang = $c23b/$maxc23; $c23skakao = $c23ka/$maxc23; $c23ssetaria = $c23set/$maxc23;
$c23skedelai = $c23k/$maxc23; $c23spadisrps = $c23psrps/$maxc23; $c23scabai = $c23c/$maxc23; $c23stebu = $c23t/$maxc23;

//C24
$c24spadi = $c24p/$maxc24; $c24spadisth = $c24psth/$maxc24; $c24spadisrl = $c24psrl/$maxc24; $c24ssawit = $c24s/$maxc24; $c24srumput = $c24r/$maxc24;
$c24sjagung = $c24j/$maxc24; $c24spadigogo = $c24pgogo/$maxc24; $c24sbawang = $c24b/$maxc24; $c24skakao = $c24ka/$maxc24; $c24ssetaria = $c24set/$maxc24;
$c24skedelai = $c24k/$maxc24; $c24spadisrps = $c24psrps/$maxc24; $c24scabai = $c24c/$maxc24; $c24stebu = $c24t/$maxc24;

//C25
$c25spadi = $c25p/$maxc25; $c25spadisth = $c25psth/$maxc25; $c25spadisrl = $c25psrl/$maxc25; $c25ssawit = $c25s/$maxc25; $c25srumput = $c25r/$maxc25;
$c25sjagung = $c25j/$maxc25; $c25spadigogo = $c25pgogo/$maxc25; $c25sbawang = $c25b/$maxc25; $c25skakao = $c25ka/$maxc25; $c25ssetaria = $c25set/$maxc25;
$c25skedelai = $c25k/$maxc25; $c25spadisrps = $c25psrps/$maxc25; $c25scabai = $c25c/$maxc25; $c25stebu = $c25t/$maxc25;



$hslpadi = ($c1spadi*4) + ($c2spadi*4) + ($c3spadi*4) + ($c4spadi*4) + ($c5spadi*4) + ($c6spadi*4) + ($c7spadi*4) + ($c8spadi*4) + ($c9spadi*4) + ($c10spadi*4) +($c11spadi*4) + ($c12spadi*4) + ($c13spadi*4) + ($c14spadi*4) + ($c15spadi*4) + ($c16spadi*4) + ($c17spadi*4) + ($c18spadi*4) + ($c19spadi*4) + ($c20spadi*4) + ($c21spadi*4) + ($c22spadi*4) + ($c23spadi*4) + ($c24spadi*4) + ($c25spadi*4);
$hsljagung = ($c1sjagung*4) + ($c2sjagung*4) + ($c3sjagung*4) + ($c4sjagung*4) + ($c5sjagung*4) + ($c6sjagung*4) + ($c7sjagung*4) + ($c8sjagung*4) + ($c9sjagung*4) + ($c10sjagung*4) +($c11sjagung*4) + ($c12sjagung*4) + ($c13sjagung*4) + ($c14sjagung*4) + ($c15sjagung*4) + ($c16sjagung*4) + ($c17sjagung*4) + ($c18sjagung*4) + ($c19sjagung*4) + ($c20sjagung*4) + ($c21sjagung*4) + ($c22sjagung*4) + ($c23sjagung*4) + ($c24sjagung*4) + ($c25sjagung*4);
$hslkedelai = ($c1skedelai*4) + ($c2skedelai*4) + ($c3skedelai*4) + ($c4skedelai*4) + ($c5skedelai*4) + ($c6skedelai*4) + ($c7skedelai*4) + ($c8skedelai*4) + ($c9skedelai*4) + ($c10skedelai*4) +($c11skedelai*4) + ($c12skedelai*4) + ($c13skedelai*4) + ($c14skedelai*4) + ($c15skedelai*4) + ($c16skedelai*4) + ($c17skedelai*4) + ($c18skedelai*4) + ($c19skedelai*4) + ($c20skedelai*4) + ($c21skedelai*4) + ($c22skedelai*4) + ($c23skedelai*4) + ($c24skedelai*4) + ($c25skedelai*4);
$hslpadisth = ($c1spadisth*4) + ($c2spadisth*4) + ($c3spadisth*4) + ($c4spadisth*4) + ($c5spadisth*4) + ($c6spadisth*4) + ($c7spadisth*4) + ($c8spadisth*4) + ($c9spadisth*4) + ($c10spadisth*4) +($c11spadisth*4) + ($c12spadisth*4) + ($c13spadisth*4) + ($c14spadisth*4) + ($c15spadisth*4) + ($c16spadisth*4) + ($c17spadisth*4) + ($c18spadisth*4) + ($c19spadisth*4) + ($c20spadisth*4) + ($c21spadisth*4) + ($c22spadisth*4) + ($c23spadisth*4) + ($c24spadisth*4) + ($c25spadisth*4);
$hslpadigogo = ($c1spadigogo*4) + ($c2spadigogo*4) + ($c3spadigogo*4) + ($c4spadigogo*4) + ($c5spadigogo*4) + ($c6spadigogo*4) + ($c7spadigogo*4) + ($c8spadigogo*4) + ($c9spadigogo*4) + ($c10spadigogo*4) +($c11spadigogo*4) + ($c12spadigogo*4) + ($c13spadigogo*4) + ($c14spadigogo*4) + ($c15spadigogo*4) + ($c16spadigogo*4) + ($c17spadigogo*4) + ($c18spadigogo*4) + ($c19spadigogo*4) + ($c20spadigogo*4) + ($c21spadigogo*4) + ($c22spadigogo*4) + ($c23spadigogo*4) + ($c24spadigogo*4) + ($c25spadigogo*4);
$hslpadisrps = ($c1spadisrps*4) + ($c2spadisrps*4) + ($c3spadisrps*4) + ($c4spadisrps*4) + ($c5spadisrps*4) + ($c6spadisrps*4) + ($c7spadisrps*4) + ($c8spadisrps*4) + ($c9spadisrps*4) + ($c10spadisrps*4) +($c11spadisrps*4) + ($c12spadisrps*4) + ($c13spadisrps*4) + ($c14spadisrps*4) + ($c15spadisrps*4) + ($c16spadisrps*4) + ($c17spadisrps*4) + ($c18spadisrps*4) + ($c19spadisrps*4) + ($c20spadisrps*4) + ($c21spadisrps*4) + ($c22spadisrps*4) + ($c23spadisrps*4) + ($c24spadisrps*4) + ($c25spadisrps*4);
$hslpadisrl = ($c1spadisrl*4) + ($c2spadisrl*4) + ($c3spadisrl*4) + ($c4spadisrl*4) + ($c5spadisrl*4) + ($c6spadisrl*4) + ($c7spadisrl*4) + ($c8spadisrl*4) + ($c9spadisrl*4) + ($c10spadisrl*4) +($c11spadisrl*4) + ($c12spadisrl*4) + ($c13spadisrl*4) + ($c14spadisrl*4) + ($c15spadisrl*4) + ($c16spadisrl*4) + ($c17spadisrl*4) + ($c18spadisrl*4) + ($c19spadisrl*4) + ($c20spadisrl*4) + ($c21spadisrl*4) + ($c22spadisrl*4) + ($c23spadisrl*4) + ($c24spadisrl*4) + ($c25spadisrl*4);
$hslbawang = ($c1sbawang*4) + ($c2sbawang*4) + ($c3sbawang*4) + ($c4sbawang*4) + ($c5sbawang*4) + ($c6sbawang*4) + ($c7sbawang*4) + ($c8sbawang*4) + ($c9sbawang*4) + ($c10sbawang*4) +($c11sbawang*4) + ($c12sbawang*4) + ($c13sbawang*4) + ($c14sbawang*4) + ($c15sbawang*4) + ($c16sbawang*4) + ($c17sbawang*4) + ($c18sbawang*4) + ($c19sbawang*4) + ($c20sbawang*4) + ($c21sbawang*4) + ($c22sbawang*4) + ($c23sbawang*4) + ($c24sbawang*4) + ($c25sbawang*4);
$hslcabai = ($c1scabai*4) + ($c2scabai*4) + ($c3scabai*4) + ($c4scabai*4) + ($c5scabai*4) + ($c6scabai*4) + ($c7scabai*4) + ($c8scabai*4) + ($c9scabai*4) + ($c10scabai*4) +($c11scabai*4) + ($c12scabai*4) + ($c13scabai*4) + ($c14scabai*4) + ($c15scabai*4) + ($c16scabai*4) + ($c17scabai*4) + ($c18scabai*4) + ($c19scabai*4) + ($c20scabai*4) + ($c21scabai*4) + ($c22scabai*4) + ($c23scabai*4) + ($c24scabai*4) + ($c25scabai*4);
$hslsawit = ($c1ssawit*4) + ($c2ssawit*4) + ($c3ssawit*4) + ($c4ssawit*4) + ($c5ssawit*4) + ($c6ssawit*4) + ($c7ssawit*4) + ($c8ssawit*4) + ($c9ssawit*4) + ($c10ssawit*4) +($c11ssawit*4) + ($c12ssawit*4) + ($c13ssawit*4) + ($c14ssawit*4) + ($c15ssawit*4) + ($c16ssawit*4) + ($c17ssawit*4) + ($c18ssawit*4) + ($c19ssawit*4) + ($c20ssawit*4) + ($c21ssawit*4) + ($c22ssawit*4) + ($c23ssawit*4) + ($c24ssawit*4) + ($c25ssawit*4);
$hslkakao = ($c1skakao*4) + ($c2skakao*4) + ($c3skakao*4) + ($c4skakao*4) + ($c5skakao*4) + ($c6skakao*4) + ($c7skakao*4) + ($c8skakao*4) + ($c9skakao*4) + ($c10skakao*4) +($c11skakao*4) + ($c12skakao*4) + ($c13skakao*4) + ($c14skakao*4) + ($c15skakao*4) + ($c16skakao*4) + ($c17skakao*4) + ($c18skakao*4) + ($c19skakao*4) + ($c20skakao*4) + ($c21skakao*4) + ($c22skakao*4) + ($c23skakao*4) + ($c24skakao*4) + ($c25skakao*4);
$hsltebu = ($c1stebu*4) + ($c2stebu*4) + ($c3stebu*4) + ($c4stebu*4) + ($c5stebu*4) + ($c6stebu*4) + ($c7stebu*4) + ($c8stebu*4) + ($c9stebu*4) + ($c10stebu*4) +($c11stebu*4) + ($c12stebu*4) + ($c13stebu*4) + ($c14stebu*4) + ($c15stebu*4) + ($c16stebu*4) + ($c17stebu*4) + ($c18stebu*4) + ($c19stebu*4) + ($c20stebu*4) + ($c21stebu*4) + ($c22stebu*4) + ($c23stebu*4) + ($c24stebu*4) + ($c25stebu*4);
$hslrumput = ($c1srumput*4) + ($c2srumput*4) + ($c3srumput*4) + ($c4srumput*4) + ($c5srumput*4) + ($c6srumput*4) + ($c7srumput*4) + ($c8srumput*4) + ($c9srumput*4) + ($c10srumput*4) +($c11srumput*4) + ($c12srumput*4) + ($c13srumput*4) + ($c14srumput*4) + ($c15srumput*4) + ($c16srumput*4) + ($c17srumput*4) + ($c18srumput*4) + ($c19srumput*4) + ($c20srumput*4) + ($c21srumput*4) + ($c22srumput*4) + ($c23srumput*4) + ($c24srumput*4) + ($c25srumput*4);
$hslsetaria = ($c1ssetaria*4) + ($c2ssetaria*4) + ($c3ssetaria*4) + ($c4ssetaria*4) + ($c5ssetaria*4) + ($c6ssetaria*4) + ($c7ssetaria*4) + ($c8ssetaria*4) + ($c9ssetaria*4) + ($c10ssetaria*4) +($c11ssetaria*4) + ($c12ssetaria*4) + ($c13ssetaria*4) + ($c14ssetaria*4) + ($c15ssetaria*4) + ($c16ssetaria*4) + ($c17ssetaria*4) + ($c18ssetaria*4) + ($c19ssetaria*4) + ($c20ssetaria*4) + ($c21ssetaria*4) + ($c22ssetaria*4) + ($c23ssetaria*4) + ($c24ssetaria*4) + ($c25ssetaria*4);


$sqls1="insert into ds_saw (nama_tanaman, nilai) values ('Setaria','$hslsetaria')";
$hasils1=mysqli_query($kon,$sqls1);
$sqls2="insert into ds_saw (nama_tanaman, nilai) values ('Rumput Gajah','$hslrumput')";
$hasils2=mysqli_query($kon,$sqls2);
$sqls3="insert into ds_saw (nama_tanaman, nilai) values ('Tebu','$hsltebu')";
$hasils3=mysqli_query($kon,$sqls3);
$sqls4="insert into ds_saw (nama_tanaman, nilai) values ('Kakao','$hslkakao')";
$hasils4=mysqli_query($kon,$sqls4);
$sqls5="insert into ds_saw (nama_tanaman, nilai) values ('Kelapa Sawit','$hslsawit')"; 
$hasils5=mysqli_query($kon,$sqls5);
$sqls6="insert into ds_saw (nama_tanaman, nilai) values ('Cabai Merah','$hslcabai')";
$hasils6=mysqli_query($kon,$sqls6);
$sqls7="insert into ds_saw (nama_tanaman, nilai) values ('Bawang Merah','$hslbawang')";
$hasils7=mysqli_query($kon,$sqls7);
$sqls8="insert into ds_saw (nama_tanaman, nilai) values ('Kedelai','$hslkedelai')";
$hasils8=mysqli_query($kon,$sqls8);
$sqls9="insert into ds_saw (nama_tanaman, nilai) values ('Jagung','$hsljagung')";
$hasils9=mysqli_query($kon,$sqls9);
$sqls10="insert into ds_saw (nama_tanaman, nilai) values ('Padi Sawah Rawa Lebak','$hslpadisrl')"; 
$hasils10=mysqli_query($kon,$sqls10);
$sqls11="insert into ds_saw (nama_tanaman, nilai) values ('Padi Sawah Rawa Pasang Surut','$hslpadisrps')";
$hasils11=mysqli_query($kon,$sqls11);
$sqls12="insert into ds_saw (nama_tanaman, nilai) values ('Padi Gogo','$hslpadigogo')";
$hasils12=mysqli_query($kon,$sqls12);
$sqls13="insert into ds_saw (nama_tanaman, nilai) values ('Padi Sawah Tadah Hujan','$hslpadisth')"; 
$hasils13=mysqli_query($kon,$sqls13);
$sqls14="insert into ds_saw (nama_tanaman, nilai) values ('Padi Sawah Irigasi','$hslpadi')"; 
$hasils14=mysqli_query($kon,$sqls14);

?>